const { describe, it } = require("node:test");
const assert = require("node:assert/strict");
const { buildRecommendationPackage } = require("./recommendation-engine");

describe("recommendation engine", () => {
  it("builds ranked recommendations from repeated work signals", () => {
    const result = buildRecommendationPackage({
      id: "emp-test",
      actions: [
        { app: "Gmail", category: "Repetitive", description: "Replied to support ticket queue with the same structure." },
        { app: "Gmail", category: "Automatable", description: "Triaged inbox requests and routed escalations into Slack." },
        { app: "Slack", category: "Automatable", description: "Routed blocker questions into the correct thread." },
        { app: "Sheets", category: "Automatable", description: "Merged export rows before CRM sync." },
      ],
    });

    assert.ok(result.recommendations.length >= 1);
    assert.ok(result.recommendations[0].confidenceScore >= 55);
    assert.ok(result.reclaimableHours > 0);
    assert.ok(result.report.headline.includes("reclaimable hours"));
    assert.ok(result.profilePoints.length >= 1);
  });

  it("falls back to no high-confidence opportunities for sparse work", () => {
    const result = buildRecommendationPackage({
      id: "emp-sparse",
      actions: [
        { app: "Calendar", category: "Other", description: "Joined a single meeting." },
      ],
    });

    assert.equal(result.recommendations.length, 0);
    assert.equal(result.automationReadiness, 0);
    assert.ok(result.report.headline.includes("No high-confidence"));
  });
});

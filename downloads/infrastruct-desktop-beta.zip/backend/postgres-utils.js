const { Client } = require("pg");
const { DATABASE_URL } = require("./config");

function buildPgClient() {
  if (!DATABASE_URL) {
    throw new Error("INFRASTRUCT_DATABASE_URL or DATABASE_URL is required for Postgres integration");
  }

  const useSsl = !/sslmode=disable/i.test(DATABASE_URL);
  return new Client({
    connectionString: DATABASE_URL,
    ssl: useSsl ? { rejectUnauthorized: false } : false,
  });
}

async function withPgClient(work) {
  const client = buildPgClient();
  await client.connect();

  try {
    return await work(client);
  } finally {
    await client.end();
  }
}

module.exports = {
  buildPgClient,
  withPgClient,
};

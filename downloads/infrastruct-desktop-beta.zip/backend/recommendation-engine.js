const KEYWORD_GROUPS = {
  triage: ["reply", "replied", "ticket", "inbox", "queue", "triage", "support"],
  reconcile: ["merge", "reconciliation", "reconcile", "export", "status field", "sheet", "crm", "pipeline", "sync"],
  route: ["route", "routing", "thread", "handoff", "digest", "blocker", "question"],
  draft: ["draft", "brief", "summary", "summaries", "update", "launch", "status", "stakeholder"],
};

const TEMPLATES = [
  {
    id: "inbox-triage",
    name: "Inbox triage and routing",
    scope: "Gmail + Slack",
    mode: "Request approval",
    summary: "Classify inbound requests, draft responses, and route exceptions into the right handoff thread.",
    match(signals) {
      return (signals.apps.Gmail || 0) * 1.4 + signals.keywordHits.triage * 1.7 + signals.automatableActions * 0.4;
    },
    buildRationale(signals) {
      return `Observed ${signals.keywordHits.triage} repeated inbox or ticket actions across Gmail-heavy work.`;
    },
  },
  {
    id: "reconciliation-sync",
    name: "Reconciliation and record sync",
    scope: "Sheets + Salesforce",
    mode: "Draft then approve",
    summary: "Prepare merged datasets, suggest field updates, and queue sync steps for explicit confirmation.",
    match(signals) {
      return (signals.apps.Sheets || 0) * 1.4 + (signals.apps.Salesforce || 0) * 1.2 + signals.keywordHits.reconcile * 1.9;
    },
    buildRationale(signals) {
      return `Repeated merge or sync work was detected ${signals.keywordHits.reconcile} times in spreadsheet and CRM activity.`;
    },
  },
  {
    id: "thread-digest",
    name: "Thread digest generator",
    scope: "Slack + Notion",
    mode: "Request approval",
    summary: "Collect thread outcomes, rank urgency, and produce a draft digest for review.",
    match(signals) {
      return (signals.apps.Slack || 0) * 1.3 + (signals.apps.Notion || 0) * 0.7 + signals.keywordHits.route * 1.7;
    },
    buildRationale(signals) {
      return `Slack routing and handoff behavior appears frequently, with ${signals.keywordHits.route} routing or blocker signals.`;
    },
  },
  {
    id: "brief-drafter",
    name: "Brief and summary drafter",
    scope: "Docs + Linear + Slack",
    mode: "Request approval",
    summary: "Turn issue changes and discussion threads into a polished weekly brief with linked source context.",
    match(signals) {
      return (signals.apps.Docs || 0) * 1.1 + (signals.apps.Linear || 0) * 0.8 + signals.keywordHits.draft * 1.8;
    },
    buildRationale(signals) {
      return `Drafting and summarization work is recurring, with ${signals.keywordHits.draft} brief or summary signals.`;
    },
  },
];

function round(value, digits = 1) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function toImpactLabel(hours) {
  return `${round(hours, 1)}h / wk`;
}

function collectSignals(employee) {
  const actions = Array.isArray(employee.actions) ? employee.actions : [];
  const apps = {};
  const categories = {};
  const keywordHits = {
    triage: 0,
    reconcile: 0,
    route: 0,
    draft: 0,
  };

  actions.forEach((action) => {
    apps[action.app] = (apps[action.app] || 0) + 1;
    categories[action.category] = (categories[action.category] || 0) + 1;

    const description = String(action.description || "").toLowerCase();
    Object.entries(KEYWORD_GROUPS).forEach(([group, terms]) => {
      if (terms.some((term) => description.includes(term))) {
        keywordHits[group] += 1;
      }
    });
  });

  const automatableActions = ["Automatable", "Repetitive", "Agent fit"]
    .reduce((sum, category) => sum + (categories[category] || 0), 0);

  return {
    actions,
    apps,
    categories,
    keywordHits,
    automatableActions,
    totalActions: actions.length,
    topApps: Object.entries(apps)
      .sort((left, right) => right[1] - left[1])
      .slice(0, 3)
      .map(([appName]) => appName),
  };
}

function evaluateTemplate(employee, template, signals) {
  const rawScore = template.match(signals);
  if (rawScore < 2.5) {
    return null;
  }

  const confidenceScore = clamp(Math.round(52 + rawScore * 7 + signals.automatableActions * 2), 55, 96);
  const projectedHours = clamp(round(0.9 + rawScore * 0.55 + signals.automatableActions * 0.35, 1), 1.2, 12.5);
  const rankScore = round(confidenceScore * 0.75 + projectedHours * 8, 1);
  const status = confidenceScore >= 85 ? "review" : "proposed";

  return {
    id: `gen-${employee.id}-${template.id}`,
    name: template.name,
    scope: template.scope,
    mode: template.mode,
    impact: toImpactLabel(projectedHours),
    projectedHours,
    confidenceScore,
    rankScore,
    status,
    employeeDecision: "pending",
    adminDecision: "pending",
    summary: template.summary,
    rationale: template.buildRationale(signals),
    source: "generated",
  };
}

function buildFallbackRecommendation(employee, signals) {
  if (signals.totalActions < 3) {
    return [];
  }

  const scope = signals.topApps.slice(0, 2).join(" + ") || "Observed apps";
  const projectedHours = clamp(round(signals.automatableActions * 0.7, 1), 1, 6);
  const confidenceScore = clamp(58 + signals.automatableActions * 4, 58, 82);

  return [{
    id: `gen-${employee.id}-workflow-assistant`,
    name: "Workflow assistant draft",
    scope,
    mode: "Request approval",
    impact: toImpactLabel(projectedHours),
    projectedHours,
    confidenceScore,
    rankScore: round(confidenceScore * 0.7 + projectedHours * 8, 1),
    status: "proposed",
    employeeDecision: "pending",
    adminDecision: "pending",
    summary: "Draft repeatable next steps from the employee's most common workflow and hold for approval.",
    rationale: `The employee repeats work across ${scope} with ${signals.automatableActions} actions already classified as automatable or repetitive.`,
    source: "generated",
  }];
}

function buildGeneratedProfilePoints(employee, signals, recommendations) {
  if (!recommendations.length) {
    return ["Observation volume is still too low to generate confident profile points."];
  }

  const dominantApps = signals.topApps.length ? signals.topApps.join(", ") : "observed apps";
  const strongest = recommendations[0];

  return [
    `Generated profile: the employee's repeatable work is concentrated in ${dominantApps}.`,
    `Highest-ranked opportunity is "${strongest.name}" at ${strongest.confidenceScore}% confidence.`,
    strongest.rationale,
  ];
}

function buildGeneratedReport(employee, signals, recommendations) {
  if (!recommendations.length) {
    return {
      headline: "No high-confidence automation opportunities detected yet.",
      findings: [
        "The employee does not yet have enough repeated observed work to produce a ranked automation recommendation.",
        "Keep collecting metadata-only actions to improve confidence and ranking quality.",
      ],
    };
  }

  const totalProjectedHours = round(recommendations.reduce((sum, entry) => sum + entry.projectedHours, 0), 1);
  const best = recommendations[0];
  const findings = [
    `Top recommendation is "${best.name}" with ${best.confidenceScore}% confidence and ${best.impact} projected savings.`,
    `Detected repeated work across ${signals.topApps.join(", ") || "observed apps"} with ${signals.automatableActions} actions classified as repetitive or automatable.`,
    `The current recommendation set is suited to ${best.mode.toLowerCase()} workflows before anything runs automatically.`,
  ];

  return {
    headline: `${totalProjectedHours} reclaimable hours each week based on observed repeat work.`,
    findings,
  };
}

function buildRecommendationPackage(employee) {
  const signals = collectSignals(employee);
  let recommendations = TEMPLATES
    .map((template) => evaluateTemplate(employee, template, signals))
    .filter(Boolean)
    .sort((left, right) => right.rankScore - left.rankScore)
    .slice(0, 3);

  if (!recommendations.length) {
    recommendations = buildFallbackRecommendation(employee, signals);
  }

  const report = buildGeneratedReport(employee, signals, recommendations);
  const profilePoints = buildGeneratedProfilePoints(employee, signals, recommendations);
  const automationReadiness = recommendations.length
    ? Math.round(recommendations.reduce((sum, entry) => sum + entry.confidenceScore, 0) / recommendations.length)
    : 0;
  const reclaimableHours = recommendations.length
    ? round(recommendations.reduce((sum, entry) => sum + entry.projectedHours, 0), 1)
    : 0;

  return {
    employeeId: employee.id,
    reclaimableHours,
    automationReadiness,
    profilePoints,
    report,
    recommendations,
    trace: {
      actionCount: signals.totalActions,
      automatableActions: signals.automatableActions,
      topApps: signals.topApps,
      categoryCounts: signals.categories,
      keywordHits: signals.keywordHits,
      recommendationIds: recommendations.map((entry) => entry.id),
    },
  };
}

module.exports = {
  buildRecommendationPackage,
};

const fs = require("fs");
const path = require("path");
const {
  BACKUP_DIR,
  DB_PATH,
} = require("./config");

function timestampId() {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function copyIfExists(sourcePath, targetPath) {
  if (!fs.existsSync(sourcePath)) {
    return false;
  }

  fs.copyFileSync(sourcePath, targetPath);
  return true;
}

function main() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });

  const stamp = timestampId();
  const dbName = path.basename(DB_PATH);
  const backupBase = path.join(BACKUP_DIR, `${stamp}-${dbName}`);
  const copied = [];

  if (copyIfExists(DB_PATH, backupBase)) {
    copied.push(backupBase);
  }

  ["-wal", "-shm"].forEach((suffix) => {
    const source = `${DB_PATH}${suffix}`;
    const target = `${backupBase}${suffix}`;
    if (copyIfExists(source, target)) {
      copied.push(target);
    }
  });

  console.log(JSON.stringify({
    ok: true,
    dbPath: DB_PATH,
    backupDir: BACKUP_DIR,
    files: copied,
  }, null, 2));
}

main();

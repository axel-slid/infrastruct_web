const fs = require("fs");
const os = require("os");
const path = require("path");
const { WorkspaceRepository } = require("./repository");

function removeDbFiles(dbPath) {
  ["", "-wal", "-shm"].forEach((suffix) => {
    try {
      fs.rmSync(`${dbPath}${suffix}`, { force: true });
    } catch (_error) {
      // ignore cleanup failures
    }
  });
}

function main() {
  const dbPath = path.join(os.tmpdir(), "infrastruct-backend-smoke.db");
  removeDbFiles(dbPath);

  const repository = new WorkspaceRepository(dbPath, {
    bootstrapPassword: "SmokePass123!",
  });

  repository.init();

  const login = repository.login({
    email: "dana@acme-logistics.com",
    password: "SmokePass123!",
    orgSlug: "acme-logistics",
    label: "smoke-test",
  });
  const orgId = login.organization.id;
  const actorUserId = login.user.id;

  const integration = repository.connectIntegration(orgId, actorUserId, {
    provider: "figma",
    displayName: "Figma",
    connectionMode: "oauth",
    scopes: ["files:read", "file_comments:read"],
    externalAccountRef: "figma-team-smoke",
  });

  const device = repository.registerDevice(orgId, actorUserId, {
    userId: "emp-maria",
    label: "Maria Smoke Device",
    platform: "macos",
  });

  const ingest = repository.ingestObserverBatch({
    deviceId: device.deviceId,
    ingestKey: device.ingestKey,
    provider: "gmail",
    events: [
      {
        id: "gmail-smoke-1",
        userEmail: "maria@acme-logistics.com",
        timestamp: "2026-04-22T06:00:00.000Z",
        action: "reply_draft",
        subject: "Carrier exception #901",
      },
    ],
  });

  const snapshot = repository.snapshot();

  console.log(JSON.stringify({
    organization: snapshot.workspace.slug,
    loginUser: login.user.email,
    integrations: integration.integrations.length,
    deviceId: device.deviceId,
    observerInserted: ingest.inserted,
    latestAuditEvent: snapshot.auditTrail[0]?.eventType,
  }, null, 2));

  repository.close();
  removeDbFiles(dbPath);
}

main();

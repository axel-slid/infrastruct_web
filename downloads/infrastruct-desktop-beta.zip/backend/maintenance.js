const { WorkspaceRepository } = require("./repository");
const {
  BOOTSTRAP_PASSWORD,
  DB_PATH,
  OBSERVER_REDACTION_MODE,
  RAW_EVENT_RETENTION_DAYS,
} = require("./config");

function main() {
  const repository = new WorkspaceRepository(DB_PATH, {
    bootstrapPassword: BOOTSTRAP_PASSWORD,
    observerRedactionMode: OBSERVER_REDACTION_MODE,
    rawEventRetentionDays: RAW_EVENT_RETENTION_DAYS,
  });

  repository.init();
  const result = repository.applyObservedActionRetention();
  const metrics = repository.getMetricsSnapshot();

  console.log(JSON.stringify({
    ok: true,
    maintenance: {
      rawEventRetentionDays: RAW_EVENT_RETENTION_DAYS,
      observerRedactionMode: OBSERVER_REDACTION_MODE,
      scrubbedPayloads: result.updated,
      cutoffAt: result.cutoffAt,
    },
    metrics,
  }, null, 2));

  repository.close();
}

main();

const { withPgClient } = require("./postgres-utils");

async function main() {
  const result = await withPgClient((client) => client.query("SELECT current_database() AS database_name, current_user AS user_name, version() AS version"));
  const row = result.rows[0];
  console.log(JSON.stringify({
    ok: true,
    database: row.database_name,
    user: row.user_name,
    version: row.version,
  }, null, 2));
}

main().catch((error) => {
  console.error(error.message || error);
  process.exitCode = 1;
});

const { describe, it, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { createServer } = require("./server");

const TEST_DB = path.join(os.tmpdir(), `infrastruct-test-${Date.now()}.db`);
const BOOTSTRAP_PASSWORD = "TestPass123!";

function removeDbFiles(dbPath) {
  ["", "-wal", "-shm"].forEach((suffix) => {
    try { fs.rmSync(`${dbPath}${suffix}`, { force: true }); } catch (_) {}
  });
}

describe("Infrastruct API", () => {
  let runtime;
  let baseUrl;
  const sentNotifications = [];
  let adminSessionToken;
  let tenantAdminSessionToken;
  let employeeSessionToken;
  let deviceId;
  let ingestKey;
  let selfDeviceId;
  let employeeId;
  let invitedEmployeeSessionToken;
  let invitedEmployeeSecondSessionToken;
  let invitedEmployeeRotatedSessionToken;
  let postResetEmployeeSessionToken;
  let invitedEmployeeId;
  let invitedEmployeeInviteToken;
  let registeredCompanyAdminSessionToken;

  async function api(pathname, options = {}) {
    const headers = { "Content-Type": "application/json" };
    if (options.token) headers["X-Infrastruct-Session"] = options.token;
    const res = await fetch(`${baseUrl}${pathname}`, {
      method: options.method || "GET",
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
    const text = await res.text();
    return { status: res.status, data: text ? JSON.parse(text) : null, headers: res.headers };
  }

  before(async () => {
    removeDbFiles(TEST_DB);
    runtime = createServer({
      dbPath: TEST_DB,
      bootstrapPassword: BOOTSTRAP_PASSWORD,
      port: 0,
      notifier: {
        enabled: true,
        provider: "test",
        async sendEmployeeInvite(payload) {
          sentNotifications.push({ type: "invite", payload });
          return { ok: true, provider: "test", id: `invite-${sentNotifications.length}` };
        },
        async sendPasswordReset(payload) {
          sentNotifications.push({ type: "password-reset", payload });
          return { ok: true, provider: "test", id: `reset-${sentNotifications.length}` };
        },
      },
    });
    const result = await runtime.start();
    baseUrl = `http://${result.host}:${result.port}`;
  });

  after(async () => {
    await runtime.stop();
    removeDbFiles(TEST_DB);
  });

  it("GET /health returns 200", async () => {
    const { status, data } = await api("/health");
    assert.equal(status, 200);
    assert.equal(data.ok, true);
    assert.equal(data.service, "infrastruct-api");
  });

  it("GET /metrics returns backend totals", async () => {
    const { status, data } = await api("/metrics");
    assert.equal(status, 200);
    assert.ok(data.generatedAt);
    assert.ok(data.totals.organizations >= 3);
    assert.equal(data.retention.observerRedactionMode, "metadata");
  });

  it("GET /api/providers returns provider catalog", async () => {
    const { status, data } = await api("/api/providers");
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.providers));
    assert.ok(data.providers.length >= 3);
  });

  it("POST /api/auth/login fails with wrong password", async () => {
    const { status } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "dana@acme-logistics.com", password: "WrongPass!" },
    });
    assert.equal(status, 401);
  });

  it("POST /api/auth/login fails with unknown email", async () => {
    const { status } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "nobody@example.com", password: BOOTSTRAP_PASSWORD },
    });
    assert.equal(status, 401);
  });

  it("GET /api/auth/company-codes returns available registration codes", async () => {
    const { status, data } = await api("/api/auth/company-codes");
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.codes));
    assert.ok(data.codes.some((entry) => entry.code === "INFRA-TEAM-2026"));
  });

  it("GET /api/auth/demo-accounts returns seeded demo aliases", async () => {
    const { status, data } = await api("/api/auth/demo-accounts");
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.accounts));
    assert.ok(data.accounts.some((entry) => entry.alias === "example_admin"));
    assert.ok(data.accounts.some((entry) => entry.alias === "example_employee1"));
  });

  it("POST /api/auth/register-company provisions a new organization and session", async () => {
    const { status, data } = await api("/api/auth/register-company", {
      method: "POST",
      body: {
        registrationCode: "INFRA-TEAM-2026",
        companyName: "Cinder Systems",
        adminName: "Alex Dils",
        adminEmail: "alex@cinder-systems.com",
        password: "CinderAdmin123!",
      },
    });
    assert.equal(status, 201);
    assert.ok(data.sessionToken);
    assert.equal(data.organization.name, "Cinder Systems");
    assert.equal(data.user.email, "alex@cinder-systems.com");
    assert.equal(data.user.role, "admin");
    registeredCompanyAdminSessionToken = data.sessionToken;
  });

  it("POST /api/auth/register-company rejects a reused registration code", async () => {
    const { status } = await api("/api/auth/register-company", {
      method: "POST",
      body: {
        registrationCode: "INFRA-TEAM-2026",
        companyName: "Second Workspace",
        adminName: "Another Admin",
        adminEmail: "another@second-workspace.com",
        password: "SecondAdmin123!",
      },
    });
    assert.equal(status, 409);
  });

  it("POST /api/auth/login signs in the registered company admin without an org slug", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: {
        email: "alex@cinder-systems.com",
        password: "CinderAdmin123!",
      },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    assert.equal(data.organization.name, "Cinder Systems");
  });

  it("POST /api/auth/login succeeds with valid credentials", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "dana@acme-logistics.com", password: BOOTSTRAP_PASSWORD },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken, "sessionToken should be present");
    assert.ok(data.user);
    assert.equal(data.user.email, "dana@acme-logistics.com");
    adminSessionToken = data.sessionToken;
  });

  it("POST /api/auth/login accepts the example_admin demo alias", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { identifier: "example_admin", password: BOOTSTRAP_PASSWORD },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    assert.equal(data.user.email, "dana@acme-logistics.com");
  });

  it("POST /api/auth/login succeeds for a tenant-scoped admin", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: {
        email: "iris@northstar-freight.com",
        password: BOOTSTRAP_PASSWORD,
        orgSlug: "northstar-freight",
      },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    assert.equal(data.user.role, "admin");
    tenantAdminSessionToken = data.sessionToken;
  });

  it("GET /api/auth/session returns session info when authenticated", async () => {
    const { status, data, headers } = await api("/api/auth/session", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.user);
    assert.ok(data.expiresAt);
    assert.ok(headers.get("x-request-id"));
  });

  it("GET /api/workspace returns 401 without auth", async () => {
    const { status, data } = await api("/api/workspace");
    assert.equal(status, 401);
    assert.equal(data.error, "Authentication required");
  });

  it("GET /api/workspace returns snapshot when authenticated", async () => {
    const { status, data } = await api("/api/workspace", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.workspace);
    assert.ok(Array.isArray(data.users));
    assert.ok(Array.isArray(data.clients));
    assert.ok(Array.isArray(data.invites));
    assert.ok(Array.isArray(data.planRequests));
    assert.ok(data.clients.length >= 3);
    assert.ok(data.session);
  });

  it("GET /api/workspace does not expose global client hierarchy to tenant admins", async () => {
    const { status, data } = await api("/api/workspace", { token: tenantAdminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.clients));
    assert.equal(data.clients.length, 0);
  });

  it("GET /api/organizations returns org list", async () => {
    const { status, data } = await api("/api/organizations", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.organizations));
    assert.ok(data.organizations.length >= 3);
  });

  it("GET /api/clients returns client table data", async () => {
    const { status, data } = await api("/api/clients", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.clients));
    assert.ok(data.clients.length >= 3);
    assert.ok(data.clients.every((client) => typeof client.userCount === "number"));
    assert.ok(data.clients.every((client) => typeof client.actionCount === "number"));
  });

  it("GET /api/clients returns 403 for tenant admins", async () => {
    const { status } = await api("/api/clients", { token: tenantAdminSessionToken });
    assert.equal(status, 403);
  });

  it("GET /api/clients/:id returns client detail with users and actions", async () => {
    const { status, data } = await api("/api/clients/org-acme-logistics", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.client);
    assert.equal(data.client.id, "org-acme-logistics");
    assert.ok(Array.isArray(data.client.users));
    assert.ok(data.client.users.length >= 3);
    const employee = data.client.users.find((entry) => entry.role === "employee");
    assert.ok(employee);
    assert.ok(Array.isArray(employee.actions));
    assert.ok(employee.actions.length > 0);
  });

  it("GET /api/organizations/current returns current org", async () => {
    const { status, data } = await api("/api/organizations/current", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.organization.name);
    assert.ok(data.organization.plan);
  });

  it("GET /api/employees returns employee list", async () => {
    const { status, data } = await api("/api/employees", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.employees));
    assert.ok(data.employees.length > 0);
    employeeId = data.employees[0].id;
  });

  it("GET /api/employees/:id returns employee detail", async () => {
    const { status, data } = await api(`/api/employees/${employeeId}`, { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.employee);
    assert.equal(data.employee.id, employeeId);
    assert.ok(Array.isArray(data.employee.automations));
  });

  it("GET /api/employees/:id returns 404 for unknown id", async () => {
    const { status } = await api("/api/employees/does-not-exist", { token: adminSessionToken });
    assert.equal(status, 404);
  });

  it("POST /api/employees adds a new employee", async () => {
    const { status, data } = await api("/api/employees", {
      method: "POST",
      token: adminSessionToken,
      body: { name: "Test User", email: "test@acme-logistics.com", title: "Engineer", team: "Engineering" },
    });
    assert.equal(status, 201);
    assert.ok(data.users);
    assert.ok(data.invite);
    assert.ok(data.invite.inviteToken);
    invitedEmployeeId = data.invite.employeeId;
    invitedEmployeeInviteToken = data.invite.inviteToken;
  });

  it("POST /api/employees rejects duplicate email", async () => {
    const { status } = await api("/api/employees", {
      method: "POST",
      token: adminSessionToken,
      body: { name: "Another User", email: "test@acme-logistics.com", title: "Manager", team: "Ops" },
    });
    assert.equal(status, 400);
  });

  it("GET /api/invites returns pending invite list", async () => {
    const { status, data } = await api("/api/invites", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.invites));
    assert.ok(data.invites.some((invite) => invite.userId === invitedEmployeeId && invite.status === "pending"));
  });

  it("POST /api/employees triggers an invite notification", async () => {
    const inviteNotification = sentNotifications.find((entry) => entry.type === "invite" && entry.payload.email === "test@acme-logistics.com");
    assert.ok(inviteNotification);
    assert.equal(inviteNotification.payload.inviteToken, invitedEmployeeInviteToken);
  });

  it("GET /api/auth/invites/:token returns invite preview", async () => {
    const { status, data } = await api(`/api/auth/invites/${invitedEmployeeInviteToken}`);
    assert.equal(status, 200);
    assert.equal(data.invite.email, "test@acme-logistics.com");
    assert.equal(data.invite.name, "Test User");
  });

  it("POST /api/auth/login blocks invited employee before invite acceptance", async () => {
    const { status } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: BOOTSTRAP_PASSWORD },
    });
    assert.equal(status, 403);
  });

  it("POST /api/auth/accept-invite activates the invited employee", async () => {
    const { status, data } = await api("/api/auth/accept-invite", {
      method: "POST",
      body: {
        inviteToken: invitedEmployeeInviteToken,
        password: "InviteUser123!",
        label: "invite-onboarding",
      },
    });
    assert.equal(status, 201);
    assert.ok(data.sessionToken);
    assert.equal(data.user.email, "test@acme-logistics.com");
    invitedEmployeeSessionToken = data.sessionToken;
  });

  it("GET /api/auth/sessions returns the invited employee session", async () => {
    const { status, data } = await api("/api/auth/sessions", { token: invitedEmployeeSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.sessions));
    assert.equal(data.sessions.length, 1);
    assert.equal(data.sessions[0].status, "active");
    assert.equal(data.sessions[0].isCurrent, true);
  });

  it("POST /api/auth/login succeeds after invite acceptance", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: "InviteUser123!" },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    invitedEmployeeSecondSessionToken = data.sessionToken;
  });

  it("GET /api/auth/sessions shows multiple sessions for the invited employee", async () => {
    const { status, data } = await api("/api/auth/sessions", { token: invitedEmployeeSessionToken });
    assert.equal(status, 200);
    assert.ok(data.sessions.length >= 2);
  });

  it("POST /api/auth/password rotates the invited employee password and revokes other sessions", async () => {
    const { status, data } = await api("/api/auth/password", {
      method: "POST",
      token: invitedEmployeeSessionToken,
      body: {
        currentPassword: "InviteUser123!",
        newPassword: "InviteUser456!",
        revokeOtherSessions: true,
      },
    });
    assert.equal(status, 200);
    assert.equal(data.ok, true);
    assert.ok(data.revokedSessions >= 1);
  });

  it("GET /api/auth/session returns 404 for the revoked secondary invited-employee session", async () => {
    const { status } = await api("/api/auth/session", { token: invitedEmployeeSecondSessionToken });
    assert.equal(status, 404);
  });

  it("POST /api/auth/login rejects the old invited-employee password after rotation", async () => {
    const { status } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: "InviteUser123!" },
    });
    assert.equal(status, 401);
  });

  it("POST /api/auth/login accepts the new invited-employee password after rotation", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: "InviteUser456!" },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    invitedEmployeeRotatedSessionToken = data.sessionToken;
  });

  it("GET /api/auth/sessions allows admin to inspect another user's sessions", async () => {
    const { status, data } = await api(`/api/auth/sessions?userId=${encodeURIComponent(invitedEmployeeId)}`, {
      token: adminSessionToken,
    });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.sessions));
    assert.ok(data.sessions.some((session) => session.id));
  });

  it("GET /api/auth/sessions blocks employee access to another user's sessions", async () => {
    const { status } = await api(`/api/auth/sessions?userId=${encodeURIComponent("emp-maria")}`, {
      token: invitedEmployeeRotatedSessionToken,
    });
    assert.equal(status, 403);
  });

  it("POST /api/auth/sessions/revoke lets admin revoke an invited employee session", async () => {
    const { status: ownStatus, data: ownData } = await api("/api/auth/sessions", {
      token: invitedEmployeeRotatedSessionToken,
    });
    assert.equal(ownStatus, 200);
    const currentSession = ownData.sessions.find((session) => session.isCurrent);
    assert.ok(currentSession);

    const { status, data } = await api("/api/auth/sessions/revoke", {
      method: "POST",
      token: adminSessionToken,
      body: { sessionId: currentSession.id },
    });
    assert.equal(status, 200);
    assert.equal(data.ok, true);
  });

  it("GET /api/auth/session returns 404 for the admin-revoked invited-employee session", async () => {
    const { status } = await api("/api/auth/session", { token: invitedEmployeeRotatedSessionToken });
    assert.equal(status, 404);
  });

  it("POST /api/auth/password/reset/request creates a reset email", async () => {
    const { status, data } = await api("/api/auth/password/reset/request", {
      method: "POST",
      body: { email: "test@acme-logistics.com", orgSlug: "acme-logistics" },
    });
    assert.equal(status, 200);
    assert.equal(data.ok, true);
    const resetNotification = sentNotifications.findLast((entry) => entry.type === "password-reset" && entry.payload.email === "test@acme-logistics.com");
    assert.ok(resetNotification);
  });

  it("POST /api/auth/password/reset/confirm resets the password and creates a new session", async () => {
    const resetNotification = sentNotifications.findLast((entry) => entry.type === "password-reset" && entry.payload.email === "test@acme-logistics.com");
    const { status, data } = await api("/api/auth/password/reset/confirm", {
      method: "POST",
      body: { resetToken: resetNotification.payload.resetToken, newPassword: "InviteUser789!" },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    postResetEmployeeSessionToken = data.sessionToken;
  });

  it("POST /api/auth/login rejects the pre-reset password after password reset confirmation", async () => {
    const { status } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: "InviteUser456!" },
    });
    assert.equal(status, 401);
  });

  it("POST /api/auth/login accepts the reset password after password reset confirmation", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { email: "test@acme-logistics.com", password: "InviteUser789!" },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    postResetEmployeeSessionToken = data.sessionToken;
  });

  it("POST /api/consent updates consent status", async () => {
    const { status, data } = await api("/api/consent", {
      method: "POST",
      token: adminSessionToken,
      body: { employeeId, consentStatus: "approved" },
    });
    assert.equal(status, 200);
    assert.ok(data.workspace);
  });

  it("POST /api/automations/decision approves automation for admin", async () => {
    const { data } = await api(`/api/employees/${employeeId}`, { token: adminSessionToken });
    const auto = data.employee.automations[0];
    if (!auto) return;
    const { status } = await api("/api/automations/decision", {
      method: "POST",
      token: adminSessionToken,
      body: { employeeId, automationId: auto.id, actorRole: "admin", decision: "approved" },
    });
    assert.equal(status, 200);
  });

  it("POST /api/automations/state moves automation to pilot", async () => {
    const { data } = await api(`/api/employees/${employeeId}`, { token: adminSessionToken });
    const auto = data.employee.automations[0];
    if (!auto) return;
    const { status } = await api("/api/automations/state", {
      method: "POST",
      token: adminSessionToken,
      body: { employeeId, automationId: auto.id, state: "pilot" },
    });
    assert.equal(status, 200);
  });

  it("POST /api/automations/state rejects invalid state", async () => {
    const { data } = await api(`/api/employees/${employeeId}`, { token: adminSessionToken });
    const auto = data.employee.automations[0];
    if (!auto) return;
    const { status } = await api("/api/automations/state", {
      method: "POST",
      token: adminSessionToken,
      body: { employeeId, automationId: auto.id, state: "flying" },
    });
    assert.equal(status, 400);
  });

  it("POST /api/automations/refresh generates ranked recommendations", async () => {
    const { status, data } = await api("/api/automations/refresh", {
      method: "POST",
      token: adminSessionToken,
      body: { employeeId },
    });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.refreshed));
    assert.ok(data.refreshed[0].generatedCount >= 1);
  });

  it("GET /api/employees/:id returns generated automation metadata after refresh", async () => {
    const { status, data } = await api(`/api/employees/${employeeId}`, { token: adminSessionToken });
    assert.equal(status, 200);
    const generated = data.employee.automations.find((entry) => entry.source === "generated");
    assert.ok(generated);
    assert.ok(generated.confidenceScore >= 55);
    assert.ok(generated.rankScore > 0);
  });

  it("GET /api/automation-opportunities returns org-ranked generated opportunities", async () => {
    const { status, data } = await api("/api/automation-opportunities?limit=10", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.opportunities));
    assert.ok(data.opportunities.length >= 1);
    assert.ok(Array.isArray(data.runs));
    assert.ok(data.runs.length >= 1);
  });

  it("POST /api/devices/register registers a device", async () => {
    const { status, data } = await api("/api/devices/register", {
      method: "POST",
      token: adminSessionToken,
      body: { userId: employeeId, label: "Test Laptop", platform: "macos" },
    });
    assert.equal(status, 201);
    assert.ok(data.deviceId);
    assert.ok(data.ingestKey);
    deviceId = data.deviceId;
    ingestKey = data.ingestKey;
  });

  it("GET /api/organizations/current/devices returns device list", async () => {
    const { status, data } = await api("/api/organizations/current/devices", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.devices));
    assert.ok(data.devices.some((d) => d.id === deviceId));
  });

  it("POST /api/devices/register lets an employee register their own observer device", async () => {
    const { status, data } = await api("/api/devices/register", {
      method: "POST",
      token: postResetEmployeeSessionToken,
      body: { userId: invitedEmployeeId, label: "Invite Laptop", platform: "macos" },
    });
    assert.equal(status, 201);
    assert.ok(data.deviceId);
    selfDeviceId = data.deviceId;
  });

  it("POST /api/observer/events/batch ingests slack events", async () => {
    const { status, data } = await api("/api/observer/events/batch", {
      method: "POST",
      body: {
        deviceId,
        ingestKey,
        provider: "slack",
        events: [
          {
            id: "slack-test-1",
            userEmail: "maria@acme-logistics.com",
            timestamp: new Date().toISOString(),
            action: "message_routed",
            channelId: "C123",
            channelName: "general",
          },
        ],
      },
    });
    assert.equal(status, 202);
    assert.equal(data.inserted, 1);
  });

  it("POST /api/observer/local-events stores desktop observer samples", async () => {
    const startedAt = new Date().toISOString();
    const laterAt = new Date(Date.now() + 2 * 60 * 1000).toISOString();
    const { status, data } = await api("/api/observer/local-events", {
      method: "POST",
      token: postResetEmployeeSessionToken,
      body: {
        deviceId: selfDeviceId,
        events: [
          {
            sourceKey: "desktop-local-1",
            occurredAt: startedAt,
            appName: "Slack",
            appId: "com.tinyspeck.slackmacgap",
            windowTitle: "Customer escalations",
            screenType: "channel",
            semanticAction: "switch-app",
            workflowHint: "coordinate-in-slack",
            confidenceScore: 0.88,
            cursorX: 240,
            cursorY: 150,
            clickCount: 0,
            inputMode: "screen-sampling",
            captureReason: "startup",
            screenSummary: { captureStatus: "captured", displayLabel: "Built-in Retina Display" },
            transcript: [
              { kind: "window", occurredAt: startedAt, value: "Slack -> Customer escalations" },
              { kind: "keystroke", occurredAt: startedAt, value: "cmd+k" },
            ],
            description: "Switched into Slack in Customer escalations.",
          },
          {
            sourceKey: "desktop-local-2",
            occurredAt: laterAt,
            appName: "Slack",
            appId: "com.tinyspeck.slackmacgap",
            windowTitle: "Customer escalations",
            screenType: "thread",
            semanticAction: "screen-change",
            workflowHint: "resolve-thread",
            confidenceScore: 0.77,
            cursorX: 288,
            cursorY: 412,
            clickCount: 0,
            inputMode: "screen-sampling",
            captureReason: "interval",
            screenSummary: { captureStatus: "captured", displayLabel: "Built-in Retina Display" },
            transcript: [
              { kind: "keystroke", occurredAt: laterAt, value: "a" },
              { kind: "keystroke", occurredAt: laterAt, value: "b" },
            ],
            description: "Worked through a thread screen in Slack.",
          },
        ],
      },
    });
    assert.equal(status, 202);
    assert.equal(data.inserted, 2);
    assert.ok(Array.isArray(data.workflows));
    assert.ok(data.workflows.length >= 1);
    assert.ok(Array.isArray(data.workflows[0].transcript));
    assert.ok(data.workflows[0].transcript.some((entry) => entry.value === "Slack -> Customer escalations"));
  });

  it("POST /api/observer/events/batch stores redacted payloads", async () => {
    const row = runtime.repository.db.prepare(`
      SELECT payload_json
      FROM observed_actions
      WHERE source = 'slack' AND source_key = 'slack-test-1'
    `).get();
    assert.ok(row);
    const payload = JSON.parse(row.payload_json);
    assert.equal(payload._redacted, true);
    assert.equal(payload.provider, "slack");
    assert.equal("channelId" in payload, false);
  });

  it("POST /api/observer/events/batch rejects invalid device credentials", async () => {
    const { status } = await api("/api/observer/events/batch", {
      method: "POST",
      body: {
        deviceId,
        ingestKey: "ingest_badkey",
        provider: "slack",
        events: [{ id: "bad-1", userEmail: "x@x.com", timestamp: new Date().toISOString() }],
      },
    });
    assert.equal(status, 401);
  });

  it("POST /api/observer/events/batch deduplicates events", async () => {
    const { status, data } = await api("/api/observer/events/batch", {
      method: "POST",
      body: {
        deviceId,
        ingestKey,
        provider: "slack",
        events: [
          {
            id: "slack-test-1",
            userEmail: "maria@acme-logistics.com",
            timestamp: new Date().toISOString(),
            action: "message_routed",
            channelId: "C123",
          },
        ],
      },
    });
    assert.equal(status, 202);
    assert.equal(data.inserted, 0);
    assert.equal(data.duplicates, 1);
  });

  it("POST /api/devices/revoke revokes a device", async () => {
    const { status, data } = await api("/api/devices/revoke", {
      method: "POST",
      token: adminSessionToken,
      body: { deviceId },
    });
    assert.equal(status, 200);
    assert.equal(data.ok, true);
    const revoked = data.devices.find((device) => device.id === deviceId);
    assert.equal(revoked.status, "revoked");
  });

  it("POST /api/observer/events/batch rejects ingest for a revoked device", async () => {
    const { status } = await api("/api/observer/events/batch", {
      method: "POST",
      body: {
        deviceId,
        ingestKey,
        provider: "slack",
        events: [
          {
            id: "slack-test-after-revoke",
            userEmail: "maria@acme-logistics.com",
            timestamp: new Date().toISOString(),
            action: "message_routed",
            channelId: "C999",
          },
        ],
      },
    });
    assert.equal(status, 401);
  });

  it("GET /api/observer/events returns observed actions", async () => {
    const { status, data } = await api("/api/observer/events?limit=10", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.events));
  });

  it("GET /api/observer/events filters by provider", async () => {
    const { status, data } = await api("/api/observer/events?provider=slack&limit=5", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.events.every((e) => e.source === "slack"));
  });

  it("GET /api/observer/events limits employees to their own recorded actions", async () => {
    const { status, data } = await api("/api/observer/events?limit=20", { token: postResetEmployeeSessionToken });
    assert.equal(status, 200);
    assert.ok(data.events.every((event) => event.userId === invitedEmployeeId));
  });

  it("GET /api/observer/workflows returns inferred workflow sessions", async () => {
    const { status, data } = await api(`/api/observer/workflows?employeeId=${encodeURIComponent(invitedEmployeeId)}&limit=5`, {
      token: adminSessionToken,
    });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.workflows));
    assert.ok(data.workflows.length >= 1);
    assert.equal(data.workflows[0].userId, invitedEmployeeId);
  });

  it("POST /api/organizations/current/integrations connects integration", async () => {
    const { status, data } = await api("/api/organizations/current/integrations", {
      method: "POST",
      token: adminSessionToken,
      body: {
        provider: "figma",
        displayName: "Figma (Test)",
        connectionMode: "oauth",
        scopes: ["files:read"],
        externalAccountRef: "figma-test-account",
      },
    });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.integrations));
    const figma = data.integrations.find((i) => i.provider === "figma");
    assert.equal(figma.status, "connected");
  });

  it("GET /api/organizations/current/integrations returns integration list", async () => {
    const { status, data } = await api("/api/organizations/current/integrations", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.integrations));
    assert.ok(data.integrations.length >= 2);
  });

  it("GET /api/audit-events returns audit trail", async () => {
    const { status, data } = await api("/api/audit-events", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.events));
    assert.ok(data.events.length > 0);
  });

  it("POST /api/plan-requests records an upgrade request", async () => {
    const { status, data } = await api("/api/plan-requests", {
      method: "POST",
      token: adminSessionToken,
      body: { requestType: "upgrade", requestedPlan: "Scale", note: "Need more seats for onboarding." },
    });
    assert.equal(status, 201);
    assert.ok(Array.isArray(data.planRequests));
    assert.ok(data.planRequests.some((request) => request.requestType === "upgrade" && request.requestedPlan === "Scale"));
  });

  it("GET /api/reports returns all employee reports", async () => {
    const { status, data } = await api("/api/reports", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(Array.isArray(data.reports));
    assert.ok(data.reports.length > 0);
    assert.ok(data.reports[0].headline);
  });

  it("GET /api/reports/:employeeId returns single report", async () => {
    const { status, data } = await api(`/api/reports/${employeeId}`, { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.report);
    assert.equal(data.report.employeeId, employeeId);
    assert.ok(Array.isArray(data.report.findings));
  });

  it("GET /api/reports/:employeeId?format=csv returns CSV", async () => {
    const res = await fetch(`${baseUrl}/api/reports/${employeeId}?format=csv`, {
      headers: { "X-Infrastruct-Session": adminSessionToken },
    });
    assert.equal(res.status, 200);
    assert.ok(res.headers.get("content-type").includes("text/csv"));
    const text = await res.text();
    assert.ok(text.includes("Employee"));
    assert.ok(text.includes("Reclaimable Hours"));
  });

  it("GET /api/audit-events includes report access activity", async () => {
    const { status, data } = await api("/api/audit-events?limit=100", { token: adminSessionToken });
    assert.equal(status, 200);
    assert.ok(data.events.some((event) => event.eventType === "report.accessed"));
  });

  it("POST /api/auth/login succeeds for employee", async () => {
    const { status, data } = await api("/api/auth/login", {
      method: "POST",
      body: { identifier: "example_employee1", password: BOOTSTRAP_PASSWORD },
    });
    assert.equal(status, 200);
    assert.ok(data.sessionToken);
    employeeSessionToken = data.sessionToken;
  });

  it("GET /api/workspace scopes employee user data to the signed-in account", async () => {
    const { status, data } = await api("/api/workspace", { token: employeeSessionToken });
    assert.equal(status, 200);
    assert.equal(data.users.length, 1);
    assert.equal(data.users[0].email, "maria@acme-logistics.com");
  });

  it("GET /api/employees returns 403 for employee role", async () => {
    const { status } = await api("/api/employees", { token: employeeSessionToken });
    assert.equal(status, 403);
  });

  it("GET /api/reports/:employeeId allows employee to read own report", async () => {
    const { status, data } = await api("/api/reports/emp-maria", { token: employeeSessionToken });
    assert.equal(status, 200);
    assert.equal(data.report.employeeId, "emp-maria");
  });

  it("GET /api/reports/:employeeId denies employee access to another employee report", async () => {
    const { status } = await api("/api/reports/emp-rhea", { token: employeeSessionToken });
    assert.equal(status, 403);
  });

  it("POST /api/automations/decision denies employee writes for another employee", async () => {
    const { data } = await api("/api/employees/emp-rhea", { token: adminSessionToken });
    const auto = data.employee.automations[0];
    if (!auto) return;
    const { status } = await api("/api/automations/decision", {
      method: "POST",
      token: employeeSessionToken,
      body: { employeeId: "emp-rhea", automationId: auto.id, actorRole: "employee", decision: "accepted" },
    });
    assert.equal(status, 403);
  });

  it("POST /api/auth/logout revokes session", async () => {
    const { status, data } = await api("/api/auth/logout", {
      method: "POST",
      token: adminSessionToken,
      body: { sessionToken: adminSessionToken },
    });
    assert.equal(status, 200);
    assert.equal(data.ok, true);
  });

  it("GET /api/auth/session returns 404 after logout", async () => {
    const { status } = await api("/api/auth/session", { token: adminSessionToken });
    assert.equal(status, 404);
  });

  it("GET /health still returns 200 after logout", async () => {
    const { status } = await api("/health");
    assert.equal(status, 200);
  });
});

const fs = require("fs");
const path = require("path");
const { randomUUID } = require("crypto");
const { DatabaseSync } = require("node:sqlite");
const { createSeedWorkspace } = require("../seed-data");
const { normalizeObserverEvents, redactObserverEvent, PROVIDERS } = require("./provider-adapters");
const { buildRecommendationPackage } = require("./recommendation-engine");
const { createOpaqueToken, createPasswordRecord, hashToken, verifyPassword } = require("./security");

const DEFAULT_SESSION_TTL_DAYS = 30;
const LATEST_SCHEMA_VERSION = 7;
const DEFAULT_OBSERVED_APPS = createSeedWorkspace().workspace.observedApps;

function createCompanyRegistrationCatalog() {
  return [
    {
      id: "reg-team-2026",
      code: "INFRA-TEAM-2026",
      label: "Team pilot access",
      planName: "Team",
      seatLimit: 25,
      approvalSla: "< 5 min",
      deploymentMode: "Desktop observer + admin console",
      auditCycleDays: 14,
      observedApps: DEFAULT_OBSERVED_APPS,
    },
    {
      id: "reg-scale-2026",
      code: "INFRA-SCALE-2026",
      label: "Scale rollout access",
      planName: "Scale",
      seatLimit: 40,
      approvalSla: "< 10 min",
      deploymentMode: "Desktop observer + supervised automations",
      auditCycleDays: 21,
      observedApps: DEFAULT_OBSERVED_APPS,
    },
    {
      id: "reg-enterprise-2026",
      code: "INFRA-ENTERPRISE-2026",
      label: "Enterprise deployment access",
      planName: "Enterprise",
      seatLimit: 60,
      approvalSla: "< 15 min",
      deploymentMode: "Desktop observer + policy approvals",
      auditCycleDays: 30,
      observedApps: DEFAULT_OBSERVED_APPS,
    },
  ];
}

const DEMO_LOGIN_ALIASES = [
  { alias: "example_admin", email: "dana@acme-logistics.com", label: "Admin demo console" },
  { alias: "example_employee1", email: "maria@acme-logistics.com", label: "Employee demo 1" },
  { alias: "example_employee2", email: "owen@acme-logistics.com", label: "Employee demo 2" },
  { alias: "example_employee3", email: "rhea@acme-logistics.com", label: "Employee demo 3" },
];

function slugify(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function buildError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function nowIso() {
  return new Date().toISOString();
}

function addDays(dateString, days) {
  const date = new Date(dateString);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString();
}

function minutesBetween(start, end) {
  return Math.max(0, Math.round((new Date(end).valueOf() - new Date(start).valueOf()) / 60000));
}

function subtractDays(date, days) {
  const next = new Date(date);
  next.setUTCDate(next.getUTCDate() - days);
  return next;
}

function isSupportRole(role) {
  return role === "support";
}

function isElevatedRole(role) {
  return role === "admin" || isSupportRole(role);
}

function parseJsonSafe(value, fallback = {}) {
  if (!value) {
    return fallback;
  }

  try {
    return JSON.parse(value);
  } catch (_error) {
    return fallback;
  }
}

function formatStatus(value) {
  return String(value || "")
    .split("-")
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function createSeedClientCatalog(primaryWorkspaceState) {
  return [
    {
      orgId: "org-acme-logistics",
      workspace: primaryWorkspaceState.workspace,
      sessionUserId: primaryWorkspaceState.session.currentUserId,
      users: primaryWorkspaceState.users,
      integrations: [
        {
          id: "int-google",
          provider: "gmail",
          displayName: "Google Workspace / Gmail",
          status: "connected",
          connectionMode: "oauth",
          scopes: PROVIDERS.gmail.scopes,
          healthStatus: "healthy",
          externalAccountRef: "google-workspace-acme",
          connectedByUserId: "admin-1",
          lastSyncAt: "2026-04-21T16:18:00.000Z",
        },
        {
          id: "int-slack",
          provider: "slack",
          displayName: "Slack",
          status: "connected",
          connectionMode: "oauth",
          scopes: PROVIDERS.slack.scopes,
          healthStatus: "healthy",
          externalAccountRef: "acme-slack-workspace",
          connectedByUserId: "admin-1",
          lastSyncAt: "2026-04-21T16:20:00.000Z",
        },
        {
          id: "int-figma",
          provider: "figma",
          displayName: "Figma",
          status: "configured",
          connectionMode: "oauth",
          scopes: PROVIDERS.figma.scopes,
          healthStatus: "awaiting-credentials",
          externalAccountRef: null,
          connectedByUserId: "admin-1",
          lastSyncAt: null,
        },
      ],
      auditEvents: [
        {
          id: "evt-seed-consent-maria",
          createdAt: "2026-04-21T16:02:00.000Z",
          actorUserId: "admin-1",
          actorName: "Dana Rowan",
          targetUserId: "emp-maria",
          eventType: "consent.updated",
          summary: "Observation consent approved for Maria Larsen.",
          metadata: { consentStatus: "approved" },
        },
        {
          id: "evt-seed-automation-maria",
          createdAt: "2026-04-21T16:08:00.000Z",
          actorUserId: "admin-1",
          actorName: "Dana Rowan",
          targetUserId: "emp-maria",
          eventType: "automation.updated",
          summary: "Pipeline reconciliation moved into active rollout for Maria Larsen.",
          metadata: { automationId: "auto-1002", status: "active" },
        },
        {
          id: "evt-seed-integration-slack",
          createdAt: "2026-04-21T16:20:00.000Z",
          actorUserId: "admin-1",
          actorName: "Dana Rowan",
          targetUserId: null,
          eventType: "integration.connected",
          summary: "Slack workspace connection is configured for Acme Logistics.",
          metadata: { provider: "slack" },
        },
      ],
    },
    {
      orgId: "org-northstar-freight",
      workspace: {
        name: "Northstar Freight",
        plan: {
          name: "Scale",
          seatLimit: 40,
          seatsUsed: 3,
          approvalSla: "< 10 min",
          deploymentMode: "Desktop observer + supervised automations",
          auditCycleDays: 21,
        },
        observedApps: ["Gmail", "Slack", "Salesforce", "Sheets", "Drive", "Calendar", "Zoom", "Notion"],
      },
      users: [
        {
          id: "admin-northstar",
          role: "admin",
          name: "Iris Kane",
          title: "Client Operations Director",
          email: "iris@northstar-freight.com",
        },
        {
          id: "emp-northstar-ada",
          role: "employee",
          name: "Ada Jimenez",
          title: "Account Manager",
          team: "Accounts",
          email: "ada@northstar-freight.com",
          status: "observing",
          consentStatus: "approved",
          lastSeen: "Active 6 min ago",
          reclaimableHours: 9.3,
          automationReadiness: 88,
          profileSummary: [
            "Builds the same shipment update email threads each morning.",
            "Copies status changes from Gmail into Salesforce and a weekly sheet.",
            "Prefers review-first drafts before any customer-facing send.",
          ],
          apps: ["Gmail", "Salesforce", "Sheets", "Slack"],
          actions: [
            {
              id: "act-northstar-1001",
              timestamp: "2026-04-21 08:11",
              app: "Gmail",
              category: "Automatable",
              description: "Drafted seven shipment delay updates with the same structure and attachments.",
            },
            {
              id: "act-northstar-1002",
              timestamp: "2026-04-21 09:28",
              app: "Salesforce",
              category: "Repetitive",
              description: "Updated account delivery statuses after reading the same carrier thread.",
            },
            {
              id: "act-northstar-1003",
              timestamp: "2026-04-21 11:05",
              app: "Sheets",
              category: "Agent fit",
              description: "Copied shipment exceptions into a weekly escalation tracker.",
            },
          ],
          access: [
            {
              id: "acc-northstar-1001",
              app: "Google Workspace",
              method: "OAuth",
              status: "Scoped token",
              visibility: "Masked",
              updatedAt: "today",
            },
            {
              id: "acc-northstar-1002",
              app: "Salesforce",
              method: "SSO",
              status: "Managed token",
              visibility: "Masked",
              updatedAt: "today",
            },
          ],
          automations: [
            {
              id: "auto-northstar-1001",
              name: "Shipment update drafts",
              scope: "Gmail + Salesforce",
              mode: "Draft then approve",
              impact: "3.6h / wk",
              status: "review",
              employeeDecision: "accepted",
              adminDecision: "approved",
              summary: "Draft customer shipment updates and stage CRM status changes for approval.",
            },
          ],
          report: {
            headline: "9.3 reclaimable hours each week by standardizing shipment update handling.",
            findings: [
              "The same outbound update pattern appears across customer accounts every morning.",
              "A draft-first automation can remove manual copying without risking autonomous sends.",
            ],
          },
        },
        {
          id: "emp-northstar-rui",
          role: "employee",
          name: "Rui Patel",
          title: "Dispatch Coordinator",
          team: "Dispatch",
          email: "rui@northstar-freight.com",
          status: "profiling",
          consentStatus: "approved",
          lastSeen: "Active 17 min ago",
          reclaimableHours: 7.1,
          automationReadiness: 79,
          profileSummary: [
            "Moves the same Slack dispatch notes into a shared status board.",
            "Needs explicit approval when automations touch carrier-facing communication.",
          ],
          apps: ["Slack", "Sheets", "Calendar"],
          actions: [
            {
              id: "act-northstar-2001",
              timestamp: "2026-04-21 07:52",
              app: "Slack",
              category: "Repetitive",
              description: "Collected route updates from four dispatch channels into one summary.",
            },
            {
              id: "act-northstar-2002",
              timestamp: "2026-04-21 10:19",
              app: "Sheets",
              category: "Automatable",
              description: "Moved route exception notes into the same board columns used every day.",
            },
          ],
          access: [
            {
              id: "acc-northstar-2001",
              app: "Slack",
              method: "Workspace app",
              status: "Installed",
              visibility: "Masked",
              updatedAt: "today",
            },
          ],
          automations: [
            {
              id: "auto-northstar-2001",
              name: "Dispatch summary builder",
              scope: "Slack + Sheets",
              mode: "Request approval",
              impact: "2.4h / wk",
              status: "proposed",
              employeeDecision: "pending",
              adminDecision: "pending",
              summary: "Compile route notes into the dispatch board and stage an approval summary.",
            },
          ],
          report: {
            headline: "7.1 reclaimable hours each week through dispatch note consolidation.",
            findings: [
              "The same dispatch notes are rewritten into a board multiple times per day.",
            ],
          },
        },
      ],
      integrations: [
        {
          id: "int-northstar-google",
          provider: "gmail",
          displayName: "Northstar Gmail",
          status: "connected",
          connectionMode: "oauth",
          scopes: PROVIDERS.gmail.scopes,
          healthStatus: "healthy",
          externalAccountRef: "northstar-google",
          connectedByUserId: "admin-northstar",
          lastSyncAt: "2026-04-21T15:12:00.000Z",
        },
        {
          id: "int-northstar-slack",
          provider: "slack",
          displayName: "Northstar Slack",
          status: "connected",
          connectionMode: "oauth",
          scopes: PROVIDERS.slack.scopes,
          healthStatus: "healthy",
          externalAccountRef: "northstar-slack",
          connectedByUserId: "admin-northstar",
          lastSyncAt: "2026-04-21T15:18:00.000Z",
        },
      ],
      auditEvents: [
        {
          id: "evt-northstar-automation",
          createdAt: "2026-04-21T15:25:00.000Z",
          actorUserId: "admin-northstar",
          actorName: "Iris Kane",
          targetUserId: "emp-northstar-ada",
          eventType: "automation.updated",
          summary: "Shipment update drafts moved into review for Ada Jimenez.",
          metadata: { automationId: "auto-northstar-1001", status: "review" },
        },
      ],
    },
    {
      orgId: "org-harbor-health",
      workspace: {
        name: "Harbor Health Partners",
        plan: {
          name: "Enterprise",
          seatLimit: 60,
          seatsUsed: 3,
          approvalSla: "< 15 min",
          deploymentMode: "Desktop observer + policy approvals",
          auditCycleDays: 30,
        },
        observedApps: ["Gmail", "Slack", "Figma", "Docs", "Notion", "Calendar", "Drive", "Intercom"],
      },
      users: [
        {
          id: "admin-harbor",
          role: "admin",
          name: "Sonia Bell",
          title: "Transformation Lead",
          email: "sonia@harbor-health.com",
        },
        {
          id: "emp-harbor-mika",
          role: "employee",
          name: "Mika Chen",
          title: "Patient Support Lead",
          team: "Support",
          email: "mika@harbor-health.com",
          status: "observing",
          consentStatus: "approved",
          lastSeen: "Active 4 min ago",
          reclaimableHours: 10.2,
          automationReadiness: 90,
          profileSummary: [
            "Turns repeat patient follow-up requests into the same response templates.",
            "Creates internal handoff notes after every support escalation.",
          ],
          apps: ["Gmail", "Docs", "Intercom", "Slack"],
          actions: [
            {
              id: "act-harbor-1001",
              timestamp: "2026-04-21 08:34",
              app: "Intercom",
              category: "Automatable",
              description: "Triaged six support conversations using the same escalation rules.",
            },
            {
              id: "act-harbor-1002",
              timestamp: "2026-04-21 09:43",
              app: "Docs",
              category: "Repetitive",
              description: "Compiled follow-up notes into the same internal case summary template.",
            },
            {
              id: "act-harbor-1003",
              timestamp: "2026-04-21 11:12",
              app: "Gmail",
              category: "Agent fit",
              description: "Prepared patient follow-up replies from a standard decision tree.",
            },
          ],
          access: [
            {
              id: "acc-harbor-1001",
              app: "Google Workspace",
              method: "OAuth",
              status: "Scoped token",
              visibility: "Masked",
              updatedAt: "today",
            },
            {
              id: "acc-harbor-1002",
              app: "Intercom",
              method: "Workspace app",
              status: "Installed",
              visibility: "Masked",
              updatedAt: "today",
            },
          ],
          automations: [
            {
              id: "auto-harbor-1001",
              name: "Patient follow-up drafts",
              scope: "Intercom + Gmail",
              mode: "Draft then approve",
              impact: "4.4h / wk",
              status: "pilot",
              employeeDecision: "accepted",
              adminDecision: "approved",
              summary: "Draft support follow-ups and compile internal case notes with approval checkpoints.",
            },
          ],
          report: {
            headline: "10.2 reclaimable hours each week if support follow-up drafting is standardized.",
            findings: [
              "Support agents repeat the same escalation notes and outbound reply patterns.",
              "A supervised drafting flow is the right first automation boundary.",
            ],
          },
        },
        {
          id: "emp-harbor-noah",
          role: "employee",
          name: "Noah Rivera",
          title: "Design Program Manager",
          team: "Design Ops",
          email: "noah@harbor-health.com",
          status: "profiling",
          consentStatus: "approved",
          lastSeen: "Active 21 min ago",
          reclaimableHours: 5.8,
          automationReadiness: 73,
          profileSummary: [
            "Moves the same Figma review notes into Docs and Slack after each design review.",
          ],
          apps: ["Figma", "Docs", "Slack"],
          actions: [
            {
              id: "act-harbor-2001",
              timestamp: "2026-04-21 10:07",
              app: "Figma",
              category: "Repetitive",
              description: "Collected component review notes from the same review checklist.",
            },
            {
              id: "act-harbor-2002",
              timestamp: "2026-04-21 12:16",
              app: "Slack",
              category: "Automatable",
              description: "Posted review outcomes to two team channels with the same summary shape.",
            },
          ],
          access: [
            {
              id: "acc-harbor-2001",
              app: "Figma",
              method: "OAuth",
              status: "Scoped token",
              visibility: "Masked",
              updatedAt: "today",
            },
          ],
          automations: [
            {
              id: "auto-harbor-2001",
              name: "Design review recap",
              scope: "Figma + Docs + Slack",
              mode: "Request approval",
              impact: "2.2h / wk",
              status: "proposed",
              employeeDecision: "pending",
              adminDecision: "approved",
              summary: "Summarize design review notes and prepare the same recap for docs and Slack.",
            },
          ],
          report: {
            headline: "5.8 reclaimable hours each week from standardized review recaps.",
            findings: [
              "Review recaps repeat the same structure across channels and tools.",
            ],
          },
        },
      ],
      integrations: [
        {
          id: "int-harbor-google",
          provider: "gmail",
          displayName: "Harbor Gmail",
          status: "connected",
          connectionMode: "oauth",
          scopes: PROVIDERS.gmail.scopes,
          healthStatus: "healthy",
          externalAccountRef: "harbor-google",
          connectedByUserId: "admin-harbor",
          lastSyncAt: "2026-04-21T14:50:00.000Z",
        },
        {
          id: "int-harbor-figma",
          provider: "figma",
          displayName: "Harbor Figma",
          status: "configured",
          connectionMode: "oauth",
          scopes: PROVIDERS.figma.scopes,
          healthStatus: "healthy",
          externalAccountRef: "harbor-figma",
          connectedByUserId: "admin-harbor",
          lastSyncAt: "2026-04-21T15:02:00.000Z",
        },
      ],
      auditEvents: [
        {
          id: "evt-harbor-consent",
          createdAt: "2026-04-21T14:58:00.000Z",
          actorUserId: "admin-harbor",
          actorName: "Sonia Bell",
          targetUserId: "emp-harbor-mika",
          eventType: "consent.updated",
          summary: "Observation consent approved for Mika Chen.",
          metadata: { consentStatus: "approved" },
        },
      ],
    },
  ];
}

class WorkspaceRepository {
  constructor(dbPath, options = {}) {
    this.dbPath = dbPath;
    this.db = null;
    this.bootstrapPassword = options.bootstrapPassword || "ChangeMe123!";
    this.sessionTtlDays = options.sessionTtlDays || DEFAULT_SESSION_TTL_DAYS;
    this.observerRedactionMode = options.observerRedactionMode || "metadata";
    this.rawEventRetentionDays = Number.isFinite(options.rawEventRetentionDays)
      ? options.rawEventRetentionDays
      : 14;
  }

  init() {
    if (this.db) {
      return;
    }

    fs.mkdirSync(path.dirname(this.dbPath), { recursive: true });
    this.db = new DatabaseSync(this.dbPath);
    this.db.exec("PRAGMA foreign_keys = ON;");
    this.db.exec("PRAGMA journal_mode = WAL;");

    if (this.isLegacySchema()) {
      this.resetSchema();
    }

    this.createSchema();
    this.runMigrations();
    this.applyObservedActionRetention();

    const organization = this.db.prepare("SELECT id FROM organizations LIMIT 1").get();
    if (!organization) {
      this.seed(createSeedWorkspace());
    } else {
      this.seedAdditionalClients();
      this.backfillSupportOperator();
    }

    this.seedCompanyRegistrationCodes();
    this.seedDemoLoginAliases();
  }

  close() {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  createSchema() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS organizations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        plan_name TEXT NOT NULL,
        seat_limit INTEGER NOT NULL,
        seats_used INTEGER NOT NULL,
        approval_sla TEXT NOT NULL,
        deployment_mode TEXT NOT NULL,
        audit_cycle_days INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS organization_observed_apps (
        org_id TEXT NOT NULL,
        sort_order INTEGER NOT NULL,
        name TEXT NOT NULL,
        PRIMARY KEY (org_id, sort_order),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        title TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        team TEXT,
        status TEXT,
        consent_status TEXT,
        last_seen TEXT,
        reclaimable_hours REAL DEFAULT 0,
        automation_readiness INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS memberships (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        role TEXT NOT NULL,
        status TEXT NOT NULL,
        sort_order INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (org_id, user_id),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS auth_accounts (
        user_id TEXT PRIMARY KEY,
        password_salt TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        must_rotate_password INTEGER NOT NULL DEFAULT 1,
        last_login_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS api_sessions (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        membership_role TEXT NOT NULL,
        token_hash TEXT NOT NULL UNIQUE,
        label TEXT,
        created_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        revoked_at TEXT,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS local_session_state (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        org_id TEXT NOT NULL,
        current_user_id TEXT NOT NULL,
        current_role TEXT NOT NULL,
        current_session_token TEXT,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (current_user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS employee_invites (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        email TEXT NOT NULL,
        name TEXT NOT NULL,
        title TEXT NOT NULL,
        team TEXT NOT NULL,
        role TEXT NOT NULL,
        invite_token_hash TEXT NOT NULL UNIQUE,
        invited_by_user_id TEXT,
        created_at TEXT NOT NULL,
        accepted_at TEXT,
        expires_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (invited_by_user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        token_hash TEXT NOT NULL UNIQUE,
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used_at TEXT,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS device_installs (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        label TEXT NOT NULL,
        platform TEXT NOT NULL,
        status TEXT NOT NULL,
        ingest_key_hash TEXT NOT NULL UNIQUE,
        created_at TEXT NOT NULL,
        last_seen_at TEXT,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS integrations (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        provider TEXT NOT NULL,
        display_name TEXT NOT NULL,
        status TEXT NOT NULL,
        connection_mode TEXT NOT NULL,
        scopes_json TEXT NOT NULL,
        health_status TEXT NOT NULL,
        external_account_ref TEXT,
        connected_by_user_id TEXT,
        last_sync_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        UNIQUE (org_id, provider),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (connected_by_user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS profile_points (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        sort_order INTEGER NOT NULL,
        content TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'manual',
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS user_apps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        sort_order INTEGER NOT NULL,
        app_name TEXT NOT NULL,
        UNIQUE (org_id, user_id, app_name),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS observed_actions (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        occurred_at TEXT NOT NULL,
        source TEXT NOT NULL,
        source_key TEXT NOT NULL,
        app_name TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE (org_id, source, source_key),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS access_records (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        app_name TEXT NOT NULL,
        method TEXT NOT NULL,
        status TEXT NOT NULL,
        visibility TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS automations (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL,
        scope TEXT NOT NULL,
        mode TEXT NOT NULL,
        impact TEXT NOT NULL,
        status TEXT NOT NULL,
        employee_decision TEXT NOT NULL,
        admin_decision TEXT NOT NULL,
        summary TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'seeded',
        confidence_score REAL NOT NULL DEFAULT 0,
        projected_hours REAL NOT NULL DEFAULT 0,
        rank_score REAL NOT NULL DEFAULT 0,
        rationale TEXT NOT NULL DEFAULT '',
        generated_at TEXT,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS reports (
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        headline TEXT NOT NULL,
        PRIMARY KEY (org_id, user_id),
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS report_findings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        sort_order INTEGER NOT NULL,
        finding TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'manual',
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS recommendation_runs (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        observed_action_count INTEGER NOT NULL,
        generated_count INTEGER NOT NULL,
        total_projected_hours REAL NOT NULL,
        automation_readiness INTEGER NOT NULL,
        trace_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS audit_events (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        actor_user_id TEXT,
        actor_name TEXT NOT NULL,
        target_user_id TEXT,
        event_type TEXT NOT NULL,
        summary TEXT NOT NULL,
        metadata_json TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS company_registration_codes (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL UNIQUE,
        label TEXT NOT NULL,
        plan_name TEXT NOT NULL,
        seat_limit INTEGER NOT NULL,
        approval_sla TEXT NOT NULL,
        deployment_mode TEXT NOT NULL,
        audit_cycle_days INTEGER NOT NULL,
        observed_apps_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        claimed_at TEXT,
        claimed_org_id TEXT,
        claimed_by_user_id TEXT,
        FOREIGN KEY (claimed_org_id) REFERENCES organizations(id) ON DELETE SET NULL,
        FOREIGN KEY (claimed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS demo_login_aliases (
        alias TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        label TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS plan_change_requests (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        requested_by_user_id TEXT NOT NULL,
        request_type TEXT NOT NULL,
        requested_plan TEXT,
        note TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS workflow_sessions (
        id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        device_id TEXT,
        source TEXT NOT NULL,
        workflow_label TEXT NOT NULL,
        primary_app TEXT NOT NULL,
        screen_type TEXT NOT NULL,
        confidence_score REAL NOT NULL DEFAULT 0,
        started_at TEXT NOT NULL,
        ended_at TEXT NOT NULL,
        step_count INTEGER NOT NULL DEFAULT 0,
        click_count INTEGER NOT NULL DEFAULT 0,
        evidence_json TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (device_id) REFERENCES device_installs(id) ON DELETE SET NULL
      );
    `);
  }

  isLegacySchema() {
    const hasWorkspaceTable = this.tableExists("workspace");
    const hasLegacySessionTable = this.tableExists("session_state");
    const hasUsersTable = this.tableExists("users");

    if (hasWorkspaceTable || hasLegacySessionTable) {
      return true;
    }

    if (hasUsersTable && !this.columnExists("users", "created_at")) {
      return true;
    }

    return false;
  }

  resetSchema() {
    this.db.exec(`
      DROP TABLE IF EXISTS workspace;
      DROP TABLE IF EXISTS observed_apps;
      DROP TABLE IF EXISTS session_state;
      DROP TABLE IF EXISTS organizations;
      DROP TABLE IF EXISTS organization_observed_apps;
      DROP TABLE IF EXISTS memberships;
      DROP TABLE IF EXISTS auth_accounts;
      DROP TABLE IF EXISTS api_sessions;
      DROP TABLE IF EXISTS schema_migrations;
      DROP TABLE IF EXISTS local_session_state;
      DROP TABLE IF EXISTS employee_invites;
      DROP TABLE IF EXISTS password_reset_tokens;
      DROP TABLE IF EXISTS device_installs;
      DROP TABLE IF EXISTS integrations;
      DROP TABLE IF EXISTS profile_points;
      DROP TABLE IF EXISTS user_apps;
      DROP TABLE IF EXISTS observed_actions;
      DROP TABLE IF EXISTS access_records;
      DROP TABLE IF EXISTS automations;
      DROP TABLE IF EXISTS reports;
      DROP TABLE IF EXISTS report_findings;
      DROP TABLE IF EXISTS recommendation_runs;
      DROP TABLE IF EXISTS audit_events;
      DROP TABLE IF EXISTS company_registration_codes;
      DROP TABLE IF EXISTS demo_login_aliases;
      DROP TABLE IF EXISTS plan_change_requests;
      DROP TABLE IF EXISTS workflow_sessions;
      DROP TABLE IF EXISTS users;
    `);
  }

  tableExists(tableName) {
    return Boolean(this.db.prepare(`
      SELECT name
      FROM sqlite_master
      WHERE type = 'table' AND name = ?
    `).get(tableName));
  }

  columnExists(tableName, columnName) {
    if (!this.tableExists(tableName)) {
      return false;
    }

    const columns = this.db.prepare(`PRAGMA table_info(${tableName})`).all();
    return columns.some((column) => column.name === columnName);
  }

  runMigrations() {
    const applied = new Set(this.db.prepare(`
      SELECT version
      FROM schema_migrations
    `).all().map((row) => row.version));

    const migrations = [
      {
        version: 1,
        name: "automation_metadata_v1",
        up: () => {
          this.addColumnIfMissing("automations", "source", "TEXT NOT NULL DEFAULT 'seeded'");
          this.addColumnIfMissing("automations", "confidence_score", "REAL NOT NULL DEFAULT 0");
          this.addColumnIfMissing("automations", "projected_hours", "REAL NOT NULL DEFAULT 0");
          this.addColumnIfMissing("automations", "rank_score", "REAL NOT NULL DEFAULT 0");
          this.addColumnIfMissing("automations", "rationale", "TEXT NOT NULL DEFAULT ''");
          this.addColumnIfMissing("automations", "generated_at", "TEXT");
        },
      },
      {
        version: 2,
        name: "generated_content_sources_v1",
        up: () => {
          this.addColumnIfMissing("profile_points", "source", "TEXT NOT NULL DEFAULT 'manual'");
          this.addColumnIfMissing("report_findings", "source", "TEXT NOT NULL DEFAULT 'manual'");
        },
      },
      {
        version: 3,
        name: "recommendation_runs_v1",
        up: () => {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS recommendation_runs (
              id TEXT PRIMARY KEY,
              org_id TEXT NOT NULL,
              user_id TEXT NOT NULL,
              observed_action_count INTEGER NOT NULL,
              generated_count INTEGER NOT NULL,
              total_projected_hours REAL NOT NULL,
              automation_readiness INTEGER NOT NULL,
              trace_json TEXT NOT NULL,
              created_at TEXT NOT NULL,
              FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
              FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );
          `);
        },
      },
      {
        version: 4,
        name: "company_registration_codes_v1",
        up: () => {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS company_registration_codes (
              id TEXT PRIMARY KEY,
              code TEXT NOT NULL UNIQUE,
              label TEXT NOT NULL,
              plan_name TEXT NOT NULL,
              seat_limit INTEGER NOT NULL,
              approval_sla TEXT NOT NULL,
              deployment_mode TEXT NOT NULL,
              audit_cycle_days INTEGER NOT NULL,
              observed_apps_json TEXT NOT NULL,
              created_at TEXT NOT NULL,
              claimed_at TEXT,
              claimed_org_id TEXT,
              claimed_by_user_id TEXT,
              FOREIGN KEY (claimed_org_id) REFERENCES organizations(id) ON DELETE SET NULL,
              FOREIGN KEY (claimed_by_user_id) REFERENCES users(id) ON DELETE SET NULL
            );
          `);
        },
      },
      {
        version: 5,
        name: "demo_login_aliases_v1",
        up: () => {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS demo_login_aliases (
              alias TEXT PRIMARY KEY,
              org_id TEXT NOT NULL,
              user_id TEXT NOT NULL,
              label TEXT NOT NULL,
              created_at TEXT NOT NULL,
              FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
              FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );
          `);
        },
      },
      {
        version: 6,
        name: "plan_change_requests_v1",
        up: () => {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS plan_change_requests (
              id TEXT PRIMARY KEY,
              org_id TEXT NOT NULL,
              requested_by_user_id TEXT NOT NULL,
              request_type TEXT NOT NULL,
              requested_plan TEXT,
              note TEXT NOT NULL DEFAULT '',
              status TEXT NOT NULL,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
              FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE CASCADE
            );
          `);
        },
      },
      {
        version: 7,
        name: "workflow_sessions_v1",
        up: () => {
          this.db.exec(`
            CREATE TABLE IF NOT EXISTS workflow_sessions (
              id TEXT PRIMARY KEY,
              org_id TEXT NOT NULL,
              user_id TEXT NOT NULL,
              device_id TEXT,
              source TEXT NOT NULL,
              workflow_label TEXT NOT NULL,
              primary_app TEXT NOT NULL,
              screen_type TEXT NOT NULL,
              confidence_score REAL NOT NULL DEFAULT 0,
              started_at TEXT NOT NULL,
              ended_at TEXT NOT NULL,
              step_count INTEGER NOT NULL DEFAULT 0,
              click_count INTEGER NOT NULL DEFAULT 0,
              evidence_json TEXT NOT NULL,
              created_at TEXT NOT NULL,
              updated_at TEXT NOT NULL,
              FOREIGN KEY (org_id) REFERENCES organizations(id) ON DELETE CASCADE,
              FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
              FOREIGN KEY (device_id) REFERENCES device_installs(id) ON DELETE SET NULL
            );
          `);
        },
      },
    ];

    migrations.forEach((migration) => {
      if (applied.has(migration.version)) {
        return;
      }

      this.withTransaction(() => {
        migration.up();
        this.db.prepare(`
          INSERT INTO schema_migrations (version, name, applied_at)
          VALUES (?, ?, ?)
        `).run(migration.version, migration.name, nowIso());
      });
    });
  }

  addColumnIfMissing(tableName, columnName, definition) {
    if (!this.columnExists(tableName, columnName)) {
      this.db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
    }
  }

  seed(workspaceState) {
    const createdAt = nowIso();
    const passwordRecord = createPasswordRecord(this.bootstrapPassword);
    const clientCatalog = createSeedClientCatalog(workspaceState);

    const insertOrganization = this.db.prepare(`
      INSERT INTO organizations (
        id, name, slug, plan_name, seat_limit, seats_used, approval_sla, deployment_mode, audit_cycle_days, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertObservedApp = this.db.prepare(`
      INSERT INTO organization_observed_apps (org_id, sort_order, name)
      VALUES (?, ?, ?)
    `);
    const insertUser = this.db.prepare(`
      INSERT INTO users (
        id, name, title, email, team, status, consent_status, last_seen, reclaimable_hours, automation_readiness, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertMembership = this.db.prepare(`
      INSERT INTO memberships (
        id, org_id, user_id, role, status, sort_order, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAuthAccount = this.db.prepare(`
      INSERT INTO auth_accounts (
        user_id, password_salt, password_hash, must_rotate_password, created_at, updated_at
      ) VALUES (?, ?, ?, 1, ?, ?)
    `);
    const insertLocalSession = this.db.prepare(`
      INSERT INTO local_session_state (
        id, org_id, current_user_id, current_role, current_session_token, updated_at
      ) VALUES (1, ?, ?, ?, NULL, ?)
    `);
    const insertProfilePoint = this.db.prepare(`
      INSERT INTO profile_points (org_id, user_id, sort_order, content)
      VALUES (?, ?, ?, ?)
    `);
    const insertUserApp = this.db.prepare(`
      INSERT INTO user_apps (org_id, user_id, sort_order, app_name)
      VALUES (?, ?, ?, ?)
    `);
    const insertObservedAction = this.db.prepare(`
      INSERT INTO observed_actions (
        id, org_id, user_id, occurred_at, source, source_key, app_name, category, description, payload_json, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAccessRecord = this.db.prepare(`
      INSERT INTO access_records (id, org_id, user_id, app_name, method, status, visibility, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAutomation = this.db.prepare(`
      INSERT INTO automations (
        id, org_id, user_id, name, scope, mode, impact, status, employee_decision, admin_decision, summary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertReport = this.db.prepare(`
      INSERT INTO reports (org_id, user_id, headline)
      VALUES (?, ?, ?)
    `);
    const insertReportFinding = this.db.prepare(`
      INSERT INTO report_findings (org_id, user_id, sort_order, finding)
      VALUES (?, ?, ?, ?)
    `);
    const insertIntegration = this.db.prepare(`
      INSERT INTO integrations (
        id, org_id, provider, display_name, status, connection_mode, scopes_json, health_status, external_account_ref, connected_by_user_id, last_sync_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAuditEvent = this.db.prepare(`
      INSERT INTO audit_events (
        id, org_id, created_at, actor_user_id, actor_name, target_user_id, event_type, summary, metadata_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    this.withTransaction(() => {
      clientCatalog.forEach((client) => {
        const orgSlug = slugify(client.workspace.name);

        insertOrganization.run(
          client.orgId,
          client.workspace.name,
          orgSlug,
          client.workspace.plan.name,
          client.workspace.plan.seatLimit,
          client.workspace.plan.seatsUsed,
          client.workspace.plan.approvalSla,
          client.workspace.plan.deploymentMode,
          client.workspace.plan.auditCycleDays,
          createdAt,
          createdAt,
        );

        client.workspace.observedApps.forEach((appName, index) => {
          insertObservedApp.run(client.orgId, index, appName);
        });

        client.users.forEach((user, index) => {
          insertUser.run(
            user.id,
            user.name,
            user.title,
            user.email,
            user.team || null,
            user.status || null,
            user.consentStatus || null,
            user.lastSeen || null,
            user.reclaimableHours || 0,
            user.automationReadiness || 0,
            createdAt,
            createdAt,
          );

          insertMembership.run(
            `mem-${client.orgId}-${user.id}`,
            client.orgId,
            user.id,
            user.role,
            "active",
            index,
            createdAt,
            createdAt,
          );

          insertAuthAccount.run(
            user.id,
            passwordRecord.salt,
            passwordRecord.hash,
            createdAt,
            createdAt,
          );

          if (user.role !== "employee") {
            return;
          }

          user.profileSummary.forEach((entry, entryIndex) => {
            insertProfilePoint.run(client.orgId, user.id, entryIndex, entry);
          });

          user.apps.forEach((appName, appIndex) => {
            insertUserApp.run(client.orgId, user.id, appIndex, appName);
          });

          user.actions.forEach((action) => {
            insertObservedAction.run(
              action.id,
              client.orgId,
              user.id,
              new Date(action.timestamp).toISOString(),
              "seed",
              action.id,
              action.app,
              action.category,
              action.description,
              JSON.stringify({ seeded: true }),
              createdAt,
            );
          });

          user.access.forEach((entry) => {
            insertAccessRecord.run(entry.id, client.orgId, user.id, entry.app, entry.method, entry.status, entry.visibility, entry.updatedAt);
          });

          user.automations.forEach((entry) => {
            insertAutomation.run(
              entry.id,
              client.orgId,
              user.id,
              entry.name,
              entry.scope,
              entry.mode,
              entry.impact,
              entry.status,
              entry.employeeDecision,
              entry.adminDecision,
              entry.summary,
            );
          });

          insertReport.run(client.orgId, user.id, user.report.headline);
          user.report.findings.forEach((finding, findingIndex) => {
            insertReportFinding.run(client.orgId, user.id, findingIndex, finding);
          });
        });

        if (client.sessionUserId) {
          const sessionUser = client.users.find((user) => user.id === client.sessionUserId);
          insertLocalSession.run(client.orgId, client.sessionUserId, sessionUser?.role || "support", createdAt);
        }

        (client.integrations || []).forEach((integration) => {
          insertIntegration.run(
            integration.id,
            client.orgId,
            integration.provider,
            integration.displayName,
            integration.status,
            integration.connectionMode,
            JSON.stringify(integration.scopes),
            integration.healthStatus,
            integration.externalAccountRef,
            integration.connectedByUserId,
            integration.lastSyncAt,
            createdAt,
            createdAt,
          );
        });

        (client.auditEvents || []).forEach((event) => {
          insertAuditEvent.run(
            event.id,
            client.orgId,
            event.createdAt,
            event.actorUserId,
            event.actorName,
            event.targetUserId,
            event.eventType,
            event.summary,
            JSON.stringify(event.metadata),
          );
        });
      });
    });
  }

  seedAdditionalClients() {
    const missingClients = createSeedClientCatalog(createSeedWorkspace())
      .filter((client) => !this.db.prepare("SELECT id FROM organizations WHERE id = ?").get(client.orgId));

    if (!missingClients.length) {
      return;
    }

    const createdAt = nowIso();
    const passwordRecord = createPasswordRecord(this.bootstrapPassword);

    const insertOrganization = this.db.prepare(`
      INSERT INTO organizations (
        id, name, slug, plan_name, seat_limit, seats_used, approval_sla, deployment_mode, audit_cycle_days, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertObservedApp = this.db.prepare(`
      INSERT INTO organization_observed_apps (org_id, sort_order, name)
      VALUES (?, ?, ?)
    `);
    const insertUser = this.db.prepare(`
      INSERT INTO users (
        id, name, title, email, team, status, consent_status, last_seen, reclaimable_hours, automation_readiness, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertMembership = this.db.prepare(`
      INSERT INTO memberships (
        id, org_id, user_id, role, status, sort_order, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAuthAccount = this.db.prepare(`
      INSERT INTO auth_accounts (
        user_id, password_salt, password_hash, must_rotate_password, created_at, updated_at
      ) VALUES (?, ?, ?, 1, ?, ?)
    `);
    const insertProfilePoint = this.db.prepare(`
      INSERT INTO profile_points (org_id, user_id, sort_order, content)
      VALUES (?, ?, ?, ?)
    `);
    const insertUserApp = this.db.prepare(`
      INSERT INTO user_apps (org_id, user_id, sort_order, app_name)
      VALUES (?, ?, ?, ?)
    `);
    const insertObservedAction = this.db.prepare(`
      INSERT INTO observed_actions (
        id, org_id, user_id, occurred_at, source, source_key, app_name, category, description, payload_json, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAccessRecord = this.db.prepare(`
      INSERT INTO access_records (id, org_id, user_id, app_name, method, status, visibility, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAutomation = this.db.prepare(`
      INSERT INTO automations (
        id, org_id, user_id, name, scope, mode, impact, status, employee_decision, admin_decision, summary
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertReport = this.db.prepare(`
      INSERT INTO reports (org_id, user_id, headline)
      VALUES (?, ?, ?)
    `);
    const insertReportFinding = this.db.prepare(`
      INSERT INTO report_findings (org_id, user_id, sort_order, finding)
      VALUES (?, ?, ?, ?)
    `);
    const insertIntegration = this.db.prepare(`
      INSERT INTO integrations (
        id, org_id, provider, display_name, status, connection_mode, scopes_json, health_status, external_account_ref, connected_by_user_id, last_sync_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertAuditEvent = this.db.prepare(`
      INSERT INTO audit_events (
        id, org_id, created_at, actor_user_id, actor_name, target_user_id, event_type, summary, metadata_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    this.withTransaction(() => {
      missingClients.forEach((client) => {
        insertOrganization.run(
          client.orgId,
          client.workspace.name,
          slugify(client.workspace.name),
          client.workspace.plan.name,
          client.workspace.plan.seatLimit,
          client.workspace.plan.seatsUsed,
          client.workspace.plan.approvalSla,
          client.workspace.plan.deploymentMode,
          client.workspace.plan.auditCycleDays,
          createdAt,
          createdAt,
        );

        client.workspace.observedApps.forEach((appName, index) => {
          insertObservedApp.run(client.orgId, index, appName);
        });

        client.users.forEach((user, index) => {
          if (!this.getUserById(user.id)) {
            insertUser.run(
              user.id,
              user.name,
              user.title,
              user.email,
              user.team || null,
              user.status || null,
              user.consentStatus || null,
              user.lastSeen || null,
              user.reclaimableHours || 0,
              user.automationReadiness || 0,
              createdAt,
              createdAt,
            );

            insertAuthAccount.run(
              user.id,
              passwordRecord.salt,
              passwordRecord.hash,
              createdAt,
              createdAt,
            );
          }

          insertMembership.run(
            `mem-${client.orgId}-${user.id}`,
            client.orgId,
            user.id,
            user.role,
            "active",
            index,
            createdAt,
            createdAt,
          );

          if (user.role !== "employee") {
            return;
          }

          user.profileSummary.forEach((entry, entryIndex) => {
            insertProfilePoint.run(client.orgId, user.id, entryIndex, entry);
          });

          user.apps.forEach((appName, appIndex) => {
            insertUserApp.run(client.orgId, user.id, appIndex, appName);
          });

          user.actions.forEach((action) => {
            insertObservedAction.run(
              action.id,
              client.orgId,
              user.id,
              new Date(action.timestamp).toISOString(),
              "seed",
              action.id,
              action.app,
              action.category,
              action.description,
              JSON.stringify({ seeded: true }),
              createdAt,
            );
          });

          user.access.forEach((entry) => {
            insertAccessRecord.run(entry.id, client.orgId, user.id, entry.app, entry.method, entry.status, entry.visibility, entry.updatedAt);
          });

          user.automations.forEach((entry) => {
            insertAutomation.run(
              entry.id,
              client.orgId,
              user.id,
              entry.name,
              entry.scope,
              entry.mode,
              entry.impact,
              entry.status,
              entry.employeeDecision,
              entry.adminDecision,
              entry.summary,
            );
          });

          insertReport.run(client.orgId, user.id, user.report.headline);
          user.report.findings.forEach((finding, findingIndex) => {
            insertReportFinding.run(client.orgId, user.id, findingIndex, finding);
          });
        });

        (client.integrations || []).forEach((integration) => {
          insertIntegration.run(
            integration.id,
            client.orgId,
            integration.provider,
            integration.displayName,
            integration.status,
            integration.connectionMode,
            JSON.stringify(integration.scopes),
            integration.healthStatus,
            integration.externalAccountRef,
            integration.connectedByUserId,
            integration.lastSyncAt,
            createdAt,
            createdAt,
          );
        });

        (client.auditEvents || []).forEach((event) => {
          insertAuditEvent.run(
            event.id,
            client.orgId,
            event.createdAt,
            event.actorUserId,
            event.actorName,
            event.targetUserId,
            event.eventType,
            event.summary,
            JSON.stringify(event.metadata),
          );
        });
      });
    });
  }

  backfillSupportOperator() {
    this.init();
    const dana = this.db.prepare(`
      SELECT users.id, memberships.org_id, memberships.role
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE lower(users.email) = lower(?)
      LIMIT 1
    `).get("dana@acme-logistics.com");

    if (!dana || dana.role === "support") {
      return;
    }

    const timestamp = nowIso();
    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE memberships
        SET role = 'support', updated_at = ?
        WHERE org_id = ? AND user_id = ?
      `).run(timestamp, dana.org_id, dana.id);

      this.db.prepare(`
        UPDATE local_session_state
        SET current_role = CASE WHEN current_user_id = ? THEN 'support' ELSE current_role END,
            updated_at = ?
        WHERE id = 1
      `).run(dana.id, timestamp);
    });
  }

  seedCompanyRegistrationCodes() {
    this.init();
    const createdAt = nowIso();
    const insertCode = this.db.prepare(`
      INSERT INTO company_registration_codes (
        id, code, label, plan_name, seat_limit, approval_sla, deployment_mode, audit_cycle_days, observed_apps_json, created_at, claimed_at, claimed_org_id, claimed_by_user_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL)
      ON CONFLICT(code) DO NOTHING
    `);

    this.withTransaction(() => {
      createCompanyRegistrationCatalog().forEach((entry) => {
        insertCode.run(
          entry.id,
          entry.code,
          entry.label,
          entry.planName,
          entry.seatLimit,
          entry.approvalSla,
          entry.deploymentMode,
          entry.auditCycleDays,
          JSON.stringify(entry.observedApps),
          createdAt,
        );
      });
    });
  }

  seedDemoLoginAliases() {
    this.init();
    const createdAt = nowIso();
    const insertAlias = this.db.prepare(`
      INSERT INTO demo_login_aliases (alias, org_id, user_id, label, created_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(alias) DO UPDATE SET
        org_id = excluded.org_id,
        user_id = excluded.user_id,
        label = excluded.label
    `);

    this.withTransaction(() => {
      DEMO_LOGIN_ALIASES.forEach((entry) => {
        const membership = this.db.prepare(`
          SELECT memberships.org_id, users.id AS user_id
          FROM users
          JOIN memberships ON memberships.user_id = users.id
          WHERE lower(users.email) = lower(?)
          ORDER BY memberships.created_at
          LIMIT 1
        `).get(entry.email);

        if (!membership) {
          return;
        }

        insertAlias.run(entry.alias, membership.org_id, membership.user_id, entry.label, createdAt);
      });
    });
  }

  applyObservedActionRetention(now = new Date()) {
    this.init();

    if (this.rawEventRetentionDays < 0) {
      return { updated: 0, cutoffAt: null };
    }

    const cutoffAt = subtractDays(now, this.rawEventRetentionDays).toISOString();
    const scrubbedPayload = JSON.stringify({
      retained: "metadata-only",
      reason: "raw-event-retention-expired",
    });

    const result = this.db.prepare(`
      UPDATE observed_actions
      SET payload_json = ?
      WHERE datetime(occurred_at) < datetime(?)
        AND payload_json != ?
    `).run(scrubbedPayload, cutoffAt, scrubbedPayload);

    return {
      updated: result.changes || 0,
      cutoffAt,
    };
  }

  getMetricsSnapshot() {
    this.init();
    const totals = {
      organizations: this.db.prepare("SELECT COUNT(*) AS count FROM organizations").get().count || 0,
      memberships: this.db.prepare("SELECT COUNT(*) AS count FROM memberships").get().count || 0,
      sessions: this.db.prepare("SELECT COUNT(*) AS count FROM api_sessions WHERE revoked_at IS NULL").get().count || 0,
      devices: this.db.prepare("SELECT COUNT(*) AS count FROM device_installs WHERE status = 'active'").get().count || 0,
      actions: this.db.prepare("SELECT COUNT(*) AS count FROM observed_actions").get().count || 0,
      workflows: this.db.prepare("SELECT COUNT(*) AS count FROM workflow_sessions").get().count || 0,
      integrations: this.db.prepare("SELECT COUNT(*) AS count FROM integrations").get().count || 0,
      auditEvents: this.db.prepare("SELECT COUNT(*) AS count FROM audit_events").get().count || 0,
    };

    const latest = this.db.prepare(`
      SELECT MAX(occurred_at) AS latest_action_at
      FROM observed_actions
    `).get();

    return {
      generatedAt: nowIso(),
      retention: {
        observerRedactionMode: this.observerRedactionMode,
        rawEventRetentionDays: this.rawEventRetentionDays,
      },
      totals: {
        organizations: totals.organizations,
        users: totals.memberships,
        activeSessions: totals.sessions,
        activeDevices: totals.devices,
        observedActions: totals.actions,
        workflowSessions: totals.workflows,
        integrations: totals.integrations,
        auditEvents: totals.auditEvents,
      },
      latestActionAt: latest.latest_action_at || null,
    };
  }

  snapshot(orgId = null, currentUserId = null) {
    this.init();
    const localSession = this.getLocalSessionState();
    const resolvedOrgId = orgId || localSession.orgId;
    const resolvedUserId = currentUserId || localSession.currentUserId;
    const membership = this.getMembershipByUserId(resolvedOrgId, resolvedUserId);
    const users = membership.role === "employee"
      ? [this.getEmployee(resolvedUserId, resolvedOrgId)]
      : this.listUsers(resolvedOrgId);

    return {
      workspace: this.getWorkspace(resolvedOrgId),
      session: {
        currentUserId: resolvedUserId,
        currentOrgId: resolvedOrgId,
        currentRole: membership.role,
        currentSessionToken: localSession.currentSessionToken || null,
      },
      users,
      clients: isSupportRole(membership.role) ? this.listClientHierarchy() : [],
      invites: membership.role === "employee" ? [] : this.listEmployeeInvites(resolvedOrgId),
      planRequests: membership.role === "employee" ? [] : this.listPlanChangeRequests(resolvedOrgId),
      automationOpportunities: this.listAutomationOpportunities(resolvedOrgId),
      observerWorkflows: membership.role === "employee"
        ? this.listWorkflowSessions(resolvedOrgId, { employeeId: resolvedUserId, limit: 12 })
        : this.listWorkflowSessions(resolvedOrgId, { limit: 20 }),
      auditTrail: this.listAuditEvents(resolvedOrgId, 20),
      integrations: this.listIntegrations(resolvedOrgId),
      devices: this.listDevices(resolvedOrgId),
      auth: {
        mode: "password + session token",
      },
      schemaVersion: LATEST_SCHEMA_VERSION,
    };
  }

  listOrganizations() {
    this.init();
    return this.db.prepare(`
      SELECT id, name, slug, plan_name, seat_limit, seats_used
      FROM organizations
      ORDER BY name
    `).all().map((row) => ({
      id: row.id,
      name: row.name,
      slug: row.slug,
      planName: row.plan_name,
      seatLimit: row.seat_limit,
      seatsUsed: row.seats_used,
    }));
  }

  getCurrentOrganization() {
    this.init();
    return this.getWorkspace(this.getLocalSessionState().orgId);
  }

  buildClientSummary(orgId) {
    const org = this.getWorkspace(orgId);
    const counts = this.db.prepare(`
      SELECT
        COUNT(*) AS user_count,
        SUM(CASE WHEN memberships.role = 'employee' THEN 1 ELSE 0 END) AS employee_count
      FROM memberships
      WHERE memberships.org_id = ?
    `).get(orgId);
    const actionStats = this.db.prepare(`
      SELECT COUNT(*) AS action_count, MAX(occurred_at) AS last_action_at
      FROM observed_actions
      WHERE org_id = ?
    `).get(orgId);

    return {
      id: org.id,
      slug: org.slug,
      name: org.name,
      planName: org.plan.name,
      seatLimit: org.plan.seatLimit,
      seatsUsed: org.plan.seatsUsed,
      observedAppsCount: org.observedApps.length,
      userCount: counts.user_count || 0,
      employeeCount: counts.employee_count || 0,
      actionCount: actionStats.action_count || 0,
      lastActionAt: actionStats.last_action_at || null,
    };
  }

  listClients() {
    this.init();
    return this.listOrganizations().map((org) => this.buildClientSummary(org.id));
  }

  getClient(orgId) {
    this.init();
    const workspace = this.getWorkspace(orgId);
    const summary = this.buildClientSummary(orgId);
    const users = this.listUsers(orgId).map((user) => ({
      ...user,
      actionCount: Array.isArray(user.actions) ? user.actions.length : 0,
      automationCount: Array.isArray(user.automations) ? user.automations.length : 0,
      lastActionAt: Array.isArray(user.actions) && user.actions.length ? user.actions[user.actions.length - 1].timestamp : null,
    }));

    return {
      ...summary,
      workspace,
      users,
    };
  }

  listClientHierarchy() {
    this.init();
    return this.listOrganizations().map((org) => this.getClient(org.id));
  }

  listEmployees(orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.listUsers(resolvedOrgId).filter((entry) => entry.role === "employee");
  }

  getEmployee(employeeId, orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    const row = this.db.prepare(`
      SELECT users.*, memberships.role, memberships.sort_order
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND users.id = ? AND memberships.role = 'employee'
    `).get(resolvedOrgId, employeeId);

    if (!row) {
      throw buildError("Employee not found", 404);
    }

    return this.hydrateUser(resolvedOrgId, row);
  }

  refreshAutomationRecommendations(actorUserId, payload = {}) {
    this.init();
    const orgId = payload.orgId || this.getLocalSessionState().orgId;
    const employeeIds = payload.employeeId ? [payload.employeeId] : this.listEmployees(orgId).map((entry) => entry.id);
    const refreshed = [];

    this.withTransaction(() => {
      employeeIds.forEach((employeeId) => {
        const employee = this.getEmployee(employeeId, orgId);
        const recommendationPackage = buildRecommendationPackage(employee);
        const timestamp = nowIso();

        this.db.prepare(`
          DELETE FROM automations
          WHERE org_id = ? AND user_id = ? AND source = 'generated'
        `).run(orgId, employeeId);

        this.db.prepare(`
          DELETE FROM profile_points
          WHERE org_id = ? AND user_id = ? AND source = 'generated'
        `).run(orgId, employeeId);

        this.db.prepare(`
          DELETE FROM report_findings
          WHERE org_id = ? AND user_id = ? AND source = 'generated'
        `).run(orgId, employeeId);

        recommendationPackage.recommendations.forEach((entry) => {
          this.db.prepare(`
            INSERT INTO automations (
              id, org_id, user_id, name, scope, mode, impact, status, employee_decision, admin_decision, summary,
              source, confidence_score, projected_hours, rank_score, rationale, generated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'generated', ?, ?, ?, ?, ?)
          `).run(
            entry.id,
            orgId,
            employeeId,
            entry.name,
            entry.scope,
            entry.mode,
            entry.impact,
            entry.status,
            entry.employeeDecision,
            entry.adminDecision,
            entry.summary,
            entry.confidenceScore,
            entry.projectedHours,
            entry.rankScore,
            entry.rationale,
            timestamp,
          );
        });

        recommendationPackage.profilePoints.forEach((content, index) => {
          this.db.prepare(`
            INSERT INTO profile_points (org_id, user_id, sort_order, content, source)
            VALUES (?, ?, ?, ?, 'generated')
          `).run(orgId, employeeId, 100 + index, content);
        });

        recommendationPackage.report.findings.forEach((finding, index) => {
          this.db.prepare(`
            INSERT INTO report_findings (org_id, user_id, sort_order, finding, source)
            VALUES (?, ?, ?, ?, 'generated')
          `).run(orgId, employeeId, 100 + index, finding);
        });

        this.db.prepare(`
          INSERT INTO recommendation_runs (
            id, org_id, user_id, observed_action_count, generated_count, total_projected_hours, automation_readiness, trace_json, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          `rr-${randomUUID().slice(0, 12)}`,
          orgId,
          employeeId,
          recommendationPackage.trace.actionCount,
          recommendationPackage.recommendations.length,
          recommendationPackage.reclaimableHours,
          recommendationPackage.automationReadiness,
          JSON.stringify(recommendationPackage.trace),
          timestamp,
        );

        this.db.prepare(`
          UPDATE users
          SET reclaimable_hours = ?, automation_readiness = ?, updated_at = ?
          WHERE id = ?
        `).run(
          recommendationPackage.reclaimableHours,
          recommendationPackage.automationReadiness,
          timestamp,
          employeeId,
        );

        this.db.prepare(`
          INSERT INTO reports (org_id, user_id, headline)
          VALUES (?, ?, ?)
          ON CONFLICT(org_id, user_id) DO UPDATE SET headline = excluded.headline
        `).run(orgId, employeeId, recommendationPackage.report.headline);

        this.logAuditEvent({
          orgId,
          actorUserId,
          targetUserId: employeeId,
          eventType: "automation.recommendations_refreshed",
          summary: `Refreshed generated automation recommendations for ${employee.name}.`,
          metadata: {
            generatedCount: recommendationPackage.recommendations.length,
            totalProjectedHours: recommendationPackage.reclaimableHours,
            automationReadiness: recommendationPackage.automationReadiness,
          },
        });

        refreshed.push({
          employeeId,
          employeeName: employee.name,
          generatedCount: recommendationPackage.recommendations.length,
          reclaimableHours: recommendationPackage.reclaimableHours,
          automationReadiness: recommendationPackage.automationReadiness,
        });
      });
    });

    return {
      refreshed,
      opportunities: this.listAutomationOpportunities(orgId),
      workspace: this.snapshot(orgId, actorUserId),
    };
  }

  setCurrentUser(orgId, userId) {
    this.init();
    const membership = this.getMembershipByUserId(orgId, userId);
    if (!membership) {
      throw buildError("User not found", 404);
    }

    this.db.prepare(`
      UPDATE local_session_state
      SET current_user_id = ?, current_role = ?, updated_at = ?
      WHERE id = 1
    `).run(userId, membership.role, nowIso());

    return this.snapshot(orgId, userId);
  }

  addEmployee(orgId, actorUserId, payload) {
    this.init();
    const organization = this.db.prepare("SELECT seat_limit FROM organizations WHERE id = ?").get(orgId);
    const employeeCount = this.employeeCount(orgId);

    if (employeeCount >= organization.seat_limit) {
      throw buildError("Plan seat limit reached", 400);
    }

    const existing = this.db.prepare("SELECT id FROM users WHERE email = ?").get(payload.email);
    if (existing) {
      throw buildError("Employee email already exists", 400);
    }

    const employeeId = `emp-${slugify(payload.name)}-${randomUUID().slice(0, 8)}`;
    const createdAt = nowIso();
    const expiresAt = addDays(createdAt, 14);
    const sortOrder = this.nextMembershipSortOrder(orgId);
    const inviteToken = createOpaqueToken("invite");

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO users (
          id, name, title, email, team, status, consent_status, last_seen, reclaimable_hours, automation_readiness, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)
      `).run(
        employeeId,
        payload.name,
        payload.title,
        payload.email,
        payload.team,
        "awaiting-consent",
        "pending",
        "New seat",
        createdAt,
        createdAt,
      );

      this.db.prepare(`
        INSERT INTO memberships (
          id, org_id, user_id, role, status, sort_order, created_at, updated_at
        ) VALUES (?, ?, ?, 'employee', 'active', ?, ?, ?)
      `).run(`mem-${employeeId}`, orgId, employeeId, sortOrder, createdAt, createdAt);

      const passwordRecord = createPasswordRecord(this.bootstrapPassword);
      this.db.prepare(`
        INSERT INTO auth_accounts (
          user_id, password_salt, password_hash, must_rotate_password, created_at, updated_at
        ) VALUES (?, ?, ?, 1, ?, ?)
      `).run(employeeId, passwordRecord.salt, passwordRecord.hash, createdAt, createdAt);

      this.db.prepare(`
        INSERT INTO profile_points (org_id, user_id, sort_order, content)
        VALUES (?, ?, 0, ?), (?, ?, 1, ?)
      `).run(
        orgId,
        employeeId,
        "Observation has not started yet.",
        orgId,
        employeeId,
        "The desktop agent will begin profiling once consent is granted.",
      );

      this.db.prepare(`
        INSERT INTO reports (org_id, user_id, headline)
        VALUES (?, ?, ?)
      `).run(orgId, employeeId, "No report generated yet.");
      this.db.prepare(`
        INSERT INTO report_findings (org_id, user_id, sort_order, finding)
        VALUES (?, ?, 0, ?)
      `).run(orgId, employeeId, "Observation has not started yet.");

      this.db.prepare(`
        INSERT INTO employee_invites (
          id, org_id, email, name, title, team, role, invite_token_hash, invited_by_user_id, created_at, expires_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'employee', ?, ?, ?, ?)
        `).run(
        `inv-${employeeId}`,
        orgId,
        payload.email,
        payload.name,
        payload.title,
        payload.team,
        hashToken(inviteToken),
        actorUserId,
        createdAt,
        expiresAt,
      );

      this.syncSeatsUsed(orgId);
      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: employeeId,
        eventType: "employee.created",
        summary: `Provisioned employee seat for ${payload.name}.`,
        metadata: {
          email: payload.email,
          inviteToken,
        },
      });
    });

    return {
      ...this.snapshot(orgId, actorUserId),
      invite: {
        employeeId,
        email: payload.email,
        expiresAt,
        inviteToken,
      },
    };
  }

  setAutomationDecision(orgId, actorUserId, payload) {
    this.init();
    const employee = this.db.prepare(`
      SELECT users.id, users.name
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND users.id = ? AND memberships.role = 'employee'
    `).get(orgId, payload.employeeId);

    if (!employee) {
      throw buildError("Employee not found", 404);
    }

    const automation = this.db.prepare(`
      SELECT *
      FROM automations
      WHERE org_id = ? AND id = ? AND user_id = ?
    `).get(orgId, payload.automationId, payload.employeeId);

    if (!automation) {
      throw buildError("Automation not found", 404);
    }

    const next = {
      adminDecision: automation.admin_decision,
      employeeDecision: automation.employee_decision,
      status: automation.status,
    };

    if (payload.actorRole === "admin") {
      next.adminDecision = payload.decision;
    } else {
      next.employeeDecision = payload.decision;
    }

    if (next.adminDecision === "approved" && next.employeeDecision === "accepted") {
      next.status = "active";
    } else if (next.adminDecision === "rejected" || next.employeeDecision === "rejected") {
      next.status = "rejected";
    } else if (next.adminDecision === "approved") {
      next.status = "proposed";
    } else {
      next.status = "review";
    }

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE automations
        SET admin_decision = ?, employee_decision = ?, status = ?
        WHERE org_id = ? AND id = ? AND user_id = ?
      `).run(next.adminDecision, next.employeeDecision, next.status, orgId, payload.automationId, payload.employeeId);

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: payload.employeeId,
        eventType: "automation.updated",
        summary: `${automation.name} was ${payload.decision} by the ${payload.actorRole} for ${employee.name}.`,
        metadata: {
          automationId: payload.automationId,
          actorRole: payload.actorRole,
          decision: payload.decision,
          status: next.status,
        },
      });
    });

    return this.snapshot(orgId, actorUserId);
  }

  setConsentStatus(orgId, actorUserId, payload) {
    this.init();
    const employee = this.db.prepare(`
      SELECT users.id, users.name
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND users.id = ? AND memberships.role = 'employee'
    `).get(orgId, payload.employeeId);

    if (!employee) {
      throw buildError("Employee not found", 404);
    }

    const nextStatus = payload.consentStatus === "approved" ? "observing" : "awaiting-consent";
    const lastSeen = payload.consentStatus === "approved" ? "Active just now" : "Needs onboarding";

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE users
        SET consent_status = ?, status = ?, last_seen = ?, updated_at = ?
        WHERE id = ?
      `).run(payload.consentStatus, nextStatus, lastSeen, nowIso(), payload.employeeId);

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: payload.employeeId,
        eventType: "consent.updated",
        summary: `Consent marked ${payload.consentStatus} for ${employee.name}.`,
        metadata: { consentStatus: payload.consentStatus },
      });
    });

    return this.snapshot(orgId, actorUserId);
  }

  login(payload) {
    this.init();
    const aliasMatch = this.db.prepare(`
      SELECT demo_login_aliases.org_id, demo_login_aliases.user_id
      FROM demo_login_aliases
      WHERE lower(alias) = lower(?)
    `).get(payload.identifier);

    const organization = payload.orgSlug
      ? this.db.prepare("SELECT id, slug, name FROM organizations WHERE slug = ?").get(payload.orgSlug)
      : aliasMatch
        ? this.db.prepare("SELECT id, slug, name FROM organizations WHERE id = ?").get(aliasMatch.org_id)
      : this.db.prepare(`
          SELECT organizations.id, organizations.slug, organizations.name
          FROM organizations
          JOIN memberships ON memberships.org_id = organizations.id
          JOIN users ON users.id = memberships.user_id
          WHERE lower(users.email) = lower(?)
          ORDER BY organizations.name
          LIMIT 1
        `).get(payload.identifier);

    if (!organization) {
      throw buildError(payload.orgSlug ? "Organization not found" : "Invalid email or password", payload.orgSlug ? 404 : 401);
    }

    const row = this.db.prepare(`
      SELECT users.*, memberships.role, auth_accounts.password_salt, auth_accounts.password_hash, auth_accounts.must_rotate_password
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      JOIN auth_accounts ON auth_accounts.user_id = users.id
      LEFT JOIN demo_login_aliases ON demo_login_aliases.user_id = users.id AND demo_login_aliases.org_id = memberships.org_id
      WHERE memberships.org_id = ?
        AND (
          lower(users.email) = lower(?)
          OR lower(demo_login_aliases.alias) = lower(?)
        )
    `).get(organization.id, payload.identifier, payload.identifier);

    const pendingInvite = this.db.prepare(`
      SELECT id, accepted_at, expires_at
      FROM employee_invites
      WHERE org_id = ? AND lower(email) = lower(?)
      ORDER BY datetime(created_at) DESC
      LIMIT 1
    `).get(organization.id, payload.identifier);

    if (pendingInvite && !pendingInvite.accepted_at) {
      if (new Date(pendingInvite.expires_at).valueOf() < Date.now()) {
        throw buildError("Invite expired. Request a new invitation.", 403);
      }

      throw buildError("Invite must be accepted before login", 403);
    }

    if (!row || !verifyPassword(payload.password, row.password_salt, row.password_hash)) {
      throw buildError("Invalid email or password", 401);
    }

    const createdAt = nowIso();
    const sessionToken = createOpaqueToken("sess");
    const expiresAt = addDays(createdAt, this.sessionTtlDays);

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO api_sessions (
          id, org_id, user_id, membership_role, token_hash, label, created_at, last_seen_at, expires_at, revoked_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
      `).run(
        `sess-${randomUUID().slice(0, 12)}`,
        organization.id,
        row.id,
        row.role,
        hashToken(sessionToken),
        payload.label || "desktop-login",
        createdAt,
        createdAt,
        expiresAt,
      );

      this.db.prepare(`
        UPDATE auth_accounts
        SET last_login_at = ?, updated_at = ?
        WHERE user_id = ?
      `).run(createdAt, createdAt, row.id);

      this.db.prepare(`
        UPDATE local_session_state
        SET org_id = ?, current_user_id = ?, current_role = ?, current_session_token = ?, updated_at = ?
        WHERE id = 1
      `).run(organization.id, row.id, row.role, sessionToken, createdAt);

      this.logAuditEvent({
        orgId: organization.id,
        actorUserId: row.id,
        targetUserId: row.id,
        eventType: "auth.login",
        summary: `${row.name} signed into ${organization.name}.`,
        metadata: {
          label: payload.label || "desktop-login",
        },
      });
    });

    return {
      sessionToken,
      expiresAt,
      user: this.hydrateUser(organization.id, row),
      organization: this.getWorkspace(organization.id),
      mustRotatePassword: Boolean(row.must_rotate_password),
      workspace: this.snapshot(organization.id, row.id),
    };
  }

  listAvailableCompanyRegistrationCodes() {
    this.init();
    return this.db.prepare(`
      SELECT code, label, plan_name, seat_limit
      FROM company_registration_codes
      WHERE claimed_at IS NULL
      ORDER BY plan_name, code
    `).all().map((row) => ({
      code: row.code,
      label: row.label,
      planName: row.plan_name,
      seatLimit: row.seat_limit,
    }));
  }

  listDemoAccounts() {
    this.init();
    return this.db.prepare(`
      SELECT demo_login_aliases.alias, demo_login_aliases.label, memberships.role, users.name
      FROM demo_login_aliases
      JOIN users ON users.id = demo_login_aliases.user_id
      JOIN memberships ON memberships.user_id = users.id AND memberships.org_id = demo_login_aliases.org_id
      ORDER BY demo_login_aliases.alias
    `).all().map((row) => ({
      alias: row.alias,
      label: row.label,
      role: row.role === "employee" ? "employee" : "admin",
      name: row.name,
      password: this.bootstrapPassword,
    }));
  }

  registerCompany(payload) {
    this.init();
    const registration = this.db.prepare(`
      SELECT *
      FROM company_registration_codes
      WHERE upper(code) = upper(?)
    `).get(payload.registrationCode);

    if (!registration) {
      throw buildError("Registration code not found", 404);
    }

    if (registration.claimed_at) {
      throw buildError("Registration code has already been used", 409);
    }

    const existingUser = this.db.prepare(`
      SELECT id
      FROM users
      WHERE lower(email) = lower(?)
    `).get(payload.adminEmail);

    if (existingUser) {
      throw buildError("Admin email already exists", 400);
    }

    const createdAt = nowIso();
    const expiresAt = addDays(createdAt, this.sessionTtlDays);
    const orgSlug = this.createUniqueOrgSlug(payload.companyName);
    const orgId = `org-${orgSlug}`;
    const adminUserId = `admin-${slugify(payload.adminName)}-${randomUUID().slice(0, 8)}`;
    const sessionToken = createOpaqueToken("sess");
    const passwordRecord = createPasswordRecord(payload.password);
    const observedApps = JSON.parse(registration.observed_apps_json);

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO organizations (
          id, name, slug, plan_name, seat_limit, seats_used, approval_sla, deployment_mode, audit_cycle_days, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
      `).run(
        orgId,
        payload.companyName,
        orgSlug,
        registration.plan_name,
        registration.seat_limit,
        registration.approval_sla,
        registration.deployment_mode,
        registration.audit_cycle_days,
        createdAt,
        createdAt,
      );

      observedApps.forEach((appName, index) => {
        this.db.prepare(`
          INSERT INTO organization_observed_apps (org_id, sort_order, name)
          VALUES (?, ?, ?)
        `).run(orgId, index, appName);
      });

      this.db.prepare(`
        INSERT INTO users (
          id, name, title, email, team, status, consent_status, last_seen, reclaimable_hours, automation_readiness, created_at, updated_at
        ) VALUES (?, ?, ?, ?, NULL, NULL, NULL, ?, 0, 0, ?, ?)
      `).run(
        adminUserId,
        payload.adminName,
        "Workspace Administrator",
        payload.adminEmail,
        "Just registered",
        createdAt,
        createdAt,
      );

      this.db.prepare(`
        INSERT INTO memberships (
          id, org_id, user_id, role, status, sort_order, created_at, updated_at
        ) VALUES (?, ?, ?, 'admin', 'active', 0, ?, ?)
      `).run(`mem-${orgId}-${adminUserId}`, orgId, adminUserId, createdAt, createdAt);

      this.db.prepare(`
        INSERT INTO auth_accounts (
          user_id, password_salt, password_hash, must_rotate_password, created_at, updated_at
        ) VALUES (?, ?, ?, 0, ?, ?)
      `).run(adminUserId, passwordRecord.salt, passwordRecord.hash, createdAt, createdAt);

      this.db.prepare(`
        INSERT INTO api_sessions (
          id, org_id, user_id, membership_role, token_hash, label, created_at, last_seen_at, expires_at, revoked_at
        ) VALUES (?, ?, ?, 'admin', ?, ?, ?, ?, ?, NULL)
      `).run(
        `sess-${randomUUID().slice(0, 12)}`,
        orgId,
        adminUserId,
        hashToken(sessionToken),
        payload.label || "company-registration",
        createdAt,
        createdAt,
        expiresAt,
      );

      this.db.prepare(`
        UPDATE local_session_state
        SET org_id = ?, current_user_id = ?, current_role = 'admin', current_session_token = ?, updated_at = ?
        WHERE id = 1
      `).run(orgId, adminUserId, sessionToken, createdAt);

      this.db.prepare(`
        UPDATE company_registration_codes
        SET claimed_at = ?, claimed_org_id = ?, claimed_by_user_id = ?
        WHERE id = ?
      `).run(createdAt, orgId, adminUserId, registration.id);

      this.logAuditEvent({
        orgId,
        actorUserId: adminUserId,
        targetUserId: adminUserId,
        eventType: "organization.registered",
        summary: `${payload.companyName} registered with ${registration.plan_name} plan access.`,
        metadata: {
          registrationCode: registration.code,
          planName: registration.plan_name,
        },
      });
    });

    return {
      sessionToken,
      expiresAt,
      user: this.hydrateUser(orgId, {
        id: adminUserId,
        role: "admin",
        name: payload.adminName,
        email: payload.adminEmail,
        title: "Workspace Administrator",
      }),
      organization: this.getWorkspace(orgId),
      mustRotatePassword: false,
      workspace: this.snapshot(orgId, adminUserId),
    };
  }

  listEmployeeInvites(orgId = null) {
    this.init();
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT employee_invites.*, users.id AS user_id, organizations.name AS organization_name
      FROM employee_invites
      JOIN organizations ON organizations.id = employee_invites.org_id
      LEFT JOIN users ON lower(users.email) = lower(employee_invites.email)
      LEFT JOIN memberships ON memberships.user_id = users.id AND memberships.org_id = employee_invites.org_id
      WHERE employee_invites.org_id = ?
      ORDER BY datetime(employee_invites.created_at) DESC
    `).all(resolvedOrgId).map((row) => ({
      id: row.id,
      orgId: row.org_id,
      organizationName: row.organization_name,
      userId: row.user_id || null,
      email: row.email,
      name: row.name,
      title: row.title,
      team: row.team,
      role: row.role,
      createdAt: row.created_at,
      acceptedAt: row.accepted_at,
      expiresAt: row.expires_at,
      status: row.accepted_at
        ? "accepted"
        : new Date(row.expires_at).valueOf() < Date.now()
          ? "expired"
          : "pending",
    }));
  }

  getInvitePreview(inviteToken) {
    this.init();
    const invite = this.getInviteByToken(inviteToken);
    this.assertInviteIsUsable(invite);

    return {
      id: invite.id,
      orgId: invite.orgId,
      organizationName: invite.organizationName,
      email: invite.email,
      name: invite.name,
      title: invite.title,
      team: invite.team,
      role: invite.role,
      expiresAt: invite.expiresAt,
    };
  }

  acceptInvite(payload) {
    this.init();
    const invite = this.getInviteByToken(payload.inviteToken);
    this.assertInviteIsUsable(invite);

    const user = this.db.prepare(`
      SELECT users.*, memberships.role
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND lower(users.email) = lower(?) AND memberships.role = ?
    `).get(invite.orgId, invite.email, invite.role);

    if (!user) {
      throw buildError("Invite target user is missing", 404);
    }

    const createdAt = nowIso();
    const expiresAt = addDays(createdAt, this.sessionTtlDays);
    const sessionToken = createOpaqueToken("sess");
    const passwordRecord = createPasswordRecord(payload.password);

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE auth_accounts
        SET password_salt = ?, password_hash = ?, must_rotate_password = 0, last_login_at = ?, updated_at = ?
        WHERE user_id = ?
      `).run(passwordRecord.salt, passwordRecord.hash, createdAt, createdAt, user.id);

      this.db.prepare(`
        UPDATE employee_invites
        SET accepted_at = ?
        WHERE id = ?
      `).run(createdAt, invite.id);

      this.db.prepare(`
        UPDATE users
        SET status = ?, consent_status = ?, last_seen = ?, updated_at = ?
        WHERE id = ?
      `).run("awaiting-consent", "pending", "Invite accepted", createdAt, user.id);

      this.db.prepare(`
        INSERT INTO api_sessions (
          id, org_id, user_id, membership_role, token_hash, label, created_at, last_seen_at, expires_at, revoked_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
      `).run(
        `sess-${randomUUID().slice(0, 12)}`,
        invite.orgId,
        user.id,
        invite.role,
        hashToken(sessionToken),
        payload.label || "invite-acceptance",
        createdAt,
        createdAt,
        expiresAt,
      );

      this.db.prepare(`
        UPDATE local_session_state
        SET org_id = ?, current_user_id = ?, current_role = ?, current_session_token = ?, updated_at = ?
        WHERE id = 1
      `).run(invite.orgId, user.id, invite.role, sessionToken, createdAt);

      this.logAuditEvent({
        orgId: invite.orgId,
        actorUserId: user.id,
        targetUserId: user.id,
        eventType: "invite.accepted",
        summary: `${invite.name} accepted their workspace invitation.`,
        metadata: {
          inviteId: invite.id,
          email: invite.email,
        },
      });
    });

    return {
      sessionToken,
      expiresAt,
      user: this.hydrateUser(invite.orgId, {
        ...user,
        role: invite.role,
      }),
      organization: this.getWorkspace(invite.orgId),
      mustRotatePassword: false,
      workspace: this.snapshot(invite.orgId, user.id),
    };
  }

  logout(sessionToken) {
    this.init();
    const session = this.getApiSession(sessionToken);
    if (!session) {
      return { ok: true };
    }

    const timestamp = nowIso();
    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE api_sessions
        SET revoked_at = ?, last_seen_at = ?
        WHERE id = ?
      `).run(timestamp, timestamp, session.id);

      const localSession = this.getLocalSessionState();
      if (localSession.currentSessionToken === sessionToken) {
        this.db.prepare(`
          UPDATE local_session_state
          SET current_session_token = NULL, updated_at = ?
          WHERE id = 1
        `).run(timestamp);
      }

      this.logAuditEvent({
        orgId: session.orgId,
        actorUserId: session.userId,
        targetUserId: session.userId,
        eventType: "auth.logout",
        summary: `${session.userName} signed out.`,
        metadata: {},
      });
    });

    return { ok: true };
  }

  changePassword(orgId, userId, sessionToken, payload) {
    this.init();
    const auth = this.db.prepare(`
      SELECT auth_accounts.password_salt, auth_accounts.password_hash, auth_accounts.must_rotate_password, users.name
      FROM auth_accounts
      JOIN users ON users.id = auth_accounts.user_id
      JOIN memberships ON memberships.user_id = users.id
      WHERE auth_accounts.user_id = ? AND memberships.org_id = ?
    `).get(userId, orgId);

    if (!auth) {
      throw buildError("User account not found", 404);
    }

    if (!verifyPassword(payload.currentPassword, auth.password_salt, auth.password_hash)) {
      throw buildError("Current password is incorrect", 401);
    }

    const passwordRecord = createPasswordRecord(payload.newPassword);
    const timestamp = nowIso();
    const currentSession = this.getApiSession(sessionToken);
    let revokedSessions = 0;

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE auth_accounts
        SET password_salt = ?, password_hash = ?, must_rotate_password = 0, updated_at = ?
        WHERE user_id = ?
      `).run(passwordRecord.salt, passwordRecord.hash, timestamp, userId);

      if (payload.revokeOtherSessions && currentSession) {
        const result = this.db.prepare(`
          UPDATE api_sessions
          SET revoked_at = ?, last_seen_at = ?
          WHERE org_id = ? AND user_id = ? AND revoked_at IS NULL AND id != ?
        `).run(timestamp, timestamp, orgId, userId, currentSession.id);
        revokedSessions = result.changes;
      }

      this.logAuditEvent({
        orgId,
        actorUserId: userId,
        targetUserId: userId,
        eventType: "auth.password_changed",
        summary: `${auth.name} changed their password.`,
        metadata: {
          revokedSessions,
        },
      });
    });

    return {
      ok: true,
      revokedSessions,
      mustRotatePassword: false,
    };
  }

  requestPasswordReset(payload) {
    this.init();
    const organization = payload.orgSlug
      ? this.db.prepare("SELECT id, slug, name FROM organizations WHERE slug = ?").get(payload.orgSlug)
      : this.db.prepare("SELECT id, slug, name FROM organizations ORDER BY name LIMIT 1").get();

    if (!organization) {
      return { ok: true, resetRequest: null };
    }

    const user = this.db.prepare(`
      SELECT users.id, users.name, users.email, memberships.role
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      JOIN auth_accounts ON auth_accounts.user_id = users.id
      WHERE memberships.org_id = ? AND lower(users.email) = lower(?)
      LIMIT 1
    `).get(organization.id, payload.email);

    if (!user) {
      return { ok: true, resetRequest: null };
    }

    const pendingInvite = this.db.prepare(`
      SELECT id, accepted_at, expires_at
      FROM employee_invites
      WHERE org_id = ? AND lower(email) = lower(?)
      ORDER BY datetime(created_at) DESC
      LIMIT 1
    `).get(organization.id, payload.email);

    if (pendingInvite && !pendingInvite.accepted_at && new Date(pendingInvite.expires_at).valueOf() >= Date.now()) {
      return { ok: true, resetRequest: null };
    }

    const createdAt = nowIso();
    const expiresAt = addDays(createdAt, 1);
    const resetToken = createOpaqueToken("reset");

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO password_reset_tokens (
          id, org_id, user_id, token_hash, created_at, expires_at, used_at
        ) VALUES (?, ?, ?, ?, ?, ?, NULL)
      `).run(
        `reset-${randomUUID().slice(0, 12)}`,
        organization.id,
        user.id,
        hashToken(resetToken),
        createdAt,
        expiresAt,
      );

      this.logAuditEvent({
        orgId: organization.id,
        actorUserId: null,
        targetUserId: user.id,
        eventType: "auth.password_reset_requested",
        summary: `Password reset requested for ${user.name}.`,
        metadata: {},
      });
    });

    return {
      ok: true,
      resetRequest: {
        orgId: organization.id,
        organizationName: organization.name,
        userId: user.id,
        name: user.name,
        email: user.email,
        expiresAt,
        resetToken,
      },
    };
  }

  resetPassword(payload) {
    this.init();
    const row = this.db.prepare(`
      SELECT password_reset_tokens.*, users.name AS user_name, users.email AS user_email, memberships.role, organizations.name AS organization_name
      FROM password_reset_tokens
      JOIN users ON users.id = password_reset_tokens.user_id
      JOIN memberships ON memberships.user_id = users.id AND memberships.org_id = password_reset_tokens.org_id
      JOIN organizations ON organizations.id = password_reset_tokens.org_id
      WHERE password_reset_tokens.token_hash = ?
    `).get(hashToken(payload.resetToken));

    if (!row) {
      throw buildError("Reset token not found", 404);
    }

    if (row.used_at) {
      throw buildError("Reset token already used", 410);
    }

    if (new Date(row.expires_at).valueOf() < Date.now()) {
      throw buildError("Reset token expired", 410);
    }

    const passwordRecord = createPasswordRecord(payload.newPassword);
    const timestamp = nowIso();
    const sessionToken = createOpaqueToken("sess");
    const expiresAt = addDays(timestamp, this.sessionTtlDays);

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE auth_accounts
        SET password_salt = ?, password_hash = ?, must_rotate_password = 0, last_login_at = ?, updated_at = ?
        WHERE user_id = ?
      `).run(passwordRecord.salt, passwordRecord.hash, timestamp, timestamp, row.user_id);

      this.db.prepare(`
        UPDATE password_reset_tokens
        SET used_at = ?
        WHERE id = ?
      `).run(timestamp, row.id);

      this.db.prepare(`
        UPDATE api_sessions
        SET revoked_at = ?, last_seen_at = ?
        WHERE org_id = ? AND user_id = ? AND revoked_at IS NULL
      `).run(timestamp, timestamp, row.org_id, row.user_id);

      this.db.prepare(`
        INSERT INTO api_sessions (
          id, org_id, user_id, membership_role, token_hash, label, created_at, last_seen_at, expires_at, revoked_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
      `).run(
        `sess-${randomUUID().slice(0, 12)}`,
        row.org_id,
        row.user_id,
        row.role,
        hashToken(sessionToken),
        payload.label || "password-reset",
        timestamp,
        timestamp,
        expiresAt,
      );

      this.db.prepare(`
        UPDATE local_session_state
        SET org_id = ?, current_user_id = ?, current_role = ?, current_session_token = ?, updated_at = ?
        WHERE id = 1
      `).run(row.org_id, row.user_id, row.role, sessionToken, timestamp);

      this.logAuditEvent({
        orgId: row.org_id,
        actorUserId: row.user_id,
        targetUserId: row.user_id,
        eventType: "auth.password_reset_completed",
        summary: `${row.user_name} reset their password.`,
        metadata: {},
      });
    });

    return {
      sessionToken,
      expiresAt,
      user: this.hydrateUser(row.org_id, {
        id: row.user_id,
        role: row.role,
        name: row.user_name,
        email: row.user_email,
        title: "",
        team: "",
      }),
      organization: this.getWorkspace(row.org_id),
      mustRotatePassword: false,
      workspace: this.snapshot(row.org_id, row.user_id),
    };
  }

  getAuthSession(sessionToken) {
    this.init();
    const session = this.getApiSession(sessionToken);
    if (!session) {
      throw buildError("Session not found", 404);
    }

    this.db.prepare(`
      UPDATE api_sessions
      SET last_seen_at = ?
      WHERE id = ?
    `).run(nowIso(), session.id);

    return {
      sessionToken,
      expiresAt: session.expiresAt,
      organization: this.getWorkspace(session.orgId),
      user: this.hydrateUser(session.orgId, session.userRow),
      role: session.role,
    };
  }

  listApiSessions(orgId, currentSessionToken, userId) {
    this.init();
    const currentTokenHash = currentSessionToken ? hashToken(currentSessionToken) : "";
    return this.db.prepare(`
      SELECT api_sessions.*, users.name AS user_name, users.email AS user_email
      FROM api_sessions
      JOIN users ON users.id = api_sessions.user_id
      WHERE api_sessions.org_id = ? AND api_sessions.user_id = ?
      ORDER BY datetime(api_sessions.created_at) DESC
    `).all(orgId, userId).map((row) => {
      const expired = new Date(row.expires_at).valueOf() < Date.now();
      const revoked = Boolean(row.revoked_at);
      return {
        id: row.id,
        userId: row.user_id,
        userName: row.user_name,
        userEmail: row.user_email,
        label: row.label,
        createdAt: row.created_at,
        lastSeenAt: row.last_seen_at,
        expiresAt: row.expires_at,
        revokedAt: row.revoked_at,
        isCurrent: currentTokenHash && row.token_hash === currentTokenHash,
        status: revoked ? "revoked" : expired ? "expired" : "active",
      };
    });
  }

  revokeSession(orgId, actorUserId, sessionId, currentSessionToken) {
    this.init();
    const session = this.db.prepare(`
      SELECT api_sessions.*, users.name AS user_name
      FROM api_sessions
      JOIN users ON users.id = api_sessions.user_id
      WHERE api_sessions.org_id = ? AND api_sessions.id = ?
    `).get(orgId, sessionId);

    if (!session) {
      throw buildError("Session not found", 404);
    }

    const timestamp = nowIso();
    const currentTokenHash = currentSessionToken ? hashToken(currentSessionToken) : "";
    const revokedCurrentSession = Boolean(currentTokenHash && session.token_hash === currentTokenHash);

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE api_sessions
        SET revoked_at = COALESCE(revoked_at, ?), last_seen_at = ?
        WHERE id = ?
      `).run(timestamp, timestamp, session.id);

      if (revokedCurrentSession) {
        this.db.prepare(`
          UPDATE local_session_state
          SET current_session_token = NULL, updated_at = ?
          WHERE id = 1
        `).run(timestamp);
      }

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: session.user_id,
        eventType: "auth.session_revoked",
        summary: `A session for ${session.user_name} was revoked.`,
        metadata: {
          sessionId: session.id,
          revokedCurrentSession,
        },
      });
    });

    return {
      ok: true,
      revokedCurrentSession,
      sessions: this.listApiSessions(orgId, currentSessionToken, session.user_id),
    };
  }

  listIntegrations(orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT integrations.*, users.name AS connected_by_name
      FROM integrations
      LEFT JOIN users ON users.id = integrations.connected_by_user_id
      WHERE integrations.org_id = ?
      ORDER BY integrations.provider
    `).all(resolvedOrgId).map((row) => ({
      id: row.id,
      provider: row.provider,
      displayName: row.display_name,
      status: row.status,
      connectionMode: row.connection_mode,
      healthStatus: row.health_status,
      scopes: JSON.parse(row.scopes_json),
      externalAccountRef: row.external_account_ref,
      connectedByUserId: row.connected_by_user_id,
      connectedByName: row.connected_by_name,
      lastSyncAt: row.last_sync_at,
      updatedAt: row.updated_at,
      requirements: PROVIDERS[row.provider]?.env || [],
    }));
  }

  connectIntegration(orgId, actorUserId, payload) {
    this.init();
    const existing = this.db.prepare(`
      SELECT id
      FROM integrations
      WHERE org_id = ? AND provider = ?
    `).get(orgId, payload.provider);

    const timestamp = nowIso();
    const status = payload.externalAccountRef ? "connected" : "configured";
    const healthStatus = payload.externalAccountRef ? "healthy" : "awaiting-credentials";

    this.withTransaction(() => {
      if (existing) {
        this.db.prepare(`
          UPDATE integrations
          SET display_name = ?, status = ?, connection_mode = ?, scopes_json = ?, health_status = ?, external_account_ref = ?, connected_by_user_id = ?, updated_at = ?
          WHERE id = ?
        `).run(
          payload.displayName,
          status,
          payload.connectionMode,
          JSON.stringify(payload.scopes),
          healthStatus,
          payload.externalAccountRef || null,
          actorUserId,
          timestamp,
          existing.id,
        );
      } else {
        this.db.prepare(`
          INSERT INTO integrations (
            id, org_id, provider, display_name, status, connection_mode, scopes_json, health_status, external_account_ref, connected_by_user_id, last_sync_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
        `).run(
          `int-${payload.provider}-${randomUUID().slice(0, 8)}`,
          orgId,
          payload.provider,
          payload.displayName,
          status,
          payload.connectionMode,
          JSON.stringify(payload.scopes),
          healthStatus,
          payload.externalAccountRef || null,
          actorUserId,
          timestamp,
          timestamp,
        );
      }

      this.logAuditEvent({
        orgId,
        actorUserId,
        eventType: "integration.connected",
        summary: `${payload.displayName} integration was ${status}.`,
        metadata: {
          provider: payload.provider,
          scopes: payload.scopes,
        },
      });
    });

    return {
      integrations: this.listIntegrations(orgId),
      provider: PROVIDERS[payload.provider],
    };
  }

  listDevices(orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT device_installs.*, users.name AS user_name, users.email AS user_email
      FROM device_installs
      JOIN users ON users.id = device_installs.user_id
      WHERE device_installs.org_id = ?
      ORDER BY users.name, device_installs.label
    `).all(resolvedOrgId).map((row) => ({
      id: row.id,
      userId: row.user_id,
      userName: row.user_name,
      userEmail: row.user_email,
      label: row.label,
      platform: row.platform,
      status: row.status,
      createdAt: row.created_at,
      lastSeenAt: row.last_seen_at,
    }));
  }

  registerDevice(orgId, actorUserId, payload) {
    this.init();
    const membership = this.getMembershipByUserId(orgId, payload.userId);

    if (!membership) {
      throw buildError("User not found in organization", 404);
    }

    const ingestKey = createOpaqueToken("ingest");
    const deviceId = `dev-${randomUUID().slice(0, 12)}`;
    const timestamp = nowIso();

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO device_installs (
          id, org_id, user_id, label, platform, status, ingest_key_hash, created_at, last_seen_at
        ) VALUES (?, ?, ?, ?, ?, 'active', ?, ?, NULL)
      `).run(deviceId, orgId, payload.userId, payload.label, payload.platform, hashToken(ingestKey), timestamp);

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: payload.userId,
        eventType: "device.registered",
        summary: `Registered device ${payload.label} for ${membership.userName}.`,
        metadata: {
          deviceId,
          platform: payload.platform,
        },
      });
    });

    return {
      deviceId,
      ingestKey,
      device: this.listDevices(orgId).find((device) => device.id === deviceId),
    };
  }

  revokeDevice(orgId, actorUserId, deviceId) {
    this.init();
    const device = this.db.prepare(`
      SELECT device_installs.*, users.name AS user_name
      FROM device_installs
      JOIN users ON users.id = device_installs.user_id
      WHERE device_installs.org_id = ? AND device_installs.id = ?
    `).get(orgId, deviceId);

    if (!device) {
      throw buildError("Device not found", 404);
    }

    const timestamp = nowIso();
    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE device_installs
        SET status = 'revoked', last_seen_at = COALESCE(last_seen_at, ?)
        WHERE id = ?
      `).run(timestamp, deviceId);

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: device.user_id,
        eventType: "device.revoked",
        summary: `Revoked device ${device.label} for ${device.user_name}.`,
        metadata: {
          deviceId,
          platform: device.platform,
        },
      });
    });

    return {
      ok: true,
      deviceId,
      devices: this.listDevices(orgId),
    };
  }

  ingestObserverBatch(payload) {
    this.init();
    const device = this.getDeviceByCredentials(payload.deviceId, payload.ingestKey);

    if (!device) {
      throw buildError("Invalid device credentials", 401);
    }

    const normalizedEvents = normalizeObserverEvents(payload.provider, payload.events);
    const timestamp = nowIso();
    let inserted = 0;
    let duplicates = 0;
    let rejected = 0;

    this.withTransaction(() => {
      this.ensureIntegration(device.orgId, payload.provider, device.userId);

      normalizedEvents.forEach((event) => {
        const targetUser = this.findUserByEmailInOrg(device.orgId, event.userEmail) || this.getUserById(device.userId);
        if (!targetUser) {
          rejected += 1;
          return;
        }

        const existing = this.db.prepare(`
          SELECT id
          FROM observed_actions
          WHERE org_id = ? AND source = ? AND source_key = ?
        `).get(device.orgId, event.provider, event.sourceKey);

        if (existing) {
          duplicates += 1;
          return;
        }

        this.db.prepare(`
          INSERT INTO observed_actions (
            id, org_id, user_id, occurred_at, source, source_key, app_name, category, description, payload_json, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          `obs-${randomUUID().slice(0, 12)}`,
          device.orgId,
          targetUser.id,
          event.occurredAt,
          event.provider,
          event.sourceKey,
          event.appName,
          event.category,
          event.description,
          JSON.stringify(redactObserverEvent(event.provider, event.rawEvent, this.observerRedactionMode)),
          timestamp,
        );

        this.touchUserActivity(targetUser.id, payload.provider, event.appName);
        inserted += 1;
      });

      this.db.prepare(`
        UPDATE device_installs
        SET last_seen_at = ?
        WHERE id = ?
      `).run(timestamp, device.id);

      this.db.prepare(`
        UPDATE integrations
        SET status = 'connected', health_status = 'healthy', last_sync_at = ?, updated_at = ?
        WHERE org_id = ? AND provider = ?
      `).run(timestamp, timestamp, device.orgId, payload.provider);

      this.logAuditEvent({
        orgId: device.orgId,
        actorUserId: device.userId,
        targetUserId: device.userId,
        eventType: "observer.ingested",
        summary: `Ingested ${inserted} ${payload.provider} events from ${device.label}.`,
        metadata: {
          provider: payload.provider,
          inserted,
          duplicates,
          rejected,
        },
      });

      this.applyObservedActionRetention(new Date(timestamp));
    });

    return {
      received: payload.events.length,
      inserted,
      duplicates,
      rejected,
      devices: this.listDevices(device.orgId),
      integrations: this.listIntegrations(device.orgId),
    };
  }

  recordLocalObserverEvents(orgId, actorUserId, payload) {
    this.init();
    const device = this.db.prepare(`
      SELECT device_installs.*, users.name AS user_name
      FROM device_installs
      JOIN users ON users.id = device_installs.user_id
      WHERE device_installs.org_id = ? AND device_installs.id = ? AND device_installs.status = 'active'
    `).get(orgId, payload.deviceId);

    if (!device) {
      throw buildError("Observer device not found", 404);
    }

    const membership = this.getMembershipByUserId(orgId, actorUserId);
    if (!membership) {
      throw buildError("Membership not found", 404);
    }

    if (membership.role === "employee" && device.user_id !== actorUserId) {
      throw buildError("Employees may only submit observer events for their own device", 403);
    }

    let inserted = 0;
    let duplicates = 0;
    const timestamp = nowIso();

    this.withTransaction(() => {
      payload.events.forEach((event) => {
        const existing = this.db.prepare(`
          SELECT id
          FROM observed_actions
          WHERE org_id = ? AND source = 'desktop-observer' AND source_key = ?
        `).get(orgId, event.sourceKey);

        if (existing) {
          duplicates += 1;
          return;
        }

        this.db.prepare(`
          INSERT INTO observed_actions (
            id, org_id, user_id, occurred_at, source, source_key, app_name, category, description, payload_json, created_at
          ) VALUES (?, ?, ?, ?, 'desktop-observer', ?, ?, ?, ?, ?, ?)
        `).run(
          `obs-${randomUUID().slice(0, 12)}`,
          orgId,
          device.user_id,
          event.occurredAt,
          event.sourceKey,
          event.appName,
          event.screenType,
          event.description,
          JSON.stringify({
            appId: event.appId,
            windowTitle: event.windowTitle,
            semanticAction: event.semanticAction,
            workflowHint: event.workflowHint,
            confidenceScore: event.confidenceScore,
            cursorX: event.cursorX,
            cursorY: event.cursorY,
            clickCount: event.clickCount,
            inputMode: event.inputMode,
            captureReason: event.captureReason,
            interactionSummary: event.interactionSummary,
            transcript: Array.isArray(event.transcript) ? event.transcript : [],
            screenSummary: event.screenSummary,
          }),
          timestamp,
        );

        inserted += 1;
        this.touchUserActivity(device.user_id, "desktop-observer", event.appName);
      });

      this.db.prepare(`
        UPDATE device_installs
        SET last_seen_at = ?
        WHERE id = ?
      `).run(timestamp, device.id);

      this.rebuildWorkflowSessions(orgId, device.user_id, device.id);
    });

    return {
      ok: true,
      inserted,
      duplicates,
      workflows: this.listWorkflowSessions(orgId, { employeeId: device.user_id, limit: 12 }),
      devices: this.listDevices(orgId),
    };
  }

  rebuildWorkflowSessions(orgId, userId, deviceId = null) {
    const rows = this.db.prepare(`
      SELECT id, occurred_at, app_name, category, description, payload_json
      FROM observed_actions
      WHERE org_id = ? AND user_id = ? AND source = 'desktop-observer'
      ORDER BY datetime(occurred_at)
    `).all(orgId, userId);

    const sessions = [];
    let current = null;

    rows.forEach((row) => {
      const payload = parseJsonSafe(row.payload_json, {});
      const entry = {
        id: row.id,
        occurredAt: row.occurred_at,
        appName: row.app_name,
        screenType: row.category || payload.screenType || "workspace",
        description: row.description,
        workflowHint: payload.workflowHint || "",
        semanticAction: payload.semanticAction || "reviewing",
        confidenceScore: Number(payload.confidenceScore) || 0,
        clickCount: Number(payload.clickCount) || 0,
        windowTitle: payload.windowTitle || "",
        interactionSummary: payload.interactionSummary || {},
        transcript: Array.isArray(payload.transcript) ? payload.transcript : [],
      };

      if (!current) {
        current = {
          startedAt: entry.occurredAt,
          endedAt: entry.occurredAt,
          steps: [entry],
          clickCount: entry.clickCount,
          keyPressCount: Number(entry.interactionSummary.keyPressCount) || 0,
          shortcutCount: Number(entry.interactionSummary.shortcutCount) || 0,
          deviceId,
        };
        return;
      }

      const gapMinutes = minutesBetween(current.endedAt, entry.occurredAt);
      const switchedApp = current.steps[current.steps.length - 1].appName !== entry.appName;

      if (gapMinutes > 20 || (switchedApp && gapMinutes > 5)) {
        sessions.push(current);
        current = {
          startedAt: entry.occurredAt,
          endedAt: entry.occurredAt,
          steps: [entry],
          clickCount: entry.clickCount,
          keyPressCount: Number(entry.interactionSummary.keyPressCount) || 0,
          shortcutCount: Number(entry.interactionSummary.shortcutCount) || 0,
          deviceId,
        };
        return;
      }

      current.steps.push(entry);
      current.endedAt = entry.occurredAt;
      current.clickCount += entry.clickCount;
      current.keyPressCount += Number(entry.interactionSummary.keyPressCount) || 0;
      current.shortcutCount += Number(entry.interactionSummary.shortcutCount) || 0;
    });

    if (current) {
      sessions.push(current);
    }

    this.db.prepare(`
      DELETE FROM workflow_sessions
      WHERE org_id = ? AND user_id = ? AND source = 'desktop-observer'
    `).run(orgId, userId);

    const insertWorkflow = this.db.prepare(`
      INSERT INTO workflow_sessions (
        id, org_id, user_id, device_id, source, workflow_label, primary_app, screen_type, confidence_score,
        started_at, ended_at, step_count, click_count, evidence_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'desktop-observer', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    sessions.forEach((session) => {
      const appCounts = new Map();
      const screenCounts = new Map();
      const workflowCounts = new Map();
      let confidenceTotal = 0;

      session.steps.forEach((step) => {
        appCounts.set(step.appName, (appCounts.get(step.appName) || 0) + 1);
        screenCounts.set(step.screenType, (screenCounts.get(step.screenType) || 0) + 1);
        if (step.workflowHint) {
          workflowCounts.set(step.workflowHint, (workflowCounts.get(step.workflowHint) || 0) + 1);
        }
        confidenceTotal += step.confidenceScore || 0;
      });

      const primaryApp = [...appCounts.entries()].sort((left, right) => right[1] - left[1])[0]?.[0] || "Desktop";
      const screenType = [...screenCounts.entries()].sort((left, right) => right[1] - left[1])[0]?.[0] || "workspace";
      const workflowLabel = [...workflowCounts.entries()].sort((left, right) => right[1] - left[1])[0]?.[0]
        || `${primaryApp.toLowerCase().replace(/\s+/g, "-")}-${screenType}`;
      const startedAt = session.startedAt;
      const endedAt = session.endedAt;
      const createdAt = nowIso();

      insertWorkflow.run(
        `wf-${randomUUID().slice(0, 12)}`,
        orgId,
        userId,
        session.deviceId,
        workflowLabel,
        primaryApp,
        screenType,
        Number((confidenceTotal / session.steps.length || 0).toFixed(2)),
        startedAt,
        endedAt,
        session.steps.length,
        session.clickCount,
        JSON.stringify({
          durationMinutes: minutesBetween(startedAt, endedAt),
          keyPressCount: session.keyPressCount,
          shortcutCount: session.shortcutCount,
          transcript: session.steps.flatMap((step) => (Array.isArray(step.transcript) ? step.transcript : [])).slice(-40),
          stepPreview: session.steps.slice(-8),
        }),
        createdAt,
        createdAt,
      );
    });
  }

  listWorkflowSessions(orgId = null, options = {}) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    const limit = Math.max(1, Math.min(50, options.limit || 12));
    const employeeId = options.employeeId || null;

    const rows = employeeId
      ? this.db.prepare(`
        SELECT workflow_sessions.*, users.name AS user_name, users.email AS user_email
        FROM workflow_sessions
        JOIN users ON users.id = workflow_sessions.user_id
        WHERE workflow_sessions.org_id = ? AND workflow_sessions.user_id = ?
        ORDER BY datetime(workflow_sessions.started_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, employeeId, limit)
      : this.db.prepare(`
        SELECT workflow_sessions.*, users.name AS user_name, users.email AS user_email
        FROM workflow_sessions
        JOIN users ON users.id = workflow_sessions.user_id
        WHERE workflow_sessions.org_id = ?
        ORDER BY datetime(workflow_sessions.started_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, limit);

    return rows.map((row) => {
      const evidence = parseJsonSafe(row.evidence_json, {});
      return {
        id: row.id,
        userId: row.user_id,
        userName: row.user_name,
        userEmail: row.user_email,
        workflowLabel: row.workflow_label,
        primaryApp: row.primary_app,
        screenType: row.screen_type,
        confidenceScore: row.confidence_score,
        startedAt: row.started_at,
        endedAt: row.ended_at,
        durationMinutes: evidence.durationMinutes || minutesBetween(row.started_at, row.ended_at),
        stepCount: row.step_count,
        clickCount: row.click_count,
        keyPressCount: evidence.keyPressCount || 0,
        shortcutCount: evidence.shortcutCount || 0,
        transcript: Array.isArray(evidence.transcript) ? evidence.transcript : [],
        steps: Array.isArray(evidence.stepPreview) ? evidence.stepPreview : [],
      };
    });
  }

  listObservedActions(orgId = null, options = {}) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    const limit = Math.max(1, Math.min(200, options.limit || 50));
    const provider = options.provider || null;
    const userId = options.userId || null;

    let rows;

    if (provider && userId) {
      rows = this.db.prepare(`
        SELECT observed_actions.*, users.name AS user_name, users.email AS user_email
        FROM observed_actions
        JOIN users ON users.id = observed_actions.user_id
        WHERE observed_actions.org_id = ? AND observed_actions.source = ? AND observed_actions.user_id = ?
        ORDER BY datetime(observed_actions.occurred_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, provider, userId, limit);
    } else if (provider) {
      rows = this.db.prepare(`
        SELECT observed_actions.*, users.name AS user_name, users.email AS user_email
        FROM observed_actions
        JOIN users ON users.id = observed_actions.user_id
        WHERE observed_actions.org_id = ? AND observed_actions.source = ?
        ORDER BY datetime(observed_actions.occurred_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, provider, limit);
    } else if (userId) {
      rows = this.db.prepare(`
        SELECT observed_actions.*, users.name AS user_name, users.email AS user_email
        FROM observed_actions
        JOIN users ON users.id = observed_actions.user_id
        WHERE observed_actions.org_id = ? AND observed_actions.user_id = ?
        ORDER BY datetime(observed_actions.occurred_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, userId, limit);
    } else {
      rows = this.db.prepare(`
        SELECT observed_actions.*, users.name AS user_name, users.email AS user_email
        FROM observed_actions
        JOIN users ON users.id = observed_actions.user_id
        WHERE observed_actions.org_id = ?
        ORDER BY datetime(observed_actions.occurred_at) DESC
        LIMIT ?
      `).all(resolvedOrgId, limit);
    }

    return rows.map((row) => ({
      id: row.id,
      userId: row.user_id,
      userName: row.user_name,
      userEmail: row.user_email,
      occurredAt: row.occurred_at,
      source: row.source,
      sourceKey: row.source_key,
      appName: row.app_name,
      category: row.category,
      description: row.description,
      payload: parseJsonSafe(row.payload_json, {}),
    }));
  }

  listAuditEvents(orgId = null, limit = 20) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT id, created_at, actor_user_id, actor_name, target_user_id, event_type, summary, metadata_json
      FROM audit_events
      WHERE org_id = ?
      ORDER BY datetime(created_at) DESC
      LIMIT ?
    `).all(resolvedOrgId, limit).map((row) => ({
      id: row.id,
      createdAt: row.created_at,
      actorUserId: row.actor_user_id,
      actorName: row.actor_name,
      targetUserId: row.target_user_id,
      eventType: row.event_type,
      summary: row.summary,
      metadata: JSON.parse(row.metadata_json),
    }));
  }

  listAutomationOpportunities(orgId = null, limit = 20) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT automations.*, users.name AS user_name, users.email AS user_email
      FROM automations
      JOIN users ON users.id = automations.user_id
      WHERE automations.org_id = ? AND automations.source = 'generated'
      ORDER BY automations.rank_score DESC, automations.projected_hours DESC, automations.name
      LIMIT ?
    `).all(resolvedOrgId, limit).map((row) => ({
      id: row.id,
      employeeId: row.user_id,
      employeeName: row.user_name,
      employeeEmail: row.user_email,
      name: row.name,
      scope: row.scope,
      mode: row.mode,
      status: row.status,
      impact: row.impact,
      confidenceScore: row.confidence_score,
      projectedHours: row.projected_hours,
      rankScore: row.rank_score,
      rationale: row.rationale,
      generatedAt: row.generated_at,
    }));
  }

  listRecommendationRuns(orgId = null, limit = 25) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT recommendation_runs.*, users.name AS user_name
      FROM recommendation_runs
      JOIN users ON users.id = recommendation_runs.user_id
      WHERE recommendation_runs.org_id = ?
      ORDER BY datetime(recommendation_runs.created_at) DESC
      LIMIT ?
    `).all(resolvedOrgId, limit).map((row) => ({
      id: row.id,
      employeeId: row.user_id,
      employeeName: row.user_name,
      observedActionCount: row.observed_action_count,
      generatedCount: row.generated_count,
      totalProjectedHours: row.total_projected_hours,
      automationReadiness: row.automation_readiness,
      trace: JSON.parse(row.trace_json),
      createdAt: row.created_at,
    }));
  }

  listReports(orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.listEmployees(resolvedOrgId).map((emp) => ({
      employeeId: emp.id,
      employeeName: emp.name,
      employeeEmail: emp.email,
      team: emp.team,
      reclaimableHours: emp.reclaimableHours,
      automationReadiness: emp.automationReadiness,
      headline: emp.report.headline,
      findings: emp.report.findings,
    }));
  }

  getReport(employeeId, orgId = null) {
    const employee = this.getEmployee(employeeId, orgId);
    return {
      employeeId: employee.id,
      employeeName: employee.name,
      employeeEmail: employee.email,
      team: employee.team,
      reclaimableHours: employee.reclaimableHours,
      automationReadiness: employee.automationReadiness,
      headline: employee.report.headline,
      findings: employee.report.findings,
      automations: employee.automations,
    };
  }

  listPlanChangeRequests(orgId = null) {
    const resolvedOrgId = orgId || this.getLocalSessionState().orgId;
    return this.db.prepare(`
      SELECT plan_change_requests.*, users.name AS requested_by_name, users.email AS requested_by_email
      FROM plan_change_requests
      JOIN users ON users.id = plan_change_requests.requested_by_user_id
      WHERE plan_change_requests.org_id = ?
      ORDER BY datetime(plan_change_requests.created_at) DESC
    `).all(resolvedOrgId).map((row) => ({
      id: row.id,
      requestType: row.request_type,
      requestedPlan: row.requested_plan || "",
      note: row.note,
      status: row.status,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      requestedByName: row.requested_by_name,
      requestedByEmail: row.requested_by_email,
    }));
  }

  requestPlanChange(orgId, actorUserId, payload) {
    this.init();
    const timestamp = nowIso();
    const requestId = `plan-${randomUUID().slice(0, 12)}`;

    this.withTransaction(() => {
      this.db.prepare(`
        INSERT INTO plan_change_requests (
          id, org_id, requested_by_user_id, request_type, requested_plan, note, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)
      `).run(
        requestId,
        orgId,
        actorUserId,
        payload.requestType,
        payload.requestedPlan || null,
        payload.note || "",
        timestamp,
        timestamp,
      );

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: null,
        eventType: "plan.change_requested",
        summary: `${formatStatus(payload.requestType)} plan request submitted${payload.requestedPlan ? ` for ${payload.requestedPlan}` : ""}.`,
        metadata: {
          requestType: payload.requestType,
          requestedPlan: payload.requestedPlan || null,
        },
      });
    });

    return this.snapshot(orgId, actorUserId);
  }

  recordReportAccess(orgId, actorUserId, employeeId, format) {
    this.init();
    const employee = this.getEmployee(employeeId, orgId);
    this.logAuditEvent({
      orgId,
      actorUserId,
      targetUserId: employeeId,
      eventType: "report.accessed",
      summary: `${employee.name}'s report was accessed.`,
      metadata: {
        format,
      },
    });
  }

  getReportCsv(employeeId, orgId = null) {
    const r = this.getReport(employeeId, orgId);
    const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const header = ["Employee", "Email", "Team", "Reclaimable Hours", "Automation Readiness", "Headline", "Findings"].join(",");
    const row = [
      esc(r.employeeName),
      esc(r.employeeEmail),
      esc(r.team),
      r.reclaimableHours,
      r.automationReadiness,
      esc(r.headline),
      esc(r.findings.join("; ")),
    ].join(",");
    return [header, row].join("\n");
  }

  setAutomationState(orgId, actorUserId, payload) {
    this.init();

    const employee = this.db.prepare(`
      SELECT users.id, users.name
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND users.id = ? AND memberships.role = 'employee'
    `).get(orgId, payload.employeeId);

    if (!employee) {
      throw buildError("Employee not found", 404);
    }

    const automation = this.db.prepare(`
      SELECT * FROM automations WHERE org_id = ? AND id = ? AND user_id = ?
    `).get(orgId, payload.automationId, payload.employeeId);

    if (!automation) {
      throw buildError("Automation not found", 404);
    }

    this.withTransaction(() => {
      this.db.prepare(`
        UPDATE automations SET status = ? WHERE org_id = ? AND id = ? AND user_id = ?
      `).run(payload.state, orgId, payload.automationId, payload.employeeId);

      this.logAuditEvent({
        orgId,
        actorUserId,
        targetUserId: payload.employeeId,
        eventType: "automation.state_changed",
        summary: `${automation.name} moved to ${payload.state} for ${employee.name}.`,
        metadata: { automationId: payload.automationId, state: payload.state },
      });
    });

    return this.snapshot(orgId, actorUserId);
  }

  getProviderCatalog() {
    return Object.values(PROVIDERS);
  }

  getWorkspace(orgId) {
    const row = this.db.prepare(`
      SELECT *
      FROM organizations
      WHERE id = ?
    `).get(orgId);

    if (!row) {
      throw buildError("Organization not found", 404);
    }

    const observedApps = this.db.prepare(`
      SELECT name
      FROM organization_observed_apps
      WHERE org_id = ?
      ORDER BY sort_order
    `).all(orgId).map((entry) => entry.name);

    return {
      id: row.id,
      slug: row.slug,
      name: row.name,
      plan: {
        name: row.plan_name,
        seatLimit: row.seat_limit,
        seatsUsed: row.seats_used,
        approvalSla: row.approval_sla,
        deploymentMode: row.deployment_mode,
        auditCycleDays: row.audit_cycle_days,
      },
      observedApps,
    };
  }

  getLocalSessionState() {
    const row = this.db.prepare(`
      SELECT org_id, current_user_id, current_role, current_session_token
      FROM local_session_state
      WHERE id = 1
    `).get();

    return {
      orgId: row.org_id,
      currentUserId: row.current_user_id,
      currentRole: row.current_role,
      currentSessionToken: row.current_session_token,
    };
  }

  getMembershipByUserId(orgId, userId) {
    const row = this.db.prepare(`
      SELECT memberships.*, users.name AS user_name, users.email AS user_email
      FROM memberships
      JOIN users ON users.id = memberships.user_id
      WHERE memberships.org_id = ? AND memberships.user_id = ?
    `).get(orgId, userId);

    if (!row) {
      return null;
    }

    return {
      id: row.id,
      orgId: row.org_id,
      userId: row.user_id,
      role: row.role,
      sortOrder: row.sort_order,
      userName: row.user_name,
      userEmail: row.user_email,
    };
  }

  listUsers(orgId) {
    const rows = this.db.prepare(`
      SELECT users.*, memberships.role, memberships.sort_order
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ?
      ORDER BY
        CASE
          WHEN memberships.role = 'support' THEN 0
          WHEN memberships.role = 'admin' THEN 1
          ELSE 2
        END,
        memberships.sort_order,
        users.name
    `).all(orgId);

    return rows.map((row) => this.hydrateUser(orgId, row));
  }

  hydrateUser(orgId, row) {
    const user = {
      id: row.id,
      role: row.role,
      name: row.name,
      title: row.title,
      email: row.email,
    };

    if (row.role !== "employee") {
      return user;
    }

    const profileSummary = this.db.prepare(`
      SELECT content
      FROM profile_points
      WHERE org_id = ? AND user_id = ?
      ORDER BY sort_order, id
    `).all(orgId, row.id).map((entry) => entry.content);

    const apps = this.db.prepare(`
      SELECT app_name
      FROM user_apps
      WHERE org_id = ? AND user_id = ?
      ORDER BY sort_order, id
    `).all(orgId, row.id).map((entry) => entry.app_name);

    const actions = this.db.prepare(`
      SELECT id, occurred_at, app_name, category, description, payload_json
      FROM observed_actions
      WHERE org_id = ? AND user_id = ?
      ORDER BY datetime(occurred_at)
    `).all(orgId, row.id).map((entry) => ({
      id: entry.id,
      timestamp: new Date(entry.occurred_at).toLocaleString("sv-SE", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      }).replace("T", " "),
      app: entry.app_name,
      category: entry.category,
      description: entry.description,
      payload: parseJsonSafe(entry.payload_json, {}),
    }));

    const workflowSessions = this.listWorkflowSessions(orgId, {
      employeeId: row.id,
      limit: 8,
    });

    const access = this.db.prepare(`
      SELECT id, app_name, method, status, visibility, updated_at
      FROM access_records
      WHERE org_id = ? AND user_id = ?
      ORDER BY app_name
    `).all(orgId, row.id).map((entry) => ({
      id: entry.id,
      app: entry.app_name,
      method: entry.method,
      status: entry.status,
      visibility: entry.visibility,
      updatedAt: entry.updated_at,
    }));

    const automations = this.db.prepare(`
      SELECT id, name, scope, mode, impact, status, employee_decision, admin_decision, summary,
             source, confidence_score, projected_hours, rank_score, rationale, generated_at
      FROM automations
      WHERE org_id = ? AND user_id = ?
      ORDER BY rank_score DESC, name
    `).all(orgId, row.id).map((entry) => ({
      id: entry.id,
      name: entry.name,
      scope: entry.scope,
      mode: entry.mode,
      impact: entry.impact,
      status: entry.status,
      employeeDecision: entry.employee_decision,
      adminDecision: entry.admin_decision,
      summary: entry.summary,
      source: entry.source,
      confidenceScore: entry.confidence_score,
      projectedHours: entry.projected_hours,
      rankScore: entry.rank_score,
      rationale: entry.rationale,
      generatedAt: entry.generated_at,
    }));

    const report = this.db.prepare(`
      SELECT headline
      FROM reports
      WHERE org_id = ? AND user_id = ?
    `).get(orgId, row.id);

    const findings = this.db.prepare(`
      SELECT finding
      FROM report_findings
      WHERE org_id = ? AND user_id = ?
      ORDER BY sort_order, id
    `).all(orgId, row.id).map((entry) => entry.finding);

    return {
      ...user,
      team: row.team,
      status: row.status,
      consentStatus: row.consent_status,
      lastSeen: row.last_seen,
      reclaimableHours: row.reclaimable_hours || 0,
      automationReadiness: row.automation_readiness || 0,
      profileSummary,
      apps,
      actions,
      workflowSessions,
      access,
      automations,
      report: {
        headline: report?.headline || "No report generated yet.",
        findings,
      },
    };
  }

  getApiSession(sessionToken) {
    const tokenHash = hashToken(sessionToken);
    const row = this.db.prepare(`
      SELECT api_sessions.*, users.name AS user_name, users.email AS user_email, users.title AS user_title, users.team AS user_team,
             users.status AS user_status, users.consent_status AS user_consent_status, users.last_seen AS user_last_seen,
             users.reclaimable_hours AS user_reclaimable_hours, users.automation_readiness AS user_automation_readiness
      FROM api_sessions
      JOIN users ON users.id = api_sessions.user_id
      WHERE api_sessions.token_hash = ? AND api_sessions.revoked_at IS NULL
    `).get(tokenHash);

    if (!row) {
      return null;
    }

    if (new Date(row.expires_at).valueOf() < Date.now()) {
      return null;
    }

    return {
      id: row.id,
      orgId: row.org_id,
      userId: row.user_id,
      role: row.membership_role,
      expiresAt: row.expires_at,
      userName: row.user_name,
      userRow: {
        id: row.user_id,
        role: row.membership_role,
        name: row.user_name,
        email: row.user_email,
        title: row.user_title,
        team: row.user_team,
        status: row.user_status,
        consent_status: row.user_consent_status,
        last_seen: row.user_last_seen,
        reclaimable_hours: row.user_reclaimable_hours,
        automation_readiness: row.user_automation_readiness,
      },
    };
  }

  getRequestContext(sessionToken = null, options = {}) {
    this.init();
    if (sessionToken) {
      const session = this.getApiSession(sessionToken);
      if (session) {
        return {
          orgId: session.orgId,
          userId: session.userId,
          role: session.role,
          authenticated: true,
        };
      }
    }

    const localSession = this.getLocalSessionState();
    return {
      orgId: localSession.orgId,
      userId: localSession.currentUserId,
      role: localSession.currentRole,
      authenticated: Boolean(options.allowLocalFallback && localSession.currentSessionToken),
    };
  }

  getInviteByToken(inviteToken) {
    const row = this.db.prepare(`
      SELECT employee_invites.*, organizations.name AS organization_name
      FROM employee_invites
      JOIN organizations ON organizations.id = employee_invites.org_id
      WHERE employee_invites.invite_token_hash = ?
    `).get(hashToken(inviteToken));

    if (!row) {
      throw buildError("Invite not found", 404);
    }

    return {
      id: row.id,
      orgId: row.org_id,
      organizationName: row.organization_name,
      email: row.email,
      name: row.name,
      title: row.title,
      team: row.team,
      role: row.role,
      createdAt: row.created_at,
      acceptedAt: row.accepted_at,
      expiresAt: row.expires_at,
    };
  }

  assertInviteIsUsable(invite) {
    if (invite.acceptedAt) {
      throw buildError("Invite already accepted", 410);
    }

    if (new Date(invite.expiresAt).valueOf() < Date.now()) {
      throw buildError("Invite expired", 410);
    }
  }

  nextMembershipSortOrder(orgId) {
    return (this.db.prepare(`
      SELECT COALESCE(MAX(sort_order), -1) AS max_sort_order
      FROM memberships
      WHERE org_id = ?
    `).get(orgId).max_sort_order || 0) + 1;
  }

  createUniqueOrgSlug(name) {
    const base = slugify(name) || "workspace";
    let candidate = base;
    let counter = 2;

    while (this.db.prepare("SELECT id FROM organizations WHERE slug = ?").get(candidate)) {
      candidate = `${base}-${counter}`;
      counter += 1;
    }

    return candidate;
  }

  employeeCount(orgId) {
    return this.db.prepare(`
      SELECT COUNT(*) AS count
      FROM memberships
      WHERE org_id = ? AND role = 'employee'
    `).get(orgId).count;
  }

  syncSeatsUsed(orgId) {
    this.db.prepare(`
      UPDATE organizations
      SET seats_used = ?, updated_at = ?
      WHERE id = ?
    `).run(this.employeeCount(orgId), nowIso(), orgId);
  }

  logAuditEvent({ orgId, actorUserId = null, targetUserId = null, eventType, summary, metadata }) {
    const actor = actorUserId
      ? this.db.prepare("SELECT name FROM users WHERE id = ?").get(actorUserId)
      : null;

    this.db.prepare(`
      INSERT INTO audit_events (
        id, org_id, created_at, actor_user_id, actor_name, target_user_id, event_type, summary, metadata_json
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      `evt-${randomUUID().slice(0, 12)}`,
      orgId,
      nowIso(),
      actorUserId,
      actor?.name || "System",
      targetUserId,
      eventType,
      summary,
      JSON.stringify(metadata || {}),
    );
  }

  getUserById(userId) {
    return this.db.prepare(`
      SELECT *
      FROM users
      WHERE id = ?
    `).get(userId);
  }

  findUserByEmailInOrg(orgId, email) {
    return this.db.prepare(`
      SELECT users.*
      FROM users
      JOIN memberships ON memberships.user_id = users.id
      WHERE memberships.org_id = ? AND lower(users.email) = lower(?)
    `).get(orgId, email);
  }

  getDeviceByCredentials(deviceId, ingestKey) {
    const row = this.db.prepare(`
      SELECT *
      FROM device_installs
      WHERE id = ? AND ingest_key_hash = ? AND status = 'active'
    `).get(deviceId, hashToken(ingestKey));

    if (!row) {
      return null;
    }

    return {
      id: row.id,
      orgId: row.org_id,
      userId: row.user_id,
      label: row.label,
      platform: row.platform,
      status: row.status,
      lastSeenAt: row.last_seen_at,
    };
  }

  ensureIntegration(orgId, provider, connectedByUserId) {
    const existing = this.db.prepare(`
      SELECT id
      FROM integrations
      WHERE org_id = ? AND provider = ?
    `).get(orgId, provider);

    if (existing) {
      return existing.id;
    }

    const timestamp = nowIso();
    const catalog = PROVIDERS[provider];
    const integrationId = `int-${provider}-${randomUUID().slice(0, 8)}`;
    this.db.prepare(`
      INSERT INTO integrations (
        id, org_id, provider, display_name, status, connection_mode, scopes_json, health_status, external_account_ref, connected_by_user_id, last_sync_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'connected', ?, ?, 'healthy', NULL, ?, ?, ?, ?)
    `).run(
      integrationId,
      orgId,
      provider,
      catalog.displayName,
      catalog.authType,
      JSON.stringify(catalog.scopes),
      connectedByUserId,
      timestamp,
      timestamp,
      timestamp,
    );

    return integrationId;
  }

  touchUserActivity(userId, provider, appName) {
    const timestamp = nowIso();
    this.db.prepare(`
      UPDATE users
      SET last_seen = ?, updated_at = ?
      WHERE id = ?
    `).run(`Synced ${provider} just now`, timestamp, userId);

    const membership = this.db.prepare(`
      SELECT org_id
      FROM memberships
      WHERE user_id = ?
      LIMIT 1
    `).get(userId);

    if (!membership) {
      return;
    }

    const existingApp = this.db.prepare(`
      SELECT id
      FROM user_apps
      WHERE org_id = ? AND user_id = ? AND app_name = ?
    `).get(membership.org_id, userId, appName);

    if (existingApp) {
      return;
    }

    const nextSort = (this.db.prepare(`
      SELECT COALESCE(MAX(sort_order), -1) AS max_sort_order
      FROM user_apps
      WHERE org_id = ? AND user_id = ?
    `).get(membership.org_id, userId).max_sort_order || 0) + 1;

    this.db.prepare(`
      INSERT INTO user_apps (org_id, user_id, sort_order, app_name)
      VALUES (?, ?, ?, ?)
    `).run(membership.org_id, userId, nextSort, appName);
  }

  withTransaction(work) {
    this.db.exec("BEGIN");

    try {
      const result = work();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
}

module.exports = {
  WorkspaceRepository,
};

# Backend Runtime

The backend is now a tenant-aware local API with:

- SQLite persistence
- versioned schema migrations
- Postgres/RDS connection and sync scripts
- organization and membership tables
- password-based auth, invite acceptance, and API sessions
- integration registry for Gmail, Slack, and Figma
- device registration, revocation, and observer ingestion
- generated automation recommendations with persisted ranking traces
- audit logging for auth, integrations, devices, automations, and report access

The Electron shell still starts this backend automatically for normal desktop use.

## Run

```bash
npm run backend:start
```

## Reset

```bash
npm run backend:reset
```

## Smoke Test

```bash
npm run backend:smoke
```

## Maintenance

```bash
npm run backend:maintenance
```

## Backup

```bash
npm run backend:backup
```

## Full Test Suite

```bash
npm run backend:test
```

## Postgres / RDS

Check a Postgres connection:

```bash
npm run backend:pg:check
```

Sync the current local SQLite workspace into Postgres:

```bash
npm run backend:pg:sync
```

## Bootstrap Credentials

Seeded users are created with the bootstrap password from `INFRASTRUCT_BOOTSTRAP_PASSWORD`.

Default if unset:

```txt
ChangeMe123!
```

Example admin login:

```txt
email: dana@acme-logistics.com
password: ChangeMe123!
orgSlug: acme-logistics
```

## Environment Variables

- `INFRASTRUCT_API_HOST`
- `INFRASTRUCT_API_PORT`
- `INFRASTRUCT_API_DB_PATH`
- `INFRASTRUCT_DB_BACKEND`
- `INFRASTRUCT_DATABASE_URL`
- `INFRASTRUCT_BOOTSTRAP_PASSWORD`
- `INFRASTRUCT_SESSION_TTL_DAYS`
- `INFRASTRUCT_APP_URL`
- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `SLACK_CLIENT_ID`
- `SLACK_CLIENT_SECRET`
- `SLACK_SIGNING_SECRET`
- `FIGMA_CLIENT_ID`
- `FIGMA_CLIENT_SECRET`
- `FIGMA_WEBHOOK_SECRET`

## Endpoints

- `GET /health`
- `GET /metrics`
- `GET /api/providers`
- `POST /api/auth/login`
- `GET /api/auth/invites/:inviteToken`
- `POST /api/auth/accept-invite`
- `POST /api/auth/logout`
- `GET /api/auth/session`
- `POST /api/auth/password`
- `POST /api/auth/password/reset/request`
- `POST /api/auth/password/reset/confirm`
- `GET /api/auth/sessions`
- `POST /api/auth/sessions/revoke`
- `GET /api/organizations`
- `GET /api/clients`
- `GET /api/clients/:clientId`
- `GET /api/organizations/current`
- `GET /api/organizations/current/integrations`
- `POST /api/organizations/current/integrations`
- `GET /api/invites`
- `GET /api/organizations/current/devices`
- `POST /api/devices/register`
- `POST /api/devices/revoke`
- `POST /api/observer/events/batch`
- `POST /api/observer/local-events`
- `GET /api/observer/events`
- `GET /api/observer/workflows`
- `GET /api/workspace`
- `GET /api/automation-opportunities`
- `GET /api/employees`
- `GET /api/employees/:employeeId`
- `GET /api/audit-events`
- `GET /api/reports`
- `GET /api/reports/:employeeId`
- `POST /api/session/current-user`
- `POST /api/employees`
- `POST /api/automations/decision`
- `POST /api/automations/state`
- `POST /api/automations/refresh`
- `POST /api/consent`

## Current Boundary

What is implemented:

- local real auth
- support-role global client directory with tenant-scoped admin access
- invite delivery and password reset email hooks
- local org isolation
- live observer ingestion endpoints for Gmail, Slack, and Figma payloads
- local desktop observer runtime for active-app, window, and screen-state sampling
- inferred workflow session reconstruction from desktop observer samples
- redacted observer payload storage with retention maintenance
- a first recommendation service that converts repeated work into ranked automation candidates
- backup and maintenance scripts for the local SQLite runtime
- a lightweight metrics endpoint for ops visibility
- RDS/Postgres bootstrap and sync scripts for AWS-hosted data
- container deployment scaffold

What still requires real external setup:

- a verified `RESEND_FROM_EMAIL` sender identity
- the RDS master password / `INFRASTRUCT_DATABASE_URL`
- OAuth app registration with Google, Slack, and Figma
- hosted callback URLs and webhook endpoints
- production secret storage
- managed database and hosted deployment

## Policy

See [backend/OPERATIONS.md](/Users/alexdils/Downloads/companies/infrastruct/backend/OPERATIONS.md) for environment boundaries, trust boundaries, retention rules, and the support/admin/employee access model.

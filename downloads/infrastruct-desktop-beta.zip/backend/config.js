const fs = require("fs");
const path = require("path");

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return {};
  }

  return fs.readFileSync(filePath, "utf8")
    .split(/\r?\n/)
    .reduce((values, line) => {
      const trimmed = line.trim();

      if (!trimmed || trimmed.startsWith("#")) {
        return values;
      }

      const separatorIndex = trimmed.indexOf("=");
      if (separatorIndex === -1) {
        return values;
      }

      const key = trimmed.slice(0, separatorIndex).trim();
      const rawValue = trimmed.slice(separatorIndex + 1).trim();
      const value = rawValue.replace(/^['"]|['"]$/g, "");

      if (key) {
        values[key] = value;
      }

      return values;
    }, {});
}

function loadLocalEnv() {
  const repoRoot = path.join(__dirname, "..");
  const envValues = {
    ...parseEnvFile(path.join(repoRoot, ".env")),
    ...parseEnvFile(path.join(repoRoot, ".env.local")),
  };

  Object.entries(envValues).forEach(([key, value]) => {
    if (!(key in process.env)) {
      process.env[key] = value;
    }
  });
}

loadLocalEnv();

const PORT = Number(process.env.INFRASTRUCT_API_PORT || process.env.INFRASTRUCT_PORT || process.env.PORT || 8787);
const HOST = process.env.INFRASTRUCT_API_HOST || process.env.INFRASTRUCT_HOST || process.env.HOST || "127.0.0.1";
const DB_PATH = process.env.INFRASTRUCT_API_DB_PATH || process.env.INFRASTRUCT_DB_PATH || path.join(__dirname, "data", "infrastruct.db");
const DATABASE_URL = process.env.INFRASTRUCT_DATABASE_URL || process.env.DATABASE_URL || "";
const DB_BACKEND = process.env.INFRASTRUCT_DB_BACKEND || (DATABASE_URL ? "postgres" : "sqlite");
const APP_ENV = process.env.INFRASTRUCT_APP_ENV || process.env.NODE_ENV || "development";
const BOOTSTRAP_PASSWORD = process.env.INFRASTRUCT_BOOTSTRAP_PASSWORD || "ChangeMe123!";
const SESSION_TTL_DAYS = Number(process.env.INFRASTRUCT_SESSION_TTL_DAYS || 30);
const APP_URL = process.env.INFRASTRUCT_APP_URL || `http://${HOST}:${PORT}`;
const RESEND_API_KEY = process.env.RESEND_API_KEY || "";
const RESEND_FROM_EMAIL = process.env.RESEND_FROM_EMAIL || "";
const OBSERVER_REDACTION_MODE = process.env.INFRASTRUCT_OBSERVER_REDACTION_MODE || "metadata";
const RAW_EVENT_RETENTION_DAYS = Number(process.env.INFRASTRUCT_RAW_EVENT_RETENTION_DAYS || 14);
const BACKUP_DIR = process.env.INFRASTRUCT_BACKUP_DIR || path.join(__dirname, "data", "backups");

module.exports = {
  APP_ENV,
  APP_URL,
  BACKUP_DIR,
  BOOTSTRAP_PASSWORD,
  DATABASE_URL,
  DB_BACKEND,
  DB_PATH,
  HOST,
  OBSERVER_REDACTION_MODE,
  PORT,
  RAW_EVENT_RETENTION_DAYS,
  RESEND_API_KEY,
  RESEND_FROM_EMAIL,
  SESSION_TTL_DAYS,
};

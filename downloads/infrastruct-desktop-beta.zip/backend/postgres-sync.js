const { WorkspaceRepository } = require("./repository");
const { DB_PATH } = require("./config");
const { withPgClient } = require("./postgres-utils");
const { PG_SCHEMA_SQL, TABLE_RESET_ORDER, TABLE_SYNC_ORDER, TABLES_WITH_SERIAL_IDS } = require("./postgres-schema");

function quoteIdentifier(identifier) {
  return `"${String(identifier).replace(/"/g, "\"\"")}"`;
}

function loadTableRows(repository, tableName) {
  return repository.db.prepare(`SELECT * FROM ${tableName}`).all();
}

async function resetTables(client) {
  for (const tableName of TABLE_RESET_ORDER) {
    await client.query(`DELETE FROM ${quoteIdentifier(tableName)}`);
  }
}

async function insertRows(client, tableName, rows) {
  if (!rows.length) {
    return;
  }

  const columns = Object.keys(rows[0]);
  const identifiers = columns.map(quoteIdentifier).join(", ");

  for (const row of rows) {
    const values = columns.map((column) => row[column]);
    const placeholders = values.map((_, index) => `$${index + 1}`).join(", ");
    await client.query(
      `INSERT INTO ${quoteIdentifier(tableName)} (${identifiers}) VALUES (${placeholders})`,
      values,
    );
  }
}

async function resetSequences(client) {
  for (const tableName of TABLES_WITH_SERIAL_IDS) {
    await client.query(`
      SELECT setval(
        pg_get_serial_sequence($1, 'id'),
        COALESCE((SELECT MAX(id) FROM ${quoteIdentifier(tableName)}), 1),
        (SELECT COUNT(*) > 0 FROM ${quoteIdentifier(tableName)})
      )
    `, [tableName]);
  }
}

async function main() {
  const repository = new WorkspaceRepository(DB_PATH);
  repository.init();

  try {
    const tableRows = new Map(TABLE_SYNC_ORDER.map((tableName) => [tableName, loadTableRows(repository, tableName)]));

    await withPgClient(async (client) => {
      await client.query("BEGIN");

      try {
        await client.query(PG_SCHEMA_SQL);
        await resetTables(client);

        for (const tableName of TABLE_SYNC_ORDER) {
          await insertRows(client, tableName, tableRows.get(tableName) || []);
        }

        await resetSequences(client);

        await client.query("COMMIT");
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      }
    });

    const summary = Object.fromEntries(TABLE_SYNC_ORDER.map((tableName) => [tableName, (tableRows.get(tableName) || []).length]));
    console.log(JSON.stringify({ ok: true, synced: summary }, null, 2));
  } finally {
    repository.close();
  }
}

main().catch((error) => {
  console.error(error.message || error);
  process.exitCode = 1;
});

function createNoopNotifier() {
  return {
    enabled: false,
    provider: "none",
    async sendEmployeeInvite() {
      return { ok: false, skipped: true, reason: "email_not_configured" };
    },
    async sendPasswordReset() {
      return { ok: false, skipped: true, reason: "email_not_configured" };
    },
  };
}

function inviteText(payload) {
  return [
    `You have been invited to join ${payload.organizationName} on Infrastruct.`,
    "",
    `Name: ${payload.name}`,
    `Role: ${payload.role}`,
    `Team: ${payload.team}`,
    `Sign-in code: ${payload.inviteToken}`,
    "",
    "Open the desktop app, choose 'Use sign-in code', and set your password there.",
    `Accept invite: ${payload.acceptUrl}`,
    `Invite expires: ${payload.expiresAt}`,
  ].join("\n");
}

function resetText(payload) {
  return [
    `A password reset was requested for your ${payload.organizationName} Infrastruct account.`,
    "",
    `Reset password: ${payload.resetUrl}`,
    `Reset expires: ${payload.expiresAt}`,
    "",
    "If you did not request this, you can ignore this email.",
  ].join("\n");
}

function createResendNotifier({ apiKey, fromEmail, appUrl }) {
  if (!apiKey || !fromEmail) {
    return createNoopNotifier();
  }

  const postEmail = async ({ to, subject, text }) => {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromEmail,
        to: Array.isArray(to) ? to : [to],
        subject,
        text,
      }),
    });

    const body = await response.text();
    const data = body ? JSON.parse(body) : null;

    if (!response.ok) {
      const error = new Error(data?.message || `Resend request failed with status ${response.status}`);
      error.statusCode = response.status;
      throw error;
    }

    return {
      ok: true,
      provider: "resend",
      id: data?.id || "",
    };
  };

  return {
    enabled: true,
    provider: "resend",
    async sendEmployeeInvite(payload) {
      return postEmail({
        to: payload.email,
        subject: `You're invited to ${payload.organizationName} on Infrastruct`,
        text: inviteText({
          ...payload,
          acceptUrl: `${appUrl.replace(/\/$/, "")}/invite/${payload.inviteToken}`,
        }),
      });
    },
    async sendPasswordReset(payload) {
      return postEmail({
        to: payload.email,
        subject: `Reset your ${payload.organizationName} Infrastruct password`,
        text: resetText({
          ...payload,
          resetUrl: `${appUrl.replace(/\/$/, "")}/reset-password/${payload.resetToken}`,
        }),
      });
    },
  };
}

function createNotifier(options = {}) {
  if (options.provider === "noop") {
    return createNoopNotifier();
  }

  return createResendNotifier({
    apiKey: options.resendApiKey,
    fromEmail: options.fromEmail,
    appUrl: options.appUrl,
  });
}

module.exports = {
  createNotifier,
  createNoopNotifier,
};

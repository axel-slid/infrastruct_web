const http = require("http");
const { randomUUID } = require("crypto");
const { URL } = require("url");
const { WorkspaceRepository } = require("./repository");
const { createNotifier } = require("./notifier");
const {
  badRequest,
  validateAutomationDecisionInput,
  validateAutomationRefreshInput,
  validateAutomationStateInput,
  validateCompanyRegistrationInput,
  validateConsentInput,
  validateCurrentUserInput,
  validateDeviceRevokeInput,
  validateDeviceRegisterInput,
  validateEmployeeInput,
  validateIntegrationConnectionInput,
  validateInviteAcceptInput,
  validateLoginInput,
  validateLocalObserverEventsInput,
  validateLogoutInput,
  validateObserverBatchInput,
  validatePasswordChangeInput,
  validatePasswordResetConfirmInput,
  validatePasswordResetRequestInput,
  validatePlanRequestInput,
  validateSessionRevokeInput,
} = require("../shared/backend-contract");
const {
  APP_URL,
  APP_ENV,
  BOOTSTRAP_PASSWORD,
  DB_PATH,
  HOST,
  OBSERVER_REDACTION_MODE,
  PORT,
  RAW_EVENT_RETENTION_DAYS,
  RESEND_API_KEY,
  RESEND_FROM_EMAIL,
  SESSION_TTL_DAYS,
} = require("./config");

function log(level, message, meta = {}) {
  process.stdout.write(JSON.stringify({ ts: new Date().toISOString(), level, message, ...meta }) + "\n");
}

function sendJson(response, statusCode, body, extraHeaders = {}) {
  response.writeHead(statusCode, {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Infrastruct-Session",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Content-Type": "application/json; charset=utf-8",
    ...extraHeaders,
  });
  response.end(JSON.stringify(body));
}

function sendNoContent(response, extraHeaders = {}) {
  response.writeHead(204, {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Infrastruct-Session",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    ...extraHeaders,
  });
  response.end();
}

async function readJsonBody(request) {
  const chunks = [];

  for await (const chunk of request) {
    chunks.push(chunk);
  }

  if (!chunks.length) {
    return {};
  }

  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch (_error) {
    throw badRequest("request body must be valid JSON");
  }
}

function getSessionToken(request) {
  const headerToken = request.headers["x-infrastruct-session"];
  return typeof headerToken === "string" && headerToken.trim() ? headerToken.trim() : "";
}

function unauthorized(message = "Authentication required") {
  const error = new Error(message);
  error.statusCode = 401;
  return error;
}

function forbidden(message = "Forbidden") {
  const error = new Error(message);
  error.statusCode = 403;
  return error;
}

function createRateLimiter({ windowMs, max }) {
  const entries = new Map();

  return {
    check(key) {
      const now = Date.now();
      const current = entries.get(key);

      if (!current || current.resetAt <= now) {
        const next = { count: 1, resetAt: now + windowMs };
        entries.set(key, next);
        return { allowed: true, remaining: Math.max(0, max - 1), resetAt: next.resetAt };
      }

      current.count += 1;
      const allowed = current.count <= max;
      return {
        allowed,
        remaining: Math.max(0, max - current.count),
        resetAt: current.resetAt,
      };
    },
    reset(key) {
      entries.delete(key);
    },
  };
}

function requireAuthenticated(context) {
  if (!context.authenticated) {
    throw unauthorized();
  }
}

function requireAdmin(context) {
  requireAuthenticated(context);
  if (context.role !== "admin" && context.role !== "support") {
    throw forbidden("Admin access required");
  }
}

function requireSupport(context) {
  requireAuthenticated(context);
  if (context.role !== "support") {
    throw forbidden("Support access required");
  }
}

function requireEmployeeSelf(context, employeeId) {
  requireAuthenticated(context);
  if (context.role !== "employee" || context.userId !== employeeId) {
    throw forbidden("Employee access is limited to the signed-in user");
  }
}

function requestHeaders(requestId) {
  return {
    "X-Request-Id": requestId,
  };
}

async function attemptNotification(logFn, requestId, label, sendWork) {
  try {
    const result = await sendWork();
    if (result?.ok) {
      logFn("info", "notification", { requestId, label, provider: result.provider || "unknown", id: result.id || "" });
    }
    return result;
  } catch (error) {
    logFn("warn", "notification", { requestId, label, error: error.message });
    return { ok: false, error: error.message };
  }
}

function createServer({
  host = HOST,
  port = PORT,
  dbPath = DB_PATH,
  bootstrapPassword = BOOTSTRAP_PASSWORD,
  observerRedactionMode = OBSERVER_REDACTION_MODE,
  rawEventRetentionDays = RAW_EVENT_RETENTION_DAYS,
  sessionTtlDays = SESSION_TTL_DAYS,
  notifier = createNotifier({
    resendApiKey: RESEND_API_KEY,
    fromEmail: RESEND_FROM_EMAIL,
    appUrl: APP_URL,
  }),
} = {}) {
  const repository = new WorkspaceRepository(dbPath, {
    bootstrapPassword,
    observerRedactionMode,
    rawEventRetentionDays,
    sessionTtlDays,
  });
  repository.init();
  const loginLimiter = createRateLimiter({ windowMs: 10 * 60 * 1000, max: 5 });
  const ingestLimiter = createRateLimiter({ windowMs: 60 * 1000, max: 120 });

  async function routeRequest(request, response, requestId) {
    if (request.method === "OPTIONS") {
      sendNoContent(response, requestHeaders(requestId));
      return;
    }

    const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
    const pathname = url.pathname;
    const sessionToken = getSessionToken(request);
    const context = repository.getRequestContext(sessionToken);
    const responseHeaders = requestHeaders(requestId);

    if (request.method === "GET" && pathname === "/health") {
      sendJson(response, 200, {
        ok: true,
        service: "infrastruct-api",
        environment: APP_ENV,
        database: dbPath,
        sessionTtlDays,
        timestamp: new Date().toISOString(),
      }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/metrics") {
      sendJson(response, 200, repository.getMetricsSnapshot(), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/providers") {
      sendJson(response, 200, { providers: repository.getProviderCatalog() }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/auth/session") {
      if (!sessionToken) {
        throw badRequest("x-infrastruct-session header is required");
      }

      sendJson(response, 200, repository.getAuthSession(sessionToken), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/login") {
      const payload = validateLoginInput(await readJsonBody(request));
      const rateKey = `${request.socket.remoteAddress || "unknown"}:${payload.email}`;
      const rate = loginLimiter.check(rateKey);

      if (!rate.allowed) {
        throw Object.assign(unauthorized("Too many login attempts"), { statusCode: 429 });
      }

      const result = repository.login(payload);
      loginLimiter.reset(rateKey);
      sendJson(response, 200, result, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/auth/company-codes") {
      sendJson(response, 200, { codes: repository.listAvailableCompanyRegistrationCodes() }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/auth/demo-accounts") {
      sendJson(response, 200, { accounts: repository.listDemoAccounts() }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/register-company") {
      const payload = validateCompanyRegistrationInput(await readJsonBody(request));
      sendJson(response, 201, repository.registerCompany(payload), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname.startsWith("/api/auth/invites/")) {
      const inviteToken = pathname.split("/").filter(Boolean).at(-1);
      sendJson(response, 200, { invite: repository.getInvitePreview(inviteToken) }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/accept-invite") {
      const payload = validateInviteAcceptInput(await readJsonBody(request));
      sendJson(response, 201, repository.acceptInvite(payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/logout") {
      requireAuthenticated(context);
      const payload = validateLogoutInput(await readJsonBody(request));
      if (payload.sessionToken !== sessionToken) {
        throw forbidden("Session token mismatch");
      }
      sendJson(response, 200, repository.logout(payload.sessionToken), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/password") {
      requireAuthenticated(context);
      const payload = validatePasswordChangeInput(await readJsonBody(request));
      sendJson(response, 200, repository.changePassword(context.orgId, context.userId, sessionToken, payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/password/reset/request") {
      const payload = validatePasswordResetRequestInput(await readJsonBody(request));
      const result = repository.requestPasswordReset(payload);
      if (result.resetRequest) {
        await attemptNotification(log, requestId, "password-reset", () => notifier.sendPasswordReset(result.resetRequest));
      }
      sendJson(response, 200, { ok: true }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/password/reset/confirm") {
      const payload = validatePasswordResetConfirmInput(await readJsonBody(request));
      sendJson(response, 200, repository.resetPassword(payload), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/auth/sessions") {
      requireAuthenticated(context);
      const userId = url.searchParams.get("userId") || context.userId;
      if (context.role !== "admin" && context.role !== "support" && userId !== context.userId) {
        throw forbidden("Session access is limited to the signed-in user");
      }
      sendJson(response, 200, { sessions: repository.listApiSessions(context.orgId, sessionToken, userId) }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/auth/sessions/revoke") {
      requireAuthenticated(context);
      const payload = validateSessionRevokeInput(await readJsonBody(request));
      if (context.role !== "admin" && context.role !== "support") {
        const ownSession = repository.listApiSessions(context.orgId, sessionToken, context.userId)
          .find((entry) => entry.id === payload.sessionId);
        if (!ownSession) {
          throw forbidden("Session revocation is limited to the signed-in user's sessions");
        }
      }
      sendJson(response, 200, repository.revokeSession(context.orgId, context.userId, payload.sessionId, sessionToken), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/organizations") {
      requireSupport(context);
      sendJson(response, 200, { organizations: repository.listOrganizations() }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/clients") {
      requireSupport(context);
      sendJson(response, 200, { clients: repository.listClients() }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname.startsWith("/api/clients/")) {
      requireSupport(context);
      const clientId = pathname.split("/").filter(Boolean).at(-1);
      sendJson(response, 200, { client: repository.getClient(clientId) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/organizations/current") {
      requireAuthenticated(context);
      sendJson(response, 200, {
        organization: repository.getWorkspace(context.orgId),
        session: repository.snapshot(context.orgId, context.userId).session,
      }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/organizations/current/integrations") {
      requireAdmin(context);
      sendJson(response, 200, { integrations: repository.listIntegrations(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/organizations/current/integrations") {
      requireAdmin(context);
      const payload = validateIntegrationConnectionInput(await readJsonBody(request));
      sendJson(response, 200, repository.connectIntegration(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/invites") {
      requireAdmin(context);
      sendJson(response, 200, { invites: repository.listEmployeeInvites(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/organizations/current/devices") {
      requireAdmin(context);
      sendJson(response, 200, { devices: repository.listDevices(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/devices/register") {
      requireAuthenticated(context);
      const payload = validateDeviceRegisterInput(await readJsonBody(request));
      if (context.role === "employee" && payload.userId !== context.userId) {
        throw forbidden("Employees may only register their own device");
      }
      sendJson(response, 201, repository.registerDevice(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/devices/revoke") {
      requireAdmin(context);
      const payload = validateDeviceRevokeInput(await readJsonBody(request));
      sendJson(response, 200, repository.revokeDevice(context.orgId, context.userId, payload.deviceId), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/observer/events/batch") {
      const payload = validateObserverBatchInput(await readJsonBody(request));
      const rate = ingestLimiter.check(`${payload.deviceId}:${payload.provider}`);
      if (!rate.allowed) {
        throw Object.assign(forbidden("Observer ingest rate limit exceeded"), { statusCode: 429 });
      }
      sendJson(response, 202, repository.ingestObserverBatch(payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/observer/local-events") {
      requireAuthenticated(context);
      const payload = validateLocalObserverEventsInput(await readJsonBody(request));
      sendJson(response, 202, repository.recordLocalObserverEvents(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/observer/events") {
      requireAuthenticated(context);
      const limit = Math.max(1, Math.min(200, Number(url.searchParams.get("limit")) || 50));
      const provider = url.searchParams.get("provider") || "";
      const employeeId = url.searchParams.get("employeeId") || "";
      if (context.role === "employee" && employeeId && employeeId !== context.userId) {
        throw forbidden("Employee access is limited to the signed-in user");
      }
      if (context.role === "employee" && !employeeId) {
        sendJson(response, 200, {
          events: repository.listObservedActions(context.orgId, {
            limit,
            provider: provider || null,
            userId: context.userId,
          }),
        }, responseHeaders);
        return;
      }
      if (context.role !== "employee") {
        requireAdmin(context);
      }
      sendJson(response, 200, {
        events: repository.listObservedActions(context.orgId, {
          limit,
          provider: provider || null,
          userId: employeeId || null,
        }),
      }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/observer/workflows") {
      requireAuthenticated(context);
      const limit = Math.max(1, Math.min(50, Number(url.searchParams.get("limit")) || 20));
      const employeeId = url.searchParams.get("employeeId") || "";
      if (context.role === "employee" && employeeId && employeeId !== context.userId) {
        throw forbidden("Employee access is limited to the signed-in user");
      }
      if (context.role === "employee") {
        sendJson(response, 200, {
          workflows: repository.listWorkflowSessions(context.orgId, {
            employeeId: context.userId,
            limit,
          }),
        }, responseHeaders);
        return;
      }
      requireAdmin(context);
      sendJson(response, 200, {
        workflows: repository.listWorkflowSessions(context.orgId, {
          employeeId: employeeId || null,
          limit,
        }),
      }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/workspace") {
      requireAuthenticated(context);
      sendJson(response, 200, repository.snapshot(context.orgId, context.userId), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/automation-opportunities") {
      requireAdmin(context);
      const limit = Math.max(1, Math.min(100, Number(url.searchParams.get("limit")) || 20));
      sendJson(response, 200, {
        opportunities: repository.listAutomationOpportunities(context.orgId, limit),
        runs: repository.listRecommendationRuns(context.orgId, limit),
      }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/employees") {
      requireAdmin(context);
      sendJson(response, 200, { employees: repository.listEmployees(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/audit-events") {
      requireAdmin(context);
      const limit = Math.max(1, Math.min(100, Number(url.searchParams.get("limit")) || 20));
      sendJson(response, 200, { events: repository.listAuditEvents(context.orgId, limit) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/plan-requests") {
      requireAdmin(context);
      sendJson(response, 200, { requests: repository.listPlanChangeRequests(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname.startsWith("/api/employees/")) {
      requireAdmin(context);
      const employeeId = pathname.split("/").filter(Boolean).at(-1);
      sendJson(response, 200, { employee: repository.getEmployee(employeeId, context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/session/current-user") {
      requireAdmin(context);
      const payload = validateCurrentUserInput(await readJsonBody(request));
      sendJson(response, 200, repository.setCurrentUser(context.orgId, payload.userId), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/employees") {
      requireAdmin(context);
      const payload = validateEmployeeInput(await readJsonBody(request));
      const result = repository.addEmployee(context.orgId, context.userId, payload);
      if (result.invite) {
        await attemptNotification(log, requestId, "employee-invite", () => notifier.sendEmployeeInvite({
          ...result.invite,
          organizationName: result.workspace.name,
          name: payload.name,
          team: payload.team,
          role: "employee",
        }));
      }
      sendJson(response, 201, result, responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/plan-requests") {
      requireAdmin(context);
      const payload = validatePlanRequestInput(await readJsonBody(request));
      sendJson(response, 201, repository.requestPlanChange(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/automations/decision") {
      requireAuthenticated(context);
      const payload = validateAutomationDecisionInput(await readJsonBody(request));
      if (payload.actorRole === "admin") {
        requireAdmin(context);
      } else {
        requireEmployeeSelf(context, payload.employeeId);
      }
      sendJson(response, 200, repository.setAutomationDecision(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/automations/state") {
      requireAdmin(context);
      const payload = validateAutomationStateInput(await readJsonBody(request));
      sendJson(response, 200, repository.setAutomationState(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/automations/refresh") {
      requireAdmin(context);
      const payload = validateAutomationRefreshInput(await readJsonBody(request));
      sendJson(response, 200, repository.refreshAutomationRecommendations(context.userId, {
        orgId: context.orgId,
        employeeId: payload.employeeId || null,
      }), responseHeaders);
      return;
    }

    if (request.method === "POST" && pathname === "/api/consent") {
      requireAdmin(context);
      const payload = validateConsentInput(await readJsonBody(request));
      sendJson(response, 200, repository.setConsentStatus(context.orgId, context.userId, payload), responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname === "/api/reports") {
      requireAdmin(context);
      sendJson(response, 200, { reports: repository.listReports(context.orgId) }, responseHeaders);
      return;
    }

    if (request.method === "GET" && pathname.startsWith("/api/reports/")) {
      requireAuthenticated(context);
      const employeeId = pathname.split("/").filter(Boolean).at(-1);
      if (context.role !== "admin" && context.role !== "support" && context.userId !== employeeId) {
        throw forbidden("Report access is limited to admins or the matching employee");
      }
      const format = url.searchParams.get("format") || "json";
      if (format === "csv") {
        repository.recordReportAccess(context.orgId, context.userId, employeeId, "csv");
        const csv = repository.getReportCsv(employeeId, context.orgId);
        response.writeHead(200, {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="report-${employeeId}.csv"`,
          ...responseHeaders,
        });
        response.end(csv);
      } else {
        repository.recordReportAccess(context.orgId, context.userId, employeeId, "json");
        sendJson(response, 200, { report: repository.getReport(employeeId, context.orgId) }, responseHeaders);
      }
      return;
    }

    sendJson(response, 404, {
      error: "Not found",
      path: pathname,
    }, responseHeaders);
  }

  const server = http.createServer(async (request, response) => {
    const requestId = randomUUID().slice(0, 12);
    const start = Date.now();
    const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);
    try {
      await routeRequest(request, response, requestId);
      log("info", "request", { requestId, method: request.method, path: url.pathname, status: response.statusCode, ms: Date.now() - start });
    } catch (error) {
      const statusCode = error.statusCode || 500;
      sendJson(response, statusCode, {
        error: error.message || "Internal server error",
      }, requestHeaders(requestId));
      log(statusCode >= 500 ? "error" : "warn", "request", { requestId, method: request.method, path: url.pathname, status: statusCode, error: error.message, ms: Date.now() - start });
    }
  });

  const start = () => new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => {
      server.off("error", reject);
      const addr = server.address();
      log("info", "server started", { host, port: addr.port, dbPath });
      resolve({
        server,
        repository,
        host,
        port: addr.port,
        dbPath,
      });
    });
  });

  const stop = () => new Promise((resolve, reject) => {
    server.close((error) => {
      repository.close();
      if (error) {
        reject(error);
        return;
      }
      resolve();
    });
  });

  return {
    server,
    repository,
    host,
    port,
    dbPath,
    start,
    stop,
  };
}

async function startServer(options) {
  const runtime = createServer(options);
  return runtime.start();
}

if (require.main === module) {
  startServer()
    .then(({ host, port, dbPath }) => {
      console.log(`Infrastruct API listening on http://${host}:${port}`);
      console.log(`Workspace database: ${dbPath}`);
    })
    .catch((error) => {
      console.error(error);
      process.exitCode = 1;
    });
}

module.exports = {
  createServer,
  startServer,
};

const fs = require("fs/promises");
const { DB_PATH } = require("./config");
const { WorkspaceRepository } = require("./repository");

async function main() {
  await Promise.all([
    fs.rm(DB_PATH, { force: true }),
    fs.rm(`${DB_PATH}-wal`, { force: true }),
    fs.rm(`${DB_PATH}-shm`, { force: true }),
  ]);
  const repository = new WorkspaceRepository(DB_PATH);
  repository.init();
  repository.close();
  console.log(`Reset local backend database at ${DB_PATH}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

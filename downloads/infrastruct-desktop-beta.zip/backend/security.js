const crypto = require("crypto");

function derivePasswordHash(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

function createPasswordRecord(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = derivePasswordHash(password, salt);
  return {
    salt,
    hash,
  };
}

function verifyPassword(password, passwordSalt, passwordHash) {
  const candidate = derivePasswordHash(password, passwordSalt);
  const left = Buffer.from(candidate, "hex");
  const right = Buffer.from(passwordHash, "hex");

  if (left.length !== right.length) {
    return false;
  }

  return crypto.timingSafeEqual(left, right);
}

function createOpaqueToken(prefix = "tok") {
  return `${prefix}_${crypto.randomBytes(24).toString("hex")}`;
}

function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

module.exports = {
  createOpaqueToken,
  createPasswordRecord,
  hashToken,
  verifyPassword,
};

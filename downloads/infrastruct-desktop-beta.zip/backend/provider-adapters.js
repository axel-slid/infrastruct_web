const PROVIDERS = {
  gmail: {
    id: "gmail",
    displayName: "Google Workspace / Gmail",
    authType: "oauth",
    scopes: [
      "openid",
      "email",
      "profile",
      "https://www.googleapis.com/auth/gmail.readonly",
      "https://www.googleapis.com/auth/gmail.labels",
    ],
    env: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"],
  },
  slack: {
    id: "slack",
    displayName: "Slack",
    authType: "oauth",
    scopes: [
      "channels:history",
      "groups:history",
      "channels:read",
      "users:read",
    ],
    env: ["SLACK_CLIENT_ID", "SLACK_CLIENT_SECRET", "SLACK_SIGNING_SECRET"],
  },
  figma: {
    id: "figma",
    displayName: "Figma",
    authType: "oauth",
    scopes: [
      "files:read",
      "file_comments:read",
      "library_analytics:read",
    ],
    env: ["FIGMA_CLIENT_ID", "FIGMA_CLIENT_SECRET", "FIGMA_WEBHOOK_SECRET"],
  },
};

function normalizeObserverEvents(provider, events) {
  if (!PROVIDERS[provider]) {
    throw new Error(`Unsupported provider ${provider}`);
  }

  if (!Array.isArray(events) || events.length === 0) {
    throw new Error("events must be a non-empty array");
  }

  return events.map((event) => normalizeObserverEvent(provider, event));
}

function redactObserverEvent(provider, event, mode = "metadata") {
  if (mode === "none") {
    return event;
  }

  const base = {
    _redacted: true,
    provider,
    action: event.action || "unknown",
  };

  if (provider === "gmail") {
    return {
      ...base,
      id: event.id || event.eventId || event.sourceKey || null,
      threadId: event.threadId || null,
      bucket: event.bucket || null,
      label: event.label || null,
      hasSubject: Boolean(event.subject),
      attachmentCount: Number(event.attachmentCount || 0),
    };
  }

  if (provider === "slack") {
    return {
      ...base,
      id: event.id || event.eventId || event.sourceKey || event.messageTs || null,
      channel: event.channel || null,
      threadId: event.threadId || null,
      messageTs: event.messageTs || null,
      hasMessageText: Boolean(event.text || event.message),
    };
  }

  if (provider === "figma") {
    return {
      ...base,
      id: event.id || event.eventId || event.sourceKey || event.fileKey || null,
      fileKey: event.fileKey || null,
      fileName: event.fileName || null,
      assetCount: Number(event.assetCount || 0),
      pageName: event.pageName || null,
    };
  }

  return base;
}

function normalizeObserverEvent(provider, event) {
  const normalizedAt = normalizeTimestamp(event.timestamp || event.occurredAt || event.eventTime);

  if (provider === "gmail") {
    return {
      provider,
      sourceKey: readSourceKey(event),
      userEmail: readUserEmail(event),
      occurredAt: normalizedAt,
      appName: "Gmail",
      category: mapGmailCategory(event.action),
      description: buildGmailDescription(event),
      rawEvent: event,
    };
  }

  if (provider === "slack") {
    return {
      provider,
      sourceKey: readSourceKey(event),
      userEmail: readUserEmail(event),
      occurredAt: normalizedAt,
      appName: "Slack",
      category: mapSlackCategory(event.action),
      description: buildSlackDescription(event),
      rawEvent: event,
    };
  }

  if (provider === "figma") {
    return {
      provider,
      sourceKey: readSourceKey(event),
      userEmail: readUserEmail(event),
      occurredAt: normalizedAt,
      appName: "Figma",
      category: mapFigmaCategory(event.action),
      description: buildFigmaDescription(event),
      rawEvent: event,
    };
  }

  throw new Error(`Unsupported provider ${provider}`);
}

function normalizeTimestamp(value) {
  if (!value) {
    return new Date().toISOString();
  }

  const date = new Date(value);
  if (Number.isNaN(date.valueOf())) {
    throw new Error("timestamp must be a valid date");
  }

  return date.toISOString();
}

function readSourceKey(event) {
  const sourceKey = event.id || event.eventId || event.sourceKey || event.messageTs || event.threadId || event.fileKey;
  if (!sourceKey || typeof sourceKey !== "string") {
    throw new Error("event id is required");
  }

  return sourceKey;
}

function readUserEmail(event) {
  const userEmail = event.userEmail || event.email;
  if (!userEmail || typeof userEmail !== "string" || !userEmail.includes("@")) {
    throw new Error("userEmail is required");
  }

  return userEmail.toLowerCase();
}

function mapGmailCategory(action = "") {
  const map = {
    reply_draft: "Automatable",
    thread_triaged: "Automatable",
    label_applied: "Repetitive",
    escalation_routed: "Agent fit",
  };

  return map[action] || "Observed";
}

function mapSlackCategory(action = "") {
  const map = {
    blocker_collected: "Automatable",
    message_routed: "Agent fit",
    digest_compiled: "Automatable",
    thread_replied: "Repetitive",
  };

  return map[action] || "Observed";
}

function mapFigmaCategory(action = "") {
  const map = {
    asset_exported: "Automatable",
    annotation_added: "Agent fit",
    file_shared: "Repetitive",
    handoff_prepared: "Automatable",
  };

  return map[action] || "Observed";
}

function buildGmailDescription(event) {
  if (event.action === "reply_draft") {
    return `Drafted reply for "${event.subject || "untitled thread"}".`;
  }

  if (event.action === "thread_triaged") {
    return `Triaged Gmail thread "${event.subject || "untitled thread"}" into ${event.bucket || "default queue"}.`;
  }

  if (event.action === "label_applied") {
    return `Applied Gmail label ${event.label || "unlabeled"} to "${event.subject || "untitled thread"}".`;
  }

  return event.description || `Observed Gmail action ${event.action || "unknown"}.`;
}

function buildSlackDescription(event) {
  if (event.action === "message_routed") {
    return `Routed Slack message into ${event.channel || "channel"} with context preserved.`;
  }

  if (event.action === "blocker_collected") {
    return `Collected blocker summary from ${event.channel || "Slack thread"}.`;
  }

  if (event.action === "digest_compiled") {
    return `Compiled Slack digest for ${event.channel || "workspace feed"}.`;
  }

  return event.description || `Observed Slack action ${event.action || "unknown"}.`;
}

function buildFigmaDescription(event) {
  if (event.action === "asset_exported") {
    return `Exported ${event.assetCount || "multiple"} assets from ${event.fileName || "Figma file"}.`;
  }

  if (event.action === "annotation_added") {
    return `Added implementation annotation in ${event.fileName || "Figma file"}.`;
  }

  if (event.action === "handoff_prepared") {
    return `Prepared engineering handoff for ${event.fileName || "Figma file"}.`;
  }

  return event.description || `Observed Figma action ${event.action || "unknown"}.`;
}

module.exports = {
  PROVIDERS,
  redactObserverEvent,
  normalizeObserverEvents,
};

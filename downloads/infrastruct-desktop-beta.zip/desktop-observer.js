const fs = require("fs");
const path = require("path");
const os = require("os");
const { randomUUID, createHash } = require("crypto");
const { execFile, spawn } = require("child_process");
const { desktopCapturer, screen, systemPreferences } = require("electron");

const SAMPLE_INTERVAL_MS = 8000;
const NATIVE_CAPTURE_MIN_INTERVAL_MS = 2500;
const MAX_PENDING_EVENTS = 12;
const HELPER_SOURCE = path.join(__dirname, "observer-helper.swift");
const MODIFIER_LABELS = {
  command: "cmd",
  shift: "shift",
  control: "ctrl",
  option: "opt",
  fn: "fn",
};

function execFileAsync(command, args) {
  return new Promise((resolve, reject) => {
    execFile(command, args, { timeout: 10000 }, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      if (stderr && stderr.trim()) {
        reject(new Error(stderr.trim()));
        return;
      }
      resolve(stdout);
    });
  });
}

function hashThumbnail(buffer) {
  return createHash("sha1").update(buffer).digest("hex").slice(0, 16);
}

function mapPlatform(platform) {
  if (platform === "darwin") return "macos";
  if (platform === "win32") return "windows";
  return "linux";
}

function redactWindowTitle(value) {
  if (!value) {
    return "";
  }

  return value
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[redacted-email]")
    .replace(/\b\d{9,16}\b/g, "[redacted-number]")
    .trim()
    .slice(0, 140);
}

function classifyScreenType(appName, windowTitle) {
  const lowerApp = (appName || "").toLowerCase();
  const lowerTitle = (windowTitle || "").toLowerCase();

  if (lowerApp.includes("slack")) {
    if (lowerTitle.includes("huddle") || lowerTitle.includes("call")) return "call";
    if (lowerTitle.includes("thread")) return "thread";
    if (lowerTitle.includes("search")) return "search";
    return "channel";
  }

  if (lowerApp.includes("gmail") || lowerApp.includes("mail")) {
    if (lowerTitle.includes("compose") || lowerTitle.includes("draft")) return "compose";
    if (lowerTitle.includes("inbox")) return "inbox";
    return "message-thread";
  }

  if (lowerApp.includes("figma")) {
    if (lowerTitle.includes("comment")) return "comment-review";
    if (lowerTitle.includes("prototype")) return "prototype";
    return "design-canvas";
  }

  if (lowerApp.includes("safari") || lowerApp.includes("chrome") || lowerApp.includes("arc") || lowerApp.includes("firefox")) {
    if (lowerTitle.includes("docs")) return "document";
    if (lowerTitle.includes("sheet")) return "spreadsheet";
    if (lowerTitle.includes("dashboard")) return "dashboard";
    if (lowerTitle.includes("ticket") || lowerTitle.includes("issue")) return "ticket";
    return "browser-tab";
  }

  if (lowerApp.includes("notion")) return "document";
  if (lowerApp.includes("calendar")) return "calendar";
  if (lowerApp.includes("finder")) return "file-browser";

  return "workspace";
}

function inferSemanticAction(previousSample, currentSample, reason, interactionSummary) {
  if (!previousSample) {
    return "session-start";
  }

  if (interactionSummary.clickCount > 0) {
    return "pointer-press";
  }

  if (interactionSummary.shortcutCount > 0) {
    return "shortcut";
  }

  if (interactionSummary.keyPressCount > 2) {
    return "typed-input";
  }

  if (previousSample.appName !== currentSample.appName) {
    return "switch-app";
  }

  if (previousSample.windowTitle !== currentSample.windowTitle) {
    return "navigate";
  }

  if (previousSample.screenHash && currentSample.screenHash && previousSample.screenHash !== currentSample.screenHash) {
    return "screen-change";
  }

  if (reason === "manual") {
    return "manual-checkpoint";
  }

  return "reviewing";
}

function buildWorkflowHint(sample) {
  const key = `${sample.appName} ${sample.screenType}`.toLowerCase();

  if (key.includes("gmail") && key.includes("compose")) return "draft-outbound-email";
  if (key.includes("gmail")) return "triage-email";
  if (key.includes("slack") && key.includes("thread")) return "resolve-thread";
  if (key.includes("slack")) return "coordinate-in-slack";
  if (key.includes("figma")) return "review-design";
  if (key.includes("spreadsheet")) return "update-tracker";
  if (key.includes("ticket")) return "work-ticket";

  return "review-workflow";
}

function describeEvent(sample, semanticAction, interactionSummary) {
  const app = sample.appName || "Desktop";
  const screenType = sample.screenType.replace(/-/g, " ");
  const title = sample.windowTitle ? ` in ${sample.windowTitle}` : "";

  if (semanticAction === "shortcut") {
    return `Triggered ${interactionSummary.shortcutCount} shortcut action${interactionSummary.shortcutCount > 1 ? "s" : ""} in ${app}${title}.`;
  }

  if (semanticAction === "typed-input") {
    return `Typed ${interactionSummary.keyPressCount} key presses while working in ${app}${title}.`;
  }

  if (semanticAction === "pointer-press") {
    return `Pressed ${interactionSummary.clickCount} pointer control${interactionSummary.clickCount > 1 ? "s" : ""} in ${app}${title}.`;
  }

  switch (semanticAction) {
    case "switch-app":
      return `Switched into ${app}${title}.`;
    case "navigate":
      return `Navigated within ${app}${title}.`;
    case "screen-change":
      return `Worked through a ${screenType} screen in ${app}.`;
    case "session-start":
      return `Started a ${screenType} session in ${app}.`;
    default:
      return `Reviewed a ${screenType} screen in ${app}.`;
  }
}

function formatKeyToken(event) {
  const text = typeof event.text === "string" ? event.text : "";
  const printable = text
    .replace(/\n/g, "enter")
    .replace(/\t/g, "tab")
    .replace(/ /g, "space")
    .trim();
  const baseKey = printable || event.keyLabel || "key";
  const modifiers = Array.isArray(event.modifiers) ? event.modifiers.map((entry) => MODIFIER_LABELS[entry] || entry) : [];

  if (modifiers.length) {
    return `${modifiers.join("+")}+${baseKey}`;
  }

  return baseKey;
}

function buildTranscript(previousSample, currentSample, interactionSummary) {
  const transcript = [];

  if (!previousSample || previousSample.appName !== currentSample.appName || previousSample.windowTitle !== currentSample.windowTitle) {
    const windowLabel = currentSample.windowTitle
      ? `${currentSample.appName} -> ${currentSample.windowTitle}`
      : currentSample.appName;
    transcript.push({
      kind: "window",
      occurredAt: currentSample.occurredAt,
      value: windowLabel,
    });
  }

  if (Array.isArray(interactionSummary.transcript) && interactionSummary.transcript.length) {
    transcript.push(...interactionSummary.transcript);
  }

  return transcript.slice(-24);
}

function createEmptyInteractionAccumulator() {
  return {
    eventCount: 0,
    keyPressCount: 0,
    shortcutCount: 0,
    clickCount: 0,
    scrollCount: 0,
    lastPointer: null,
    recentKinds: [],
    recentKeys: [],
    transcript: [],
  };
}

function summariseAccumulator(accumulator) {
  return {
    eventCount: accumulator.eventCount,
    keyPressCount: accumulator.keyPressCount,
    shortcutCount: accumulator.shortcutCount,
    clickCount: accumulator.clickCount,
    scrollCount: accumulator.scrollCount,
    recentKinds: accumulator.recentKinds.slice(-6),
    recentKeys: accumulator.recentKeys.slice(-6),
    lastPointer: accumulator.lastPointer,
    transcript: accumulator.transcript.slice(-12),
  };
}

async function getFrontmostAppContext() {
  if (process.platform !== "darwin") {
    return {
      appName: "Desktop",
      windowTitle: "",
      appId: "",
    };
  }

  const script = `
    tell application "System Events"
      set frontApp to first application process whose frontmost is true
      set appName to name of frontApp
      set appId to ""
      set windowTitle to ""
      try
        set appId to bundle identifier of frontApp
      end try
      try
        set windowTitle to name of front window of frontApp
      end try
      return appName & "||" & appId & "||" & windowTitle
    end tell
  `;

  const output = await execFileAsync("osascript", ["-e", script]);
  const [appName = "Desktop", appId = "", rawWindowTitle = ""] = output.trim().split("||");

  return {
    appName: appName.trim() || "Desktop",
    appId: appId.trim(),
    windowTitle: redactWindowTitle(rawWindowTitle),
  };
}

async function captureScreenMetadata() {
  try {
    const primaryDisplay = screen.getPrimaryDisplay();
    const displaySize = primaryDisplay?.size || primaryDisplay?.workAreaSize || { width: 1440, height: 900 };
    const scaleFactor = Number(primaryDisplay?.scaleFactor) || 1;
    const thumbnailSize = {
      width: Math.min(2400, Math.max(960, Math.round(displaySize.width * scaleFactor))),
      height: Math.min(1600, Math.max(600, Math.round(displaySize.height * scaleFactor))),
    };
    const sources = await desktopCapturer.getSources({
      types: ["screen"],
      thumbnailSize,
      fetchWindowIcons: false,
    });
    const preferred = sources.find((source) => String(source.display_id) === String(primaryDisplay.id)) || sources[0];

    if (!preferred) {
      return {
        captureStatus: "unavailable",
        screenHash: "",
        displayLabel: "",
        previewSize: thumbnailSize,
        previewDataUrl: "",
      };
    }

    const buffer = preferred.thumbnail.toPNG();
    return {
      captureStatus: buffer.length ? "captured" : "empty",
      screenHash: buffer.length ? hashThumbnail(buffer) : "",
      displayLabel: preferred.name || preferred.id || "",
      displayBounds: primaryDisplay?.workAreaSize
        ? { width: primaryDisplay.workAreaSize.width, height: primaryDisplay.workAreaSize.height }
        : null,
      previewSize: thumbnailSize,
      previewDataUrl: preferred.thumbnail.toDataURL(),
    };
  } catch (error) {
    return {
      captureStatus: "failed",
      captureError: error.message,
      screenHash: "",
      displayLabel: "",
      displayBounds: null,
      previewSize: null,
      previewDataUrl: "",
    };
  }
}

class DesktopObserverService {
  constructor({ apiRequest, onStatusChange = () => {}, userDataPath = "" }) {
    this.apiRequest = apiRequest;
    this.onStatusChange = onStatusChange;
    this.userDataPath = userDataPath;
    this.intervalId = null;
    this.currentSession = null;
    this.currentDevice = null;
    this.previousSample = null;
    this.pendingEvents = [];
    this.captureInFlight = false;
    this.helperProcess = null;
    this.helperBinaryPath = userDataPath ? path.join(userDataPath, "observer-helper") : "";
    this.lastNativeCaptureAt = 0;
    this.interactionAccumulator = createEmptyInteractionAccumulator();
    this.status = {
      running: false,
      mode: "metadata + native-input",
      platform: process.platform,
      permissions: {
        accessibility: "unknown",
        screen: "unknown",
      },
      deviceId: "",
      deviceLabel: "",
      lastSampleAt: "",
      lastFlushAt: "",
      activeApp: "",
      activeWindow: "",
      screenType: "",
      semanticAction: "",
      workflowHint: "",
      pendingEvents: 0,
      totalCaptured: 0,
      keyPressesCaptured: 0,
      pointerPressesCaptured: 0,
      screenCapturesCaptured: 0,
      nativeHelperState: "idle",
      lastError: "",
      lastPreviewDataUrl: "",
      lastTranscript: [],
      limitations: [
        "This build stores local screen previews for review and sends workflow metadata to the backend.",
        "Keystroke transcripts and window-switch logs are captured from the signed-in desktop session when accessibility is granted.",
      ],
    };
  }

  emitStatus() {
    this.status.pendingEvents = this.pendingEvents.length;
    this.onStatusChange(this.getStatus());
  }

  getStatus() {
    return {
      ...this.status,
      permissions: { ...this.status.permissions },
      limitations: [...this.status.limitations],
      lastTranscript: Array.isArray(this.status.lastTranscript) ? [...this.status.lastTranscript] : [],
    };
  }

  readPermissionState() {
    const permissions = {
      accessibility: "unsupported",
      screen: "unsupported",
    };

    if (process.platform === "darwin") {
      try {
        permissions.accessibility = systemPreferences.isTrustedAccessibilityClient(false) ? "granted" : "not-granted";
      } catch (_error) {
        permissions.accessibility = "unknown";
      }

      try {
        permissions.screen = systemPreferences.getMediaAccessStatus("screen");
      } catch (_error) {
        permissions.screen = "unknown";
      }
    }

    this.status.permissions = permissions;
  }

  async ensureDevice(session) {
    if (this.currentDevice?.userId === session.user.id && this.currentDevice?.orgId === session.organization.id) {
      return this.currentDevice;
    }

    const label = `${os.hostname()} · ${process.platform}`;
    const result = await this.apiRequest("/api/devices/register", {
      method: "POST",
      body: {
        userId: session.user.id,
        label,
        platform: mapPlatform(process.platform),
      },
    });

    this.currentDevice = {
      id: result.deviceId,
      label,
      userId: session.user.id,
      orgId: session.organization.id,
    };
    this.status.deviceId = result.deviceId;
    this.status.deviceLabel = label;
    return this.currentDevice;
  }

  async ensureHelperBinary() {
    if (process.platform !== "darwin" || !this.helperBinaryPath) {
      return "";
    }

    const needsBuild = !fs.existsSync(this.helperBinaryPath)
      || fs.statSync(this.helperBinaryPath).mtimeMs < fs.statSync(HELPER_SOURCE).mtimeMs;

    if (needsBuild) {
      fs.mkdirSync(path.dirname(this.helperBinaryPath), { recursive: true });
      await execFileAsync("xcrun", ["swiftc", HELPER_SOURCE, "-framework", "ApplicationServices", "-o", this.helperBinaryPath]);
    }

    return this.helperBinaryPath;
  }

  startNativeHelper() {
    if (process.platform !== "darwin" || this.helperProcess || this.status.permissions.accessibility !== "granted") {
      this.status.nativeHelperState = this.status.permissions.accessibility === "granted" ? "ready" : "needs-accessibility";
      this.emitStatus();
      return;
    }

    this.ensureHelperBinary().then((binaryPath) => {
      this.helperProcess = spawn(binaryPath, [], {
        stdio: ["ignore", "pipe", "pipe"],
      });
      this.status.nativeHelperState = "starting";
      this.emitStatus();

      this.helperProcess.stdout.setEncoding("utf8");
      this.helperProcess.stdout.on("data", (chunk) => {
        chunk.split("\n").map((line) => line.trim()).filter(Boolean).forEach((line) => {
          try {
            const payload = JSON.parse(line);
            if (payload.ready) {
              this.status.nativeHelperState = "streaming";
              this.emitStatus();
              return;
            }
            this.handleNativeEvent(payload).catch((error) => {
              this.status.lastError = error.message;
              this.emitStatus();
            });
          } catch (_error) {
            // ignore malformed helper output
          }
        });
      });

      this.helperProcess.stderr.setEncoding("utf8");
      this.helperProcess.stderr.on("data", (chunk) => {
        const text = chunk.toString().trim();
        if (text) {
          this.status.lastError = text;
          this.status.nativeHelperState = "error";
          this.emitStatus();
        }
      });

      this.helperProcess.on("exit", () => {
        this.helperProcess = null;
        if (this.status.running) {
          this.status.nativeHelperState = "stopped";
          this.emitStatus();
        }
      });
    }).catch((error) => {
      this.status.lastError = error.message;
      this.status.nativeHelperState = "compile-failed";
      this.emitStatus();
    });
  }

  stopNativeHelper() {
    if (this.helperProcess) {
      this.helperProcess.kill();
      this.helperProcess = null;
    }
    this.status.nativeHelperState = "idle";
  }

  accumulateNativeEvent(event) {
    this.interactionAccumulator.eventCount += 1;
    this.interactionAccumulator.recentKinds.push(event.kind);

    if (event.kind === "keyDown") {
      this.interactionAccumulator.keyPressCount += 1;
      this.status.keyPressesCaptured += 1;
      if (Array.isArray(event.modifiers) && event.modifiers.length) {
        this.interactionAccumulator.shortcutCount += 1;
      }
      if (event.keyLabel && event.keyLabel !== "character") {
        this.interactionAccumulator.recentKeys.push(event.keyLabel);
      }
      this.interactionAccumulator.transcript.push({
        kind: "keystroke",
        occurredAt: event.occurredAt,
        value: formatKeyToken(event),
      });
    }

    if (event.kind === "leftMouseDown" || event.kind === "rightMouseDown") {
      this.interactionAccumulator.clickCount += 1;
      this.status.pointerPressesCaptured += 1;
      this.interactionAccumulator.lastPointer = {
        x: event.x || 0,
        y: event.y || 0,
        kind: event.kind,
      };
    }

    if (event.kind === "scrollWheel") {
      this.interactionAccumulator.scrollCount += 1;
      this.interactionAccumulator.lastPointer = {
        x: event.x || 0,
        y: event.y || 0,
        kind: event.kind,
      };
    }

    this.interactionAccumulator.recentKinds = this.interactionAccumulator.recentKinds.slice(-8);
    this.interactionAccumulator.recentKeys = this.interactionAccumulator.recentKeys.slice(-8);
    this.interactionAccumulator.transcript = this.interactionAccumulator.transcript.slice(-24);
    this.emitStatus();
  }

  async handleNativeEvent(event) {
    this.accumulateNativeEvent(event);

    const now = Date.now();
    const shouldCaptureImmediately = event.kind === "leftMouseDown"
      || event.kind === "rightMouseDown"
      || (event.kind === "keyDown" && Array.isArray(event.modifiers) && event.modifiers.length > 0);

    if (!shouldCaptureImmediately && now - this.lastNativeCaptureAt < NATIVE_CAPTURE_MIN_INTERVAL_MS) {
      return;
    }

    this.lastNativeCaptureAt = now;
    await this.captureNow(`native-${event.kind}`);
  }

  async start() {
    if (this.status.running) {
      return this.getStatus();
    }

    this.readPermissionState();
    this.currentSession = await this.apiRequest("/api/auth/session");
    await this.ensureDevice(this.currentSession);

    this.status.running = true;
    this.status.lastError = "";
    this.emitStatus();
    this.startNativeHelper();

    await this.captureNow("startup").catch((error) => {
      this.status.lastError = error.message;
      this.emitStatus();
    });

    this.intervalId = setInterval(() => {
      this.captureNow("interval").catch((error) => {
        this.status.lastError = error.message;
        this.emitStatus();
      });
    }, SAMPLE_INTERVAL_MS);

    return this.getStatus();
  }

  async stop(reason = "manual") {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    this.stopNativeHelper();
    this.status.running = false;
    this.previousSample = null;
    this.interactionAccumulator = createEmptyInteractionAccumulator();
    await this.flushPending().catch((error) => {
      this.status.lastError = error.message;
    });
    this.emitStatus();
    return { ok: true, reason, status: this.getStatus() };
  }

  async sampleNow() {
    return this.captureNow("manual");
  }

  async captureNow(reason = "manual") {
    if (!this.status.running || this.captureInFlight) {
      return this.getStatus();
    }

    this.captureInFlight = true;

    try {
      this.readPermissionState();
      const [frontmost, screenMeta] = await Promise.all([
        getFrontmostAppContext(),
        captureScreenMetadata(),
      ]);
      const cursor = screen.getCursorScreenPoint();
      const screenType = classifyScreenType(frontmost.appName, frontmost.windowTitle);
      const interactionSummary = summariseAccumulator(this.interactionAccumulator);

      const sample = {
        occurredAt: new Date().toISOString(),
        appName: frontmost.appName,
        appId: frontmost.appId,
        windowTitle: frontmost.windowTitle,
        screenType,
        cursorX: interactionSummary.lastPointer?.x ?? cursor.x,
        cursorY: interactionSummary.lastPointer?.y ?? cursor.y,
        displayLabel: screenMeta.displayLabel,
        screenHash: screenMeta.screenHash,
        captureStatus: screenMeta.captureStatus,
        displayBounds: screenMeta.displayBounds,
      };

      const semanticAction = inferSemanticAction(this.previousSample, sample, reason, interactionSummary);
      const workflowHint = buildWorkflowHint(sample);
      const transcript = buildTranscript(this.previousSample, sample, interactionSummary);
      const confidenceScore = semanticAction === "reviewing"
        ? 0.61
        : interactionSummary.keyPressCount || interactionSummary.clickCount
          ? 0.9
          : 0.82;

      const event = {
        sourceKey: `desktop-${Date.now()}-${randomUUID().slice(0, 8)}`,
        occurredAt: sample.occurredAt,
        deviceId: this.currentDevice?.id || "",
        appName: sample.appName,
        appId: sample.appId,
        windowTitle: sample.windowTitle,
        screenType,
        semanticAction,
        workflowHint,
        confidenceScore,
        cursorX: sample.cursorX,
        cursorY: sample.cursorY,
        clickCount: interactionSummary.clickCount,
        inputMode: this.status.permissions.accessibility === "granted" ? "native-event-tap" : "screen-sampling",
        captureReason: reason,
        interactionSummary,
        transcript,
        screenSummary: {
          displayLabel: sample.displayLabel,
          captureStatus: sample.captureStatus,
          displayBounds: sample.displayBounds,
          screenHash: sample.screenHash,
          previewSize: screenMeta.previewSize,
        },
        description: describeEvent(sample, semanticAction, interactionSummary),
      };

      this.pendingEvents.push(event);
      this.previousSample = sample;
      this.interactionAccumulator = createEmptyInteractionAccumulator();
      this.status.lastSampleAt = sample.occurredAt;
      this.status.activeApp = sample.appName;
      this.status.activeWindow = sample.windowTitle;
      this.status.screenType = screenType;
      this.status.semanticAction = semanticAction;
      this.status.workflowHint = workflowHint;
      this.status.screenCapturesCaptured += 1;
      this.status.lastPreviewDataUrl = screenMeta.previewDataUrl || this.status.lastPreviewDataUrl;
      this.status.lastTranscript = transcript;
      this.status.lastError = "";

      if (
        this.pendingEvents.length >= MAX_PENDING_EVENTS
        || reason === "manual"
        || semanticAction === "switch-app"
        || interactionSummary.shortcutCount > 0
      ) {
        await this.flushPending();
      } else {
        this.emitStatus();
      }

      return this.getStatus();
    } finally {
      this.captureInFlight = false;
    }
  }

  async flushPending() {
    if (!this.pendingEvents.length || !this.currentDevice) {
      this.emitStatus();
      return { ok: true, inserted: 0 };
    }

    const events = this.pendingEvents.splice(0, this.pendingEvents.length);

    try {
      const result = await this.apiRequest("/api/observer/local-events", {
        method: "POST",
        body: {
          deviceId: this.currentDevice.id,
          events,
        },
      });

      this.status.lastFlushAt = new Date().toISOString();
      this.status.totalCaptured += result.inserted || 0;
      this.emitStatus();
      return result;
    } catch (error) {
      this.pendingEvents.unshift(...events);
      this.status.lastError = error.message;
      this.emitStatus();
      throw error;
    }
  }
}

function createDesktopObserverService(options) {
  return new DesktopObserverService(options);
}

module.exports = {
  createDesktopObserverService,
};

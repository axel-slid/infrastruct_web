# Observer Task

## Product Goal

- Build a desktop observer service that runs alongside the Infrastruct app.
- Observe user interaction patterns to understand how work is actually performed.
- Detect workflows by combining:
  - click activity
  - focused application changes
  - screen understanding
  - keyboard and window context
  - repeated task sequences over time
- Produce workflow intelligence that can later power:
  - employee activity timelines
  - workflow summaries
  - automation recommendations
  - manager/admin reporting

## Core Observer Principle

- The observer should not behave like a screen recorder.
- The observer should behave like a workflow interpreter.
- The main question is not "what exact pixels were shown?"
- The main question is "what task was the employee trying to complete, in what app, with what repeated sequence of actions?"

## What The Observer Should Detect

- Which app is active.
- Which window or document context appears to be active.
- Where the user clicks.
- What broad UI element was likely clicked:
  - button
  - menu
  - field
  - sidebar item
  - canvas area
  - send/publish/export control
- Whether the user is reading, editing, reviewing, responding, searching, navigating, or waiting.
- Whether the user is moving through a repeated multi-step workflow.
- Whether the workflow appears manual, repetitive, and automation-ready.

## Primary Signals To Capture

- Active application name.
- Bundle ID / executable identity.
- Window title.
- Timestamp.
- Cursor position at click time.
- Mouse event type:
  - move
  - click
  - double click
  - drag
  - scroll
- Keyboard context:
  - hotkey use
  - enter/submit behavior
  - tab navigation
  - copy/paste patterns
- Screen snapshot signals around key events.
- OCR-derived labels from the visible UI.
- On-device vision classification of what screen the user is on.
- Optional accessibility-tree context when available.

## Screen Understanding Model

- Use periodic on-device screen analysis at low frequency.
- Use event-triggered screen analysis at higher fidelity for important moments:
  - click
  - submit
  - navigation
  - dialog open
  - app switch
- Analyze the current screen for:
  - visible app layout
  - text labels
  - forms
  - buttons
  - tables
  - message lists
  - design canvases
  - dashboards
  - search results
- Classify the visible state into a normalized screen type:
  - inbox
  - message thread
  - compose window
  - CRM record
  - spreadsheet table
  - design canvas
  - issue tracker ticket
  - admin dashboard
  - file browser
  - settings page

## Click Interpretation Layer

- Raw click coordinates are not enough.
- Every click should be enriched into an interpreted event.
- Each interpreted click should try to answer:
  - what app was open?
  - what screen type was visible?
  - what UI region was clicked?
  - what likely intent did the click represent?
- Convert raw clicks into semantic actions such as:
  - open message
  - search record
  - edit field
  - copy value
  - submit form
  - navigate to board
  - export asset
  - resolve ticket
  - send reply

## Workflow Reconstruction

- Group low-level events into short task sessions.
- Group task sessions into named workflows.
- Reconstruct workflows using:
  - app switch order
  - repeated screen states
  - repeated click regions
  - repeated OCR labels
  - repeated time intervals
  - repeated completion outcomes
- Example reconstructed workflows:
  - open Gmail, read support request, switch to Slack, ask teammate, return to Gmail, send response
  - open Salesforce lead, copy company name, search LinkedIn, update CRM notes
  - open Figma, review comments, export asset, upload asset to task system

## Workflow Output Format

- Each workflow should produce:
  - workflow ID
  - employee ID
  - start/end time
  - apps involved
  - ordered step list
  - confidence score
  - repetition score
  - estimated manual effort
  - automation candidate score
  - redacted evidence summary
- Each step should contain:
  - timestamp
  - app
  - screen type
  - semantic action
  - confidence
  - redacted context labels

## Supported App Strategy

- Start with high-frequency knowledge-work apps.
- Prioritize about 20 app families, with explicit v1 focus on:
  - Gmail
  - Slack
  - Figma
  - Notion
  - Google Sheets
  - Google Docs
  - Salesforce
  - HubSpot
  - Zendesk
  - Intercom
  - Jira
  - Linear
  - Asana
  - Trello
  - Airtable
  - Web browser tabs for internal tools
  - file pickers / export dialogs
  - macOS Finder
- For each supported app, define:
  - app fingerprint
  - common screens
  - common actions
  - important workflow states
  - sensitive regions that must be redacted

## Privacy And Trust Boundaries

- Default to metadata-first collection.
- Do not ship raw screen video to the backend.
- Do not ship raw message bodies, document bodies, or credential material off-device.
- Prefer on-device OCR and on-device vision labeling.
- Persist only redacted workflow evidence such as:
  - app name
  - screen type
  - UI label category
  - non-sensitive button text
  - action classification
  - timestamps
- Sensitive text handling rules:
  - detect likely secrets, emails, message bodies, and freeform text blocks
  - redact them before persistence
  - never retain password fields
  - never retain clipboard plaintext by default

## Local Architecture

- Run the observer as a background desktop component.
- Separate the observer from the visible Electron UI.
- Recommended local components:
  - input capture module
  - active-window tracker
  - screenshot sampler
  - OCR module
  - vision classification module
  - workflow assembler
  - local encrypted queue
  - backend sync uploader
- Maintain a local event buffer for offline use.
- Upload normalized, redacted workflow events in batches.

## Capture Strategy

- Capture low-cost signals continuously:
  - active app
  - active window
  - click coordinates
  - scroll
  - key shortcuts
- Capture expensive signals selectively:
  - screenshots
  - OCR
  - vision inference
- Trigger higher-cost capture when:
  - app changes
  - a meaningful click occurs
  - a likely submission occurs
  - a dialog or modal appears
  - a workflow branch appears to start or end

## State Machine For Observation

- Idle
  - no meaningful interaction yet
- Active session
  - repeated interaction in one app or one workflow
- Cross-app workflow
  - user moves across apps to complete one task
- Completion candidate
  - likely send, submit, export, resolve, update, or publish event
- Review / waiting
  - user pauses, reads, or waits on content
- Session close
  - inactivity, app closure, or explicit completion

## Admin-Facing Outputs

- For each employee:
  - daily workflow timeline
  - top repeated workflows
  - top manual tasks
  - suggested automation opportunities
  - evidence-backed workflow summaries
- For each organization:
  - team-wide workflow heatmap
  - app utilization summary
  - most repeated cross-app processes
  - approval-ready automation queue

## Employee-Facing Outputs

- Personal activity timeline.
- Personal workflow summaries.
- Proposed automations with reasons.
- Clear visibility into what was observed.
- Permission and consent controls.
- Ability to review proposed automations before activation.

## Security Requirements

- Encrypt observer queue data at rest on device.
- Sign or hash event batches before upload.
- Register each device with a revocable device identity.
- Allow remote device revocation.
- Stop ingestion immediately when device authorization is revoked.
- Keep model prompts and redaction rules versioned.

## Failure Modes To Handle

- Observer crashes and restarts.
- Offline device for long periods.
- OCR failure.
- Vision model uncertainty.
- Unsupported app screens.
- Permission loss for screen capture or accessibility APIs.
- Excess CPU or memory usage.
- Large monitors or multiple displays.
- Sensitive content over-capture.

## Performance Constraints

- Low background CPU usage during idle periods.
- Bounded memory usage.
- Battery-aware behavior on laptops.
- Sampling rate should adapt to activity.
- Vision and OCR should be throttled and cached.
- Avoid making the machine feel slower or intrusive.

## MVP Implementation Phases

- Phase 1: local event capture
  - active app detection
  - click capture
  - window title capture
  - local queue
- Phase 2: screen understanding
  - event-triggered screenshots
  - OCR labels
  - basic screen-type classification
- Phase 3: semantic action inference
  - click-region labeling
  - app-specific action mapping
  - workflow session assembly
- Phase 4: workflow intelligence
  - repeated workflow detection
  - automation scoring
  - admin and employee summaries
- Phase 5: production hardening
  - privacy review
  - performance tuning
  - permission UX
  - auditability
  - rollback / disable controls

## Definition Of Done

- The system can observe real desktop activity without recording raw screen video.
- The system can identify which app and broad screen type the employee is using.
- The system can interpret clicks into likely semantic actions.
- The system can reconstruct repeated workflows across multiple apps.
- The system can produce redacted, reviewable workflow summaries.
- The system can surface automation opportunities with evidence and confidence.
- The system operates within explicit privacy limits and clear employee disclosure.

## Immediate Build Tasks

- Define the local observer process boundary in the desktop app.
- Implement macOS active-window tracking.
- Implement click and scroll event capture.
- Implement event-triggered screenshot capture.
- Add local OCR pipeline for visible UI labels.
- Add screen classifier for supported apps.
- Define redaction rules before persistence.
- Extend the backend event schema for semantic observer steps.
- Store workflow sessions separately from raw interaction events.
- Build the first admin workflow timeline view from observer sessions.

const CONSENT_STATUSES = new Set(["approved", "pending"]);
const ACTOR_ROLES = new Set(["admin", "employee"]);
const PROVIDERS = new Set(["gmail", "slack", "figma"]);
const AUTOMATION_STATES = new Set(["proposed", "review", "pilot", "active", "paused", "rejected"]);
const PLATFORM_VALUES = new Set(["macos", "windows", "linux"]);
const CONNECTION_MODES = new Set(["oauth", "service-account", "webhook"]);
const PLAN_REQUEST_TYPES = new Set(["upgrade", "downgrade", "cancel"]);
const MIN_PASSWORD_LENGTH = 10;
const DECISIONS = {
  admin: new Set(["approved", "rejected"]),
  employee: new Set(["accepted", "rejected"]),
};

function readRequiredString(payload, fieldName) {
  const value = payload?.[fieldName];

  if (typeof value !== "string" || value.trim() === "") {
    throw badRequest(`${fieldName} is required`);
  }

  return value.trim();
}

function badRequest(message) {
  const error = new Error(message);
  error.statusCode = 400;
  return error;
}

function notFound(message) {
  const error = new Error(message);
  error.statusCode = 404;
  return error;
}

function readStrongPassword(payload, fieldName = "password") {
  const value = readRequiredString(payload, fieldName);

  if (value.length < MIN_PASSWORD_LENGTH) {
    throw badRequest(`${fieldName} must be at least ${MIN_PASSWORD_LENGTH} characters`);
  }

  if (!/[a-z]/.test(value) || !/[A-Z]/.test(value) || !/[0-9]/.test(value) || !/[^A-Za-z0-9]/.test(value)) {
    throw badRequest(`${fieldName} must include upper, lower, number, and symbol characters`);
  }

  return value;
}

function validateEmployeeInput(payload) {
  const name = readRequiredString(payload, "name");
  const email = readRequiredString(payload, "email").toLowerCase();
  const title = readRequiredString(payload, "title");
  const team = readRequiredString(payload, "team");

  if (!email.includes("@")) {
    throw badRequest("email must be valid");
  }

  return { name, email, title, team };
}

function validateCurrentUserInput(payload) {
  return {
    userId: readRequiredString(payload, "userId"),
  };
}

function validateLoginInput(payload) {
  const identifier = payload?.identifier
    ? readRequiredString(payload, "identifier").toLowerCase()
    : readRequiredString(payload, "email").toLowerCase();
  const password = readRequiredString(payload, "password");
  const orgSlug = payload?.orgSlug ? readRequiredString(payload, "orgSlug") : "";
  const label = payload?.label ? readRequiredString(payload, "label") : "desktop-login";

  return {
    identifier,
    password,
    orgSlug,
    label,
  };
}

function validateCompanyRegistrationInput(payload) {
  const registrationCode = readRequiredString(payload, "registrationCode").toUpperCase();
  const companyName = readRequiredString(payload, "companyName");
  const adminName = readRequiredString(payload, "adminName");
  const adminEmail = readRequiredString(payload, "adminEmail").toLowerCase();
  const password = readStrongPassword(payload, "password");
  const label = payload?.label ? readRequiredString(payload, "label") : "company-registration";

  if (!adminEmail.includes("@")) {
    throw badRequest("adminEmail must be valid");
  }

  return {
    registrationCode,
    companyName,
    adminName,
    adminEmail,
    password,
    label,
  };
}

function validateLogoutInput(payload) {
  return {
    sessionToken: readRequiredString(payload, "sessionToken"),
  };
}

function validateInviteAcceptInput(payload) {
  return {
    inviteToken: readRequiredString(payload, "inviteToken"),
    password: readStrongPassword(payload, "password"),
    label: payload?.label ? readRequiredString(payload, "label") : "invite-acceptance",
  };
}

function validatePasswordChangeInput(payload) {
  return {
    currentPassword: readRequiredString(payload, "currentPassword"),
    newPassword: readStrongPassword(payload, "newPassword"),
    revokeOtherSessions: payload?.revokeOtherSessions !== false,
  };
}

function validateSessionRevokeInput(payload) {
  return {
    sessionId: readRequiredString(payload, "sessionId"),
  };
}

function validatePasswordResetRequestInput(payload) {
  const email = readRequiredString(payload, "email").toLowerCase();
  const orgSlug = payload?.orgSlug ? readRequiredString(payload, "orgSlug") : "";

  if (!email.includes("@")) {
    throw badRequest("email must be valid");
  }

  return {
    email,
    orgSlug,
  };
}

function validatePasswordResetConfirmInput(payload) {
  return {
    resetToken: readRequiredString(payload, "resetToken"),
    newPassword: readStrongPassword(payload, "newPassword"),
    label: payload?.label ? readRequiredString(payload, "label") : "password-reset",
  };
}

function validateAutomationStateInput(payload) {
  const employeeId = readRequiredString(payload, "employeeId");
  const automationId = readRequiredString(payload, "automationId");
  const state = readRequiredString(payload, "state");

  if (!AUTOMATION_STATES.has(state)) {
    throw badRequest(`state must be one of: ${[...AUTOMATION_STATES].join(", ")}`);
  }

  return { employeeId, automationId, state };
}

function validateAutomationDecisionInput(payload) {
  const employeeId = readRequiredString(payload, "employeeId");
  const automationId = readRequiredString(payload, "automationId");
  const actorRole = readRequiredString(payload, "actorRole");
  const decision = readRequiredString(payload, "decision");

  if (!ACTOR_ROLES.has(actorRole)) {
    throw badRequest("actorRole must be admin or employee");
  }

  if (!DECISIONS[actorRole].has(decision)) {
    throw badRequest(`decision is invalid for actorRole ${actorRole}`);
  }

  return { employeeId, automationId, actorRole, decision };
}

function validateAutomationRefreshInput(payload) {
  return {
    employeeId: typeof payload?.employeeId === "string" && payload.employeeId.trim() ? payload.employeeId.trim() : "",
  };
}

function validateConsentInput(payload) {
  const employeeId = readRequiredString(payload, "employeeId");
  const consentStatus = readRequiredString(payload, "consentStatus");

  if (!CONSENT_STATUSES.has(consentStatus)) {
    throw badRequest("consentStatus must be approved or pending");
  }

  return { employeeId, consentStatus };
}

function validateIntegrationConnectionInput(payload) {
  const provider = readRequiredString(payload, "provider").toLowerCase();
  const displayName = readRequiredString(payload, "displayName");
  const connectionMode = readRequiredString(payload, "connectionMode").toLowerCase();
  const scopes = Array.isArray(payload?.scopes) ? payload.scopes.filter((entry) => typeof entry === "string" && entry.trim() !== "") : [];
  const externalAccountRef = typeof payload?.externalAccountRef === "string" ? payload.externalAccountRef.trim() : "";

  if (!PROVIDERS.has(provider)) {
    throw badRequest("provider must be gmail, slack, or figma");
  }

  if (!CONNECTION_MODES.has(connectionMode)) {
    throw badRequest("connectionMode must be oauth, service-account, or webhook");
  }

  if (!scopes.length) {
    throw badRequest("scopes must be a non-empty array");
  }

  return {
    provider,
    displayName,
    connectionMode,
    scopes,
    externalAccountRef,
  };
}

function validateDeviceRegisterInput(payload) {
  const userId = readRequiredString(payload, "userId");
  const label = readRequiredString(payload, "label");
  const platform = readRequiredString(payload, "platform").toLowerCase();

  if (!PLATFORM_VALUES.has(platform)) {
    throw badRequest("platform must be macos, windows, or linux");
  }

  return {
    userId,
    label,
    platform,
  };
}

function validateDeviceRevokeInput(payload) {
  return {
    deviceId: readRequiredString(payload, "deviceId"),
  };
}

function validateObserverBatchInput(payload) {
  const deviceId = readRequiredString(payload, "deviceId");
  const ingestKey = readRequiredString(payload, "ingestKey");
  const provider = readRequiredString(payload, "provider").toLowerCase();
  const events = payload?.events;

  if (!PROVIDERS.has(provider)) {
    throw badRequest("provider must be gmail, slack, or figma");
  }

  if (!Array.isArray(events) || events.length === 0) {
    throw badRequest("events must be a non-empty array");
  }

  return {
    deviceId,
    ingestKey,
    provider,
    events,
  };
}

function validatePlanRequestInput(payload) {
  const requestType = readRequiredString(payload, "requestType").toLowerCase();
  const note = typeof payload?.note === "string" ? payload.note.trim() : "";
  const requestedPlan = typeof payload?.requestedPlan === "string" ? payload.requestedPlan.trim() : "";

  if (!PLAN_REQUEST_TYPES.has(requestType)) {
    throw badRequest("requestType must be upgrade, downgrade, or cancel");
  }

  if (requestType !== "cancel" && !requestedPlan) {
    throw badRequest("requestedPlan is required for upgrade or downgrade");
  }

  return {
    requestType,
    requestedPlan,
    note,
  };
}

function validateLocalObserverEventsInput(payload) {
  const deviceId = readRequiredString(payload, "deviceId");
  const events = payload?.events;

  if (!Array.isArray(events) || !events.length) {
    throw badRequest("events must be a non-empty array");
  }

  if (events.length > 100) {
    throw badRequest("events may contain at most 100 entries");
  }

  return {
    deviceId,
    events: events.map((event, index) => {
      const base = {
        sourceKey: readRequiredString(event, "sourceKey"),
        occurredAt: readRequiredString(event, "occurredAt"),
        appName: readRequiredString(event, "appName"),
        screenType: readRequiredString(event, "screenType"),
        semanticAction: readRequiredString(event, "semanticAction"),
        workflowHint: readRequiredString(event, "workflowHint"),
        description: readRequiredString(event, "description"),
        confidenceScore: Number(event?.confidenceScore),
        cursorX: Number.isFinite(Number(event?.cursorX)) ? Number(event.cursorX) : 0,
        cursorY: Number.isFinite(Number(event?.cursorY)) ? Number(event.cursorY) : 0,
        clickCount: Number.isFinite(Number(event?.clickCount)) ? Number(event.clickCount) : 0,
        inputMode: typeof event?.inputMode === "string" ? event.inputMode.trim() : "",
        captureReason: typeof event?.captureReason === "string" ? event.captureReason.trim() : "",
        appId: typeof event?.appId === "string" ? event.appId.trim() : "",
        windowTitle: typeof event?.windowTitle === "string" ? event.windowTitle.trim() : "",
        screenSummary: typeof event?.screenSummary === "object" && event.screenSummary ? event.screenSummary : {},
        interactionSummary: typeof event?.interactionSummary === "object" && event.interactionSummary ? event.interactionSummary : {},
        transcript: Array.isArray(event?.transcript) ? event.transcript : [],
      };

      if (!Number.isFinite(base.confidenceScore) || base.confidenceScore < 0 || base.confidenceScore > 1) {
        throw badRequest(`events[${index}].confidenceScore must be between 0 and 1`);
      }

      return base;
    }),
  };
}

module.exports = {
  badRequest,
  notFound,
  validateAutomationDecisionInput,
  validateAutomationRefreshInput,
  validateAutomationStateInput,
  validateCompanyRegistrationInput,
  validateConsentInput,
  validateCurrentUserInput,
  validateDeviceRevokeInput,
  validateDeviceRegisterInput,
  validateEmployeeInput,
  validateIntegrationConnectionInput,
  validateInviteAcceptInput,
  validateLoginInput,
  validateLocalObserverEventsInput,
  validateLogoutInput,
  validateObserverBatchInput,
  validatePasswordChangeInput,
  validatePasswordResetConfirmInput,
  validatePasswordResetRequestInput,
  validatePlanRequestInput,
  validateSessionRevokeInput,
};

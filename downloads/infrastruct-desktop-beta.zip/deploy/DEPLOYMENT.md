# Hosted Deployment

This repo now contains a deployable backend API image in [Dockerfile.api](/Users/alexdils/Downloads/companies/infrastruct/Dockerfile.api).

Hosted image note:

- The backend uses `node:sqlite`, so the container must run on Node 25 or newer.
- If you build the image from Apple Silicon for App Runner, build an `amd64` image to avoid architecture mismatches during deploy.

## Local Container Run

```bash
docker compose -f deploy/docker-compose.backend.yml up --build
```

## ECR / App Runner Rebuild

Use an x86_64 image for App Runner:

```bash
docker build --platform linux/amd64 -f Dockerfile.api -t infrastruct-api .
docker tag infrastruct-api:latest 093487859827.dkr.ecr.us-east-2.amazonaws.com/infrastruct-api:latest
docker push 093487859827.dkr.ecr.us-east-2.amazonaws.com/infrastruct-api:latest
```

## AWS / RDS Prep

The repo now includes:

- [deploy/apprunner.yaml](/Users/alexdils/Downloads/companies/infrastruct/deploy/apprunner.yaml) for App Runner env/secrets layout
- `npm run backend:pg:check` to verify an RDS/Postgres connection
- `npm run backend:pg:sync` to push the current SQLite workspace state into Postgres

Required env:

```bash
INFRASTRUCT_DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/infrastruct?sslmode=require
```

Recommended first run after setting the URL:

```bash
npm run backend:pg:check
npm run backend:pg:sync
```

## Runtime Ops

Local ops commands now available in this repo:

```bash
npm run backend:maintenance
npm run backend:backup
```

Operational endpoints:

- `GET /health`
- `GET /metrics`

## What You Still Need For Real Hosted Deployment

1. Choose a host for the API container.
   Examples: Fly.io, Render, Railway, ECS, Cloud Run.
2. Replace `.env.example` values with real secrets.
3. Set `INFRASTRUCT_BOOTSTRAP_PASSWORD` to a non-demo value.
4. Add a persistent volume for `/data/infrastruct.db` or swap SQLite for managed Postgres.
5. Put the API behind TLS and a real domain.
6. Store OAuth secrets in the cloud provider secret manager, not in plain env files.
7. Add centralized logs and uptime monitoring.

## Recommended Production Shape

- Backend API in a container
- Managed Postgres instead of SQLite
- Managed secrets
- Object storage for exported reports
- Background worker for observer ingestion and report generation
- SSO/OAuth callback URLs pointed at the hosted API domain
- Monitoring scraping `GET /metrics` and uptime checks hitting `GET /health`

## Current Boundary

The repo now has Postgres/RDS sync tooling and App Runner deployment scaffolding.

What is still not finished:

- the live API runtime itself is still SQLite-backed
- a full async Postgres repository for the main server
- CI/CD deployment execution into your AWS account

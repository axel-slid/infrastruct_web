const net = require("net");
const path = require("path");
const { app, BrowserWindow, ipcMain, shell, systemPreferences } = require("electron");
const { startServer } = require("./backend/server");
const { createDesktopObserverService } = require("./desktop-observer");

let backendRuntime = null;
let backendBaseUrl = "";
let currentSessionToken = "";
let desktopObserver = null;

// Observer event queue — batched and flushed every 5 s
const observerQueue = [];
let observerFlushTimer = null;

async function findAvailablePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      server.close((error) => {
        if (error) {
          reject(error);
          return;
        }
        resolve(address.port);
      });
    });
  });
}

async function apiRequest(pathname, options = {}) {
  if (!backendBaseUrl) {
    throw new Error("Desktop backend is not ready");
  }

  const headers = { "Content-Type": "application/json" };
  if (currentSessionToken) {
    headers["X-Infrastruct-Session"] = currentSessionToken;
  }

  const response = await fetch(`${backendBaseUrl}${pathname}`, {
    method: options.method || "GET",
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (!response.ok) {
    throw new Error(payload?.error || `Request failed with status ${response.status}`);
  }

  return payload;
}

async function syncObserverForSession() {
  if (!desktopObserver) {
    return null;
  }

  if (!currentSessionToken) {
    await desktopObserver.stop("signed-out").catch(() => {});
    return desktopObserver.getStatus();
  }

  return desktopObserver.start();
}

async function flushObserverQueue() {
  observerFlushTimer = null;
  if (!observerQueue.length) return;

  // Group pending events by deviceId + provider
  const batches = new Map();
  while (observerQueue.length) {
    const item = observerQueue.shift();
    const key = `${item.deviceId}::${item.provider}`;
    if (!batches.has(key)) {
      batches.set(key, { deviceId: item.deviceId, ingestKey: item.ingestKey, provider: item.provider, events: [] });
    }
    batches.get(key).events.push(item.event);
  }

  for (const batch of batches.values()) {
    try {
      await apiRequest("/api/observer/events/batch", { method: "POST", body: batch });
    } catch (err) {
      // Re-queue failed events so they are retried on the next flush
      batch.events.forEach((event) => {
        observerQueue.push({ deviceId: batch.deviceId, ingestKey: batch.ingestKey, provider: batch.provider, event });
      });
    }
  }
}

function scheduleObserverFlush() {
  if (observerFlushTimer) return;
  observerFlushTimer = setTimeout(flushObserverQueue, 5000);
}

function registerIpcHandlers() {
  // Runtime info
  ipcMain.handle("desktop:get-runtime", async () => ({
    shell: "desktop",
    platform: process.platform,
    version: process.versions.electron,
    backendMode: "Local API + SQLite",
    backendUrl: backendBaseUrl,
  }));

  // Auth
  ipcMain.handle("auth:login", async (_event, payload) => {
    const result = await apiRequest("/api/auth/login", { method: "POST", body: payload });
    if (result.sessionToken) {
      currentSessionToken = result.sessionToken;
      await syncObserverForSession().catch(() => {});
    }
    return result;
  });

  ipcMain.handle("auth:list-company-codes", async () => {
    return apiRequest("/api/auth/company-codes");
  });

  ipcMain.handle("auth:list-demo-accounts", async () => {
    return apiRequest("/api/auth/demo-accounts");
  });

  ipcMain.handle("auth:register-company", async (_event, payload) => {
    const result = await apiRequest("/api/auth/register-company", { method: "POST", body: payload });
    if (result.sessionToken) {
      currentSessionToken = result.sessionToken;
      await syncObserverForSession().catch(() => {});
    }
    return result;
  });

  ipcMain.handle("auth:accept-invite", async (_event, payload) => {
    const result = await apiRequest("/api/auth/accept-invite", { method: "POST", body: payload });
    if (result.sessionToken) {
      currentSessionToken = result.sessionToken;
      await syncObserverForSession().catch(() => {});
    }
    return result;
  });

  ipcMain.handle("auth:logout", async () => {
    if (!currentSessionToken) return { ok: true };
    const result = await apiRequest("/api/auth/logout", {
      method: "POST",
      body: { sessionToken: currentSessionToken },
    });
    currentSessionToken = "";
    await syncObserverForSession().catch(() => {});
    return result;
  });

  ipcMain.handle("auth:session", async () => {
    if (!currentSessionToken) return null;
    return apiRequest("/api/auth/session");
  });

  ipcMain.handle("auth:change-password", async (_event, payload) => {
    return apiRequest("/api/auth/password", { method: "POST", body: payload });
  });

  ipcMain.handle("auth:request-password-reset", async (_event, payload) => {
    return apiRequest("/api/auth/password/reset/request", { method: "POST", body: payload });
  });

  ipcMain.handle("auth:confirm-password-reset", async (_event, payload) => {
    const result = await apiRequest("/api/auth/password/reset/confirm", { method: "POST", body: payload });
    if (result.sessionToken) {
      currentSessionToken = result.sessionToken;
      await syncObserverForSession().catch(() => {});
    }
    return result;
  });

  ipcMain.handle("auth:list-sessions", async (_event, userId = "") => {
    const qs = new URLSearchParams();
    if (userId) qs.set("userId", userId);
    return apiRequest(`/api/auth/sessions${qs.toString() ? `?${qs}` : ""}`);
  });

  ipcMain.handle("auth:revoke-session", async (_event, payload) => {
    const result = await apiRequest("/api/auth/sessions/revoke", { method: "POST", body: payload });
    if (result.revokedCurrentSession) {
      currentSessionToken = "";
    }
    return result;
  });

  // Workspace / session
  ipcMain.handle("workspace:get", async () => apiRequest("/api/workspace"));
  ipcMain.handle("workspace:providers", async () => apiRequest("/api/providers"));

  ipcMain.handle("workspace:set-current-user", async (_event, userId) => {
    return apiRequest("/api/session/current-user", { method: "POST", body: { userId } });
  });

  ipcMain.handle("workspace:add-employee", async (_event, payload) => {
    return apiRequest("/api/employees", { method: "POST", body: payload });
  });

  ipcMain.handle("workspace:list-invites", async () => {
    return apiRequest("/api/invites");
  });

  ipcMain.handle("workspace:set-automation-decision", async (_event, payload) => {
    return apiRequest("/api/automations/decision", { method: "POST", body: payload });
  });

  ipcMain.handle("workspace:set-automation-state", async (_event, payload) => {
    return apiRequest("/api/automations/state", { method: "POST", body: payload });
  });

  ipcMain.handle("workspace:refresh-automations", async (_event, payload = {}) => {
    return apiRequest("/api/automations/refresh", { method: "POST", body: payload });
  });

  ipcMain.handle("workspace:set-consent-status", async (_event, payload) => {
    return apiRequest("/api/consent", { method: "POST", body: payload });
  });

  ipcMain.handle("workspace:request-plan-change", async (_event, payload) => {
    return apiRequest("/api/plan-requests", { method: "POST", body: payload });
  });

  // Employees
  ipcMain.handle("employees:get", async (_event, employeeId) => {
    return apiRequest(`/api/employees/${encodeURIComponent(employeeId)}`);
  });

  // Integrations
  ipcMain.handle("integrations:list", async () => {
    return apiRequest("/api/organizations/current/integrations");
  });

  ipcMain.handle("integrations:connect", async (_event, payload) => {
    return apiRequest("/api/organizations/current/integrations", { method: "POST", body: payload });
  });

  // Devices
  ipcMain.handle("devices:list", async () => {
    return apiRequest("/api/organizations/current/devices");
  });

  ipcMain.handle("devices:register", async (_event, payload) => {
    return apiRequest("/api/devices/register", { method: "POST", body: payload });
  });

  ipcMain.handle("devices:revoke", async (_event, payload) => {
    return apiRequest("/api/devices/revoke", { method: "POST", body: payload });
  });

  // Observer
  ipcMain.handle("observer:queue-event", (_event, payload) => {
    observerQueue.push(payload);
    scheduleObserverFlush();
    return { queued: true, pending: observerQueue.length };
  });

  ipcMain.handle("observer:flush", async () => {
    await flushObserverQueue();
    return { ok: true };
  });

  ipcMain.handle("observer:status", async () => {
    return desktopObserver?.getStatus() || null;
  });

  ipcMain.handle("observer:start", async () => {
    return syncObserverForSession();
  });

  ipcMain.handle("observer:stop", async () => {
    return desktopObserver?.stop("manual") || { ok: true };
  });

  ipcMain.handle("observer:sample-now", async () => {
    return desktopObserver?.sampleNow() || null;
  });

  ipcMain.handle("observer:prompt-accessibility", async () => {
    if (process.platform !== "darwin") {
      return { prompted: false, reason: "unsupported-platform" };
    }

    const granted = systemPreferences.isTrustedAccessibilityClient(true);
    return {
      prompted: true,
      granted,
    };
  });

  ipcMain.handle("observer:open-privacy-settings", async (_event, target = "accessibility") => {
    if (process.platform !== "darwin") {
      return { opened: false, reason: "unsupported-platform" };
    }

    const suffix = target === "screen"
      ? "Privacy_ScreenCapture"
      : "Privacy_Accessibility";
    await shell.openExternal(`x-apple.systempreferences:com.apple.preference.security?${suffix}`);
    return { opened: true, target };
  });

  ipcMain.handle("observer:events", async (_event, params = {}) => {
    const qs = new URLSearchParams();
    if (params.limit) qs.set("limit", params.limit);
    if (params.provider) qs.set("provider", params.provider);
    if (params.employeeId) qs.set("employeeId", params.employeeId);
    return apiRequest(`/api/observer/events${qs.toString() ? `?${qs}` : ""}`);
  });

  ipcMain.handle("observer:workflows", async (_event, params = {}) => {
    const qs = new URLSearchParams();
    if (params.limit) qs.set("limit", params.limit);
    if (params.employeeId) qs.set("employeeId", params.employeeId);
    return apiRequest(`/api/observer/workflows${qs.toString() ? `?${qs}` : ""}`);
  });

  // Audit
  ipcMain.handle("audit:events", async (_event, params = {}) => {
    const qs = new URLSearchParams();
    if (params.limit) qs.set("limit", params.limit);
    return apiRequest(`/api/audit-events${qs.toString() ? `?${qs}` : ""}`);
  });

  // Reports
  ipcMain.handle("reports:list", async () => apiRequest("/api/reports"));

  ipcMain.handle("reports:get", async (_event, employeeId) => {
    return apiRequest(`/api/reports/${encodeURIComponent(employeeId)}`);
  });

  ipcMain.handle("recommendations:list", async (_event, params = {}) => {
    const qs = new URLSearchParams();
    if (params.limit) qs.set("limit", params.limit);
    return apiRequest(`/api/automation-opportunities${qs.toString() ? `?${qs}` : ""}`);
  });

  // Organizations
  ipcMain.handle("organizations:list", async () => apiRequest("/api/organizations"));
  ipcMain.handle("clients:list", async () => apiRequest("/api/clients"));
  ipcMain.handle("clients:get", async (_event, clientId) => apiRequest(`/api/clients/${encodeURIComponent(clientId)}`));
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1540,
    height: 980,
    minWidth: 1200,
    minHeight: 760,
    backgroundColor: "#f5f0e8",
    title: "Infrastruct",
    titleBarStyle: "hiddenInset",
    trafficLightPosition: { x: 18, y: 18 },
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  win.webContents.on("console-message", (_event, level, message, line, sourceId) => {
    console.log(`[renderer:${level}] ${sourceId || "app"}:${line} ${message}`);
  });

  win.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
    console.error("Renderer failed to load", { errorCode, errorDescription, validatedURL });
  });

  win.webContents.on("render-process-gone", (_event, details) => {
    console.error("Renderer process gone", details);
  });

  win.loadFile(path.join(__dirname, "Infrastruct_web", "index.html"));
}

async function startDesktopBackend() {
  const port = await findAvailablePort();
  const dbPath = path.join(app.getPath("userData"), "infrastruct.db");
  backendRuntime = await startServer({
    host: "127.0.0.1",
    port,
    dbPath,
  });
  backendBaseUrl = `http://${backendRuntime.host}:${backendRuntime.port}`;
  currentSessionToken = "";
  desktopObserver = createDesktopObserverService({
    apiRequest,
    onStatusChange: () => {},
    userDataPath: app.getPath("userData"),
  });
}

async function stopDesktopBackend() {
  if (observerFlushTimer) {
    clearTimeout(observerFlushTimer);
    observerFlushTimer = null;
    await flushObserverQueue().catch(() => {});
  }

  if (desktopObserver) {
    await desktopObserver.stop("shutdown").catch(() => {});
    desktopObserver = null;
  }

  if (!backendRuntime?.server) {
    return;
  }

  await new Promise((resolve, reject) => {
    backendRuntime.server.close((error) => {
      backendRuntime.repository.close();
      if (error) {
        reject(error);
        return;
      }
      resolve();
    });
  });

  backendRuntime = null;
  backendBaseUrl = "";
}

app.whenReady().then(async () => {
  await startDesktopBackend();
  registerIpcHandlers();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("before-quit", async (event) => {
  if (!backendRuntime?.server) {
    return;
  }

  event.preventDefault();
  await stopDesktopBackend().catch((error) => {
    console.error("Failed to stop backend cleanly", error);
  });
  app.exit();
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

const fs = require("fs/promises");
const path = require("path");
const { randomUUID } = require("crypto");
const { createSeedWorkspace } = require("./seed-data");

class WorkspaceStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.cache = null;
  }

  async load() {
    if (this.cache) {
      return this.cache;
    }

    try {
      const raw = await fs.readFile(this.filePath, "utf8");
      this.cache = JSON.parse(raw);
    } catch (error) {
      if (error.code !== "ENOENT") {
        throw error;
      }

      this.cache = createSeedWorkspace();
      await this.persist();
    }

    return this.cache;
  }

  async persist() {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    await fs.writeFile(this.filePath, JSON.stringify(this.cache, null, 2));
  }

  async snapshot() {
    const data = await this.load();
    return structuredClone(data);
  }

  async listEmployees() {
    const data = await this.load();
    return structuredClone(data.users.filter((entry) => entry.role === "employee"));
  }

  async getEmployee(employeeId) {
    const data = await this.load();
    const employee = data.users.find((entry) => entry.id === employeeId && entry.role === "employee");

    if (!employee) {
      throw new Error("Employee not found");
    }

    return structuredClone(employee);
  }

  async setCurrentUser(userId) {
    const data = await this.load();
    const user = data.users.find((entry) => entry.id === userId);

    if (!user) {
      throw new Error("User not found");
    }

    data.session.currentUserId = userId;
    await this.persist();
    return structuredClone(data);
  }

  async addEmployee(payload) {
    const data = await this.load();
    const seatLimit = data.workspace.plan.seatLimit;
    const seatCount = data.users.filter((entry) => entry.role === "employee").length;

    if (seatCount >= seatLimit) {
      throw new Error("Plan seat limit reached");
    }

    const slug = payload.name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const employee = {
      id: `emp-${slug}-${randomUUID().slice(0, 8)}`,
      role: "employee",
      name: payload.name,
      title: payload.title,
      team: payload.team,
      email: payload.email,
      status: "awaiting-consent",
      consentStatus: "pending",
      lastSeen: "New seat",
      reclaimableHours: 0,
      automationReadiness: 0,
      profileSummary: [
        "Observation has not started yet.",
        "The desktop agent will begin profiling once consent is granted.",
      ],
      apps: [],
      actions: [],
      access: [],
      automations: [],
      report: {
        headline: "No report generated yet.",
        findings: ["Observation has not started yet."],
      },
    };

    data.users.push(employee);
    data.workspace.plan.seatsUsed = seatCount + 1;
    await this.persist();
    return structuredClone(data);
  }

  async setAutomationDecision(payload) {
    const data = await this.load();
    const employee = data.users.find((entry) => entry.id === payload.employeeId && entry.role === "employee");

    if (!employee) {
      throw new Error("Employee not found");
    }

    const automation = employee.automations.find((entry) => entry.id === payload.automationId);

    if (!automation) {
      throw new Error("Automation not found");
    }

    if (payload.actorRole === "admin") {
      automation.adminDecision = payload.decision;
    } else {
      automation.employeeDecision = payload.decision;
    }

    if (automation.adminDecision === "approved" && automation.employeeDecision === "accepted") {
      automation.status = "active";
    } else if (automation.adminDecision === "rejected" || automation.employeeDecision === "rejected") {
      automation.status = "rejected";
    } else if (automation.adminDecision === "approved") {
      automation.status = "proposed";
    } else {
      automation.status = "review";
    }

    await this.persist();
    return structuredClone(data);
  }

  async setConsentStatus(payload) {
    const data = await this.load();
    const employee = data.users.find((entry) => entry.id === payload.employeeId && entry.role === "employee");

    if (!employee) {
      throw new Error("Employee not found");
    }

    employee.consentStatus = payload.consentStatus;
    employee.status = payload.consentStatus === "approved" ? "observing" : "awaiting-consent";
    employee.lastSeen = payload.consentStatus === "approved" ? "Active just now" : "Needs onboarding";
    await this.persist();
    return structuredClone(data);
  }
}

module.exports = {
  WorkspaceStore,
};

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("infrastructDesktop", {
  runtime: {
    get: () => ipcRenderer.invoke("desktop:get-runtime"),
  },
  auth: {
    listCompanyCodes: () => ipcRenderer.invoke("auth:list-company-codes"),
    listDemoAccounts: () => ipcRenderer.invoke("auth:list-demo-accounts"),
    login: (payload) => ipcRenderer.invoke("auth:login", payload),
    registerCompany: (payload) => ipcRenderer.invoke("auth:register-company", payload),
    acceptInvite: (payload) => ipcRenderer.invoke("auth:accept-invite", payload),
    logout: () => ipcRenderer.invoke("auth:logout"),
    session: () => ipcRenderer.invoke("auth:session"),
    changePassword: (payload) => ipcRenderer.invoke("auth:change-password", payload),
    requestPasswordReset: (payload) => ipcRenderer.invoke("auth:request-password-reset", payload),
    confirmPasswordReset: (payload) => ipcRenderer.invoke("auth:confirm-password-reset", payload),
    listSessions: (userId) => ipcRenderer.invoke("auth:list-sessions", userId),
    revokeSession: (payload) => ipcRenderer.invoke("auth:revoke-session", payload),
  },
  workspace: {
    get: () => ipcRenderer.invoke("workspace:get"),
    providers: () => ipcRenderer.invoke("workspace:providers"),
    setCurrentUser: (userId) => ipcRenderer.invoke("workspace:set-current-user", userId),
    addEmployee: (payload) => ipcRenderer.invoke("workspace:add-employee", payload),
    listInvites: () => ipcRenderer.invoke("workspace:list-invites"),
    setAutomationDecision: (payload) => ipcRenderer.invoke("workspace:set-automation-decision", payload),
    setAutomationState: (payload) => ipcRenderer.invoke("workspace:set-automation-state", payload),
    refreshAutomations: (payload) => ipcRenderer.invoke("workspace:refresh-automations", payload),
    setConsentStatus: (payload) => ipcRenderer.invoke("workspace:set-consent-status", payload),
    requestPlanChange: (payload) => ipcRenderer.invoke("workspace:request-plan-change", payload),
  },
  employees: {
    get: (employeeId) => ipcRenderer.invoke("employees:get", employeeId),
  },
  integrations: {
    list: () => ipcRenderer.invoke("integrations:list"),
    connect: (payload) => ipcRenderer.invoke("integrations:connect", payload),
  },
  devices: {
    list: () => ipcRenderer.invoke("devices:list"),
    register: (payload) => ipcRenderer.invoke("devices:register", payload),
    revoke: (payload) => ipcRenderer.invoke("devices:revoke", payload),
  },
  observer: {
    queueEvent: (payload) => ipcRenderer.invoke("observer:queue-event", payload),
    flush: () => ipcRenderer.invoke("observer:flush"),
    status: () => ipcRenderer.invoke("observer:status"),
    start: () => ipcRenderer.invoke("observer:start"),
    stop: () => ipcRenderer.invoke("observer:stop"),
    sampleNow: () => ipcRenderer.invoke("observer:sample-now"),
    promptAccessibility: () => ipcRenderer.invoke("observer:prompt-accessibility"),
    openPrivacySettings: (target) => ipcRenderer.invoke("observer:open-privacy-settings", target),
    events: (params) => ipcRenderer.invoke("observer:events", params),
    workflows: (params) => ipcRenderer.invoke("observer:workflows", params),
  },
  audit: {
    events: (params) => ipcRenderer.invoke("audit:events", params),
  },
  reports: {
    list: () => ipcRenderer.invoke("reports:list"),
    get: (employeeId) => ipcRenderer.invoke("reports:get", employeeId),
  },
  recommendations: {
    list: (params) => ipcRenderer.invoke("recommendations:list", params),
  },
  organizations: {
    list: () => ipcRenderer.invoke("organizations:list"),
  },
  clients: {
    list: () => ipcRenderer.invoke("clients:list"),
    get: (clientId) => ipcRenderer.invoke("clients:get", clientId),
  },
});

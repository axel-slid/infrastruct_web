# Production Handoff Checklist

This is the finished launch checklist for turning the current repo into a real hosted product.

## 1. Current State

Already implemented in this repo:

- [x] Desktop Electron app
- [x] Local backend API
- [x] SQLite persistence
- [x] Organization-aware backend schema
- [x] Local auth and API session model
- [x] Tenant-scoped employees, automations, reports, and audit events
- [x] Device registration for observer uploads
- [x] Observer ingestion endpoints
- [x] Gmail event normalization scaffold
- [x] Slack event normalization scaffold
- [x] Figma event normalization scaffold
- [x] Integration registry and health state
- [x] Docker backend scaffold
- [x] Local smoke test for auth, integrations, devices, and observer ingest

Still not complete for external production:

- [ ] Hosted cloud deployment
- [ ] Managed Postgres
- [ ] Real OAuth credentials
- [ ] Real OAuth callback handling
- [ ] Real webhook endpoints exposed publicly
- [ ] Secure desktop login UX
- [ ] Secret manager integration
- [ ] Monitoring and alerting
- [x] Email/invite delivery scaffold
- [x] Observer redaction and retention scaffold
- [x] Support-role client directory with tenant-scoped admin access
- [ ] Formal privacy/compliance rollout

## 2. Accounts You Need

- [ ] Cloud provider account
  Recommended: AWS, GCP, Fly.io, Render, or Railway
- [ ] Domain and DNS access
- [ ] Managed database account if separate from the cloud host
- [ ] Secret manager access
- [ ] Google Cloud account for Gmail OAuth
- [ ] Slack developer account for Slack app setup
- [ ] Figma developer account for OAuth/webhook setup
- [ ] Email delivery provider
  Recommended: Postmark, Resend, or SendGrid
- [ ] Apple Developer account if you want signed macOS distribution

## 3. Secrets And Env Vars

Values you must set before any real deployment:

- [ ] `INFRASTRUCT_BOOTSTRAP_PASSWORD`
- [ ] `INFRASTRUCT_API_HOST`
- [ ] `INFRASTRUCT_API_PORT`
- [ ] `INFRASTRUCT_API_DB_PATH`
- [ ] `INFRASTRUCT_SESSION_TTL_DAYS`
- [ ] `GOOGLE_CLIENT_ID`
- [ ] `GOOGLE_CLIENT_SECRET`
- [ ] `SLACK_CLIENT_ID`
- [ ] `SLACK_CLIENT_SECRET`
- [ ] `SLACK_SIGNING_SECRET`
- [ ] `FIGMA_CLIENT_ID`
- [ ] `FIGMA_CLIENT_SECRET`
- [ ] `FIGMA_WEBHOOK_SECRET`

Files to use:

- [ ] Copy [.env.example](/Users/alexdils/Downloads/companies/infrastruct/.env.example) into a real private env file for local testing
- [ ] Store production values in a cloud secret manager, not in the repo

## 4. Database And Persistence

- [ ] Replace SQLite with managed Postgres before public rollout
- [ ] Recreate the current repository schema in Postgres
- [ ] Add migration files instead of schema-only bootstrap
- [ ] Add migration execution in CI/CD
- [ ] Add daily backups
- [ ] Add restore test for backups
- [ ] Add staging database separate from production
- [ ] Add encryption-at-rest validation on the production database

## 5. Auth And Identity

Decide first:

- [ ] Keep the built-in password auth for early staging
- [ ] Or replace it with hosted auth before production
  Recommended production direction: hosted auth or enterprise SSO

If keeping current auth temporarily:

- [x] Add password reset flow
- [ ] Add email verification flow
- [x] Add password rotation flow for invited users
- [ ] Add account lockout / brute-force protection
- [ ] Add secure session revocation UI

If moving to hosted auth:

- [ ] Choose provider
  Recommended: Clerk, Auth0, WorkOS, or Supabase Auth
- [ ] Map auth identities to org memberships
- [ ] Map auth identities to desktop sessions
- [ ] Add admin role mapping
- [ ] Add employee role mapping

Regardless of auth choice:

- [ ] Replace the current demo user switcher in the desktop app with real login
- [ ] Store session tokens securely in the desktop app
- [ ] Add logout flow in desktop UI
- [x] Add invite acceptance flow
- [x] Add seat enforcement on invites and membership activation

## 6. Organization And Tenant Isolation

- [x] Enforce tenant scoping on every backend query
- [ ] Add tenant-aware integration ownership
- [ ] Add tenant-aware device ownership
- [ ] Add tenant-aware report exports
- [x] Add tests for cross-tenant access denial
- [x] Add support for multiple orgs per backend deployment
- [x] Add internal admin/support role policy if your team needs it

## 7. Google / Gmail Setup

- [ ] Create a Google Cloud project
- [ ] Enable the Gmail API
- [ ] Create OAuth credentials
- [ ] Add the hosted callback URL
- [ ] Configure the consent screen
- [ ] Add approved scopes only
- [ ] Verify whether the app needs Google verification for requested scopes
- [ ] Decide whether metadata-only Gmail access is enough for v1
- [ ] Test token refresh
- [ ] Test token revocation

Information you will need to supply:

- [ ] Google OAuth client ID
- [ ] Google OAuth client secret
- [ ] Hosted callback URL

## 8. Slack Setup

- [ ] Create a Slack app
- [ ] Configure OAuth scopes
- [ ] Configure the redirect URL
- [ ] Add the signing secret
- [ ] Decide whether the app uses bot tokens, user tokens, or both
- [ ] Configure event subscriptions if needed
- [ ] Test workspace installation
- [ ] Test token refresh or reinstall path if required
- [ ] Test uninstall / revoke behavior

Information you will need to supply:

- [ ] Slack client ID
- [ ] Slack client secret
- [ ] Slack signing secret
- [ ] Hosted redirect URL

## 9. Figma Setup

- [ ] Create a Figma OAuth app
- [ ] Configure redirect URL
- [ ] Configure webhook secret
- [ ] Decide what Figma events actually matter in v1
- [ ] Test webhook delivery against staging
- [ ] Test OAuth token refresh if supported
- [ ] Test deauthorization / disconnect flow

Information you will need to supply:

- [ ] Figma client ID
- [ ] Figma client secret
- [ ] Figma webhook secret
- [ ] Hosted redirect URL

## 10. Observer And Device Rollout

- [ ] Decide whether the observer runs as:
  Recommended now: dedicated desktop background service or hardened Electron helper
- [ ] Finalize the local event capture model
- [ ] Finalize what is metadata-only versus captured content
- [ ] Add batching and retry queue on device
- [ ] Add offline queue on device
- [ ] Add device revocation UI
- [ ] Add device health monitoring
- [x] Add rate limiting for observer ingest
- [x] Add abuse protection for ingest endpoints
- [x] Add event retention policy
- [x] Add raw-event deletion policy

## 11. Desktop App Release Work

- [ ] Replace demo sign-in with real auth screens
- [ ] Add integration onboarding screens
- [ ] Add device registration screens
- [ ] Add session-expired handling
- [ ] Add invite acceptance screen
- [ ] Add integration health page in admin UI
- [ ] Add devices page in admin UI
- [ ] Add signed macOS build process
- [ ] Add auto-update channel
- [ ] Add rollback path for bad desktop releases

## 12. Hosted Deployment

Use these files:

- [ ] [Dockerfile.api](/Users/alexdils/Downloads/companies/infrastruct/Dockerfile.api)
- [ ] [deploy/docker-compose.backend.yml](/Users/alexdils/Downloads/companies/infrastruct/deploy/docker-compose.backend.yml)
- [ ] [deploy/DEPLOYMENT.md](/Users/alexdils/Downloads/companies/infrastruct/deploy/DEPLOYMENT.md)

Infrastructure steps:

- [ ] Choose hosting target
- [ ] Build and publish the API image
- [ ] Provision staging environment
- [ ] Provision production environment
- [ ] Attach managed Postgres
- [ ] Configure secret manager
- [ ] Configure persistent object storage if reports or artifacts leave the DB
- [ ] Put the API behind TLS
- [ ] Attach the real domain
- [ ] Set OAuth callback URLs to the production domain
- [ ] Set webhook URLs to the production domain

## 13. Monitoring And Reliability

- [x] Add structured logs
- [x] Add request IDs
- [ ] Add error monitoring
  Recommended: Sentry
- [ ] Add uptime monitoring
- [x] Add metrics endpoint
- [ ] Add metrics dashboard
- [ ] Add health check monitoring
- [ ] Add alerting for ingest failures
- [ ] Add alerting for provider auth failures
- [ ] Add alerting for database issues
- [ ] Add alerting for job failures if background workers are introduced

## 14. Privacy, Consent, And Compliance

- [ ] Finalize employee consent wording
- [ ] Finalize admin disclosure wording
- [ ] Finalize metadata-only policy
- [ ] Finalize content retention rules
- [ ] Finalize deletion/export flows
- [ ] Add privacy policy
- [ ] Add terms of service
- [ ] Add internal incident response policy
- [ ] Decide whether SOC 2 readiness is required before first customer rollout
- [ ] Decide whether GDPR support is needed for first launch
- [ ] Decide whether any industry-specific compliance is actually in scope

## 15. Testing Before Launch

- [x] Run `npm run backend:smoke`
- [x] Add automated API integration tests
- [x] Add auth tests
- [x] Add tenant-isolation tests
- [ ] Add observer ingestion tests for Gmail
- [ ] Add observer ingestion tests for Slack
- [ ] Add observer ingestion tests for Figma
- [ ] Add desktop end-to-end login test
- [ ] Add desktop invite acceptance test
- [ ] Add staging load test for ingestion
- [x] Add security review for auth/session handling

## 16. Exact Release Sequence

Do these in order:

- [ ] 1. Create all external accounts
- [ ] 2. Fill real secrets
- [ ] 3. Choose hosted auth strategy
- [ ] 4. Move database to Postgres
- [ ] 5. Deploy staging backend
- [ ] 6. Register OAuth apps against staging URLs
- [ ] 7. Test Gmail auth and ingest
- [ ] 8. Test Slack auth and ingest
- [ ] 9. Test Figma auth and ingest
- [ ] 10. Replace desktop demo sign-in with real auth
- [ ] 11. Test full admin and employee flows in staging
- [ ] 12. Add monitoring and alerts
- [ ] 13. Run launch checklist on production
- [ ] 14. Deploy production backend
- [ ] 15. Ship signed desktop build

## 17. What I Need From You

To keep going past the local implementation, I need these from you:

- [ ] Cloud host choice
- [ ] Real domain name
- [ ] Decision on SQLite vs Postgres timing
- [ ] Decision on built-in auth vs hosted auth
- [ ] Google OAuth credentials
- [ ] Slack app credentials
- [ ] Figma app credentials
- [ ] Email provider choice
- [ ] Apple Developer credentials if you want signed macOS release

## 18. Recommended Decisions

If you want the fastest sane route:

- [ ] Host backend on Fly.io, Render, or Railway
- [ ] Use managed Postgres, not SQLite, for hosted environments
- [ ] Keep built-in auth only for staging
- [ ] Move to hosted auth before external production
- [ ] Ship Gmail + Slack first
- [ ] Keep Figma in pilot behind admin enablement
- [ ] Keep storage metadata-first for v1

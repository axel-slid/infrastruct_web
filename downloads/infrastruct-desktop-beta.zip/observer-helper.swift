import Foundation
import ApplicationServices
import CoreGraphics

struct StreamEvent: Encodable {
  let kind: String
  let occurredAt: String
  let x: Double?
  let y: Double?
  let keyCode: Int64?
  let keyLabel: String?
  let text: String?
  let modifiers: [String]
  let deltaY: Int64?
  let clickCount: Int64?
}

let isoFormatter = ISO8601DateFormatter()

func modifierNames(_ flags: CGEventFlags) -> [String] {
  var values: [String] = []
  if flags.contains(.maskCommand) { values.append("command") }
  if flags.contains(.maskShift) { values.append("shift") }
  if flags.contains(.maskControl) { values.append("control") }
  if flags.contains(.maskAlternate) { values.append("option") }
  if flags.contains(.maskSecondaryFn) { values.append("fn") }
  return values
}

func keyLabel(for keyCode: Int64) -> String {
  switch keyCode {
  case 36: return "return"
  case 48: return "tab"
  case 49: return "space"
  case 51: return "delete"
  case 53: return "escape"
  case 123: return "left"
  case 124: return "right"
  case 125: return "down"
  case 126: return "up"
  case 122: return "f1"
  case 120: return "f2"
  case 99: return "f3"
  case 118: return "f4"
  default: return "character"
  }
}

func typedText(for event: CGEvent) -> String? {
  var length: Int = 0
  var characters = [UniChar](repeating: 0, count: 8)
  event.keyboardGetUnicodeString(maxStringLength: characters.count, actualStringLength: &length, unicodeString: &characters)
  guard length > 0 else {
    return nil
  }

  let value = String(utf16CodeUnits: characters, count: length)
    .replacingOccurrences(of: "\u{7F}", with: "")
    .replacingOccurrences(of: "\r", with: "\n")

  return value.isEmpty ? nil : value
}

func emit(_ event: StreamEvent) {
  let encoder = JSONEncoder()
  guard let data = try? encoder.encode(event), let line = String(data: data, encoding: .utf8) else {
    return
  }
  print(line)
  fflush(stdout)
}

let eventMask =
  (1 << CGEventType.keyDown.rawValue) |
  (1 << CGEventType.leftMouseDown.rawValue) |
  (1 << CGEventType.rightMouseDown.rawValue) |
  (1 << CGEventType.scrollWheel.rawValue)

let callback: CGEventTapCallBack = { _, type, event, _ in
  let location = event.location
  let timestamp = isoFormatter.string(from: Date())

  switch type {
  case .keyDown:
    let keyCode = event.getIntegerValueField(.keyboardEventKeycode)
    emit(StreamEvent(
      kind: "keyDown",
      occurredAt: timestamp,
      x: nil,
      y: nil,
      keyCode: keyCode,
      keyLabel: keyLabel(for: keyCode),
      text: typedText(for: event),
      modifiers: modifierNames(event.flags),
      deltaY: nil,
      clickCount: nil
    ))
  case .leftMouseDown:
    emit(StreamEvent(
      kind: "leftMouseDown",
      occurredAt: timestamp,
      x: Double(location.x),
      y: Double(location.y),
      keyCode: nil,
      keyLabel: nil,
      text: nil,
      modifiers: modifierNames(event.flags),
      deltaY: nil,
      clickCount: event.getIntegerValueField(.mouseEventClickState)
    ))
  case .rightMouseDown:
    emit(StreamEvent(
      kind: "rightMouseDown",
      occurredAt: timestamp,
      x: Double(location.x),
      y: Double(location.y),
      keyCode: nil,
      keyLabel: nil,
      text: nil,
      modifiers: modifierNames(event.flags),
      deltaY: nil,
      clickCount: event.getIntegerValueField(.mouseEventClickState)
    ))
  case .scrollWheel:
    emit(StreamEvent(
      kind: "scrollWheel",
      occurredAt: timestamp,
      x: Double(location.x),
      y: Double(location.y),
      keyCode: nil,
      keyLabel: nil,
      text: nil,
      modifiers: modifierNames(event.flags),
      deltaY: event.getIntegerValueField(.scrollWheelEventDeltaAxis1),
      clickCount: nil
    ))
  default:
    break
  }

  return Unmanaged.passUnretained(event)
}

guard AXIsProcessTrusted() else {
  fputs("{\"error\":\"accessibility-not-granted\"}\n", stderr)
  fflush(stderr)
  exit(2)
}

guard let eventTap = CGEvent.tapCreate(
  tap: .cgSessionEventTap,
  place: .headInsertEventTap,
  options: .defaultTap,
  eventsOfInterest: CGEventMask(eventMask),
  callback: callback,
  userInfo: nil
) else {
  fputs("{\"error\":\"event-tap-create-failed\"}\n", stderr)
  fflush(stderr)
  exit(3)
}

let source = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, eventTap, 0)
CFRunLoopAddSource(CFRunLoopGetCurrent(), source, .commonModes)
CGEvent.tapEnable(tap: eventTap, enable: true)
print("{\"ready\":true}")
fflush(stdout)
CFRunLoopRun()

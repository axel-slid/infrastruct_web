# Infrastruct Backend Checklist

This checklist assumes the current app is an Electron desktop client with local-only seeded data and no real backend services yet.

## 1. Core Decisions

- [x] Choose the production backend stack. *(Node API modular monolith in Docker, SQLite locally, PostgreSQL for hosted production, AWS App Runner/ECS-style container deployment path.)*
- [x] Choose the primary cloud provider. *(AWS)*
- [x] Choose the production database. *(SQLite for local desktop; PostgreSQL for hosted production)*
- [x] Decide whether the desktop app talks directly to the API or through a sync/agent service. *(direct local API via IPC)*
- [x] Decide whether the observer agent runs as:
  - [x] an Electron helper process *(observer queue built into main.js)*
- [x] Define which apps are in v1 integration scope. *(Gmail, Slack, Figma)*
- [ ] Define exact trust boundaries:
  - [x] what metadata is stored *(documented in `backend/OPERATIONS.md`)*
  - [x] what content is stored *(documented in `backend/OPERATIONS.md`)*
  - [x] what never leaves the employee device *(documented in `backend/OPERATIONS.md`)*

## 2. Production Architecture

- [x] Replace local `workspace.json` persistence with a real backend API. *(SQLite + REST API in backend/)*
- [x] Split the system into services:
  - [x] API service *(backend/server.js)*
  - [x] auth/session service *(api_sessions table + login/logout endpoints)*
  - [x] ingestion service for observed actions *(POST /api/observer/events/batch)*
  - [x] automation recommendation service *(heuristic recommendation engine + POST /api/automations/refresh)*
  - [x] approval/workflow service *(POST /api/automations/decision + /state)*
  - [x] reporting service *(GET /api/reports + CSV export)*
  - [x] notification service *(Resend-compatible invite + password reset hooks)*
- [x] Decide whether to keep this as a modular monolith first or start with separate services. *(monolith first)*
- [ ] Define environment boundaries:
  - [x] local development *(documented in `backend/OPERATIONS.md`)*
  - [x] staging *(documented in `backend/OPERATIONS.md`)*
  - [x] production *(documented in `backend/OPERATIONS.md`)*

## 3. Data Model

- [x] Design tables for:
  - [x] organizations
  - [x] plans *(embedded in organizations: plan_name, seat_limit, etc.)*
  - [x] admins *(users with role=admin in memberships)*
  - [x] employees *(users with role=employee)*
  - [x] employee device installations *(device_installs)*
  - [x] app integrations *(integrations)*
  - [x] consent records *(users.consent_status + audit_events)*
  - [x] observed actions *(observed_actions)*
  - [x] action tags/classifications *(observed_actions.category)*
  - [x] learned profiles *(heuristic-generated profile_points are now persisted alongside manual points)*
  - [x] automation proposals *(automations)*
  - [x] approval decisions *(automations.admin_decision + employee_decision)*
  - [x] deployed automations *(automations.status = active/pilot)*
  - [x] reports *(reports + report_findings)*
  - [x] audit logs *(audit_events)*
  - [x] API keys / service credentials metadata *(api_sessions, device_installs.ingest_key_hash)*
- [x] Add timestamps and soft-delete strategy where needed.
- [x] Add tenant isolation to every org-owned record.
- [x] Add migration tooling. *(schema_migrations + versioned migration runner in repository.js)*
- [x] Seed a development dataset that mirrors the current mock data.

## 4. Auth, Identity, And Access Control

- [x] Add real sign-in for admins. *(POST /api/auth/login + IPC auth:login handler)*
- [x] Add real sign-in for employees. *(same endpoint)*
- [x] Choose auth provider: custom auth (scrypt passwords + opaque session tokens)
- [x] Add role-based access control:
  - [x] org admin
  - [x] employee
  - [ ] manager *(not yet a distinct role)*
  - [x] support / internal ops *(global client directory is limited to `support`)*
- [x] Add session management and refresh strategy. *(TTL-based api_sessions + list/revoke endpoints)*
- [x] Add invitation flow for employees. *(employee_invites table + invite token generation)*
- [x] Add invitation accept endpoint. *(GET /api/auth/invites/:token + POST /api/auth/accept-invite)*
- [x] Add org ownership and seat enforcement.
- [ ] Add SSO support plan for business customers.

## 5. API Surface

- [x] Design versioned REST API. *(all routes under /api/)*
- [x] Add endpoints for:
  - [x] current org/workspace *(GET /api/organizations/current, GET /api/workspace)*
  - [x] employee list *(GET /api/employees)*
  - [x] employee detail *(GET /api/employees/:id)*
  - [x] observed actions query *(GET /api/observer/events?limit=&provider=)*
  - [x] integration status *(GET /api/organizations/current/integrations)*
  - [x] consent status *(POST /api/consent)*
  - [x] automation proposal list *(embedded in /api/workspace snapshot)*
  - [x] approve/reject automation *(POST /api/automations/decision)*
  - [x] set automation state (pilot/paused/active) *(POST /api/automations/state)*
  - [x] reports *(GET /api/reports, GET /api/reports/:id, GET /api/reports/:id?format=csv)*
  - [x] add/invite employee *(POST /api/employees)*
  - [x] plan/seat usage *(embedded in GET /api/organizations/current)*
  - [x] health check *(GET /health)*
- [x] Add pagination, filtering for action history. *(limit + provider filter on observer events)*
- [x] Add server-side validation for every write endpoint.
- [x] Add idempotency for event and automation write paths. *(deduplication via UNIQUE constraint)*

## 6. Desktop App To Backend Connection

- [x] Replace direct IPC-backed local data mutation with API-backed state.
- [x] Add a backend client layer in the Electron app. *(apiRequest in main.js)*
- [x] Add token storage strategy for desktop sessions. *(currentSessionToken in main.js, synced with local_session_state)*
- [x] Add online/offline behavior:
  - [x] queue unsent observations locally *(observerQueue in main.js)*
  - [x] retry on reconnect *(failed batches re-queued, flushed every 5s)*
  - [ ] mark stale data in UI
- [ ] Add secure update path for the desktop app.

## 7. Observer / Ingestion Pipeline

- [x] Define the event schema for observed work. *(provider-adapters.js)*
- [ ] Implement local action capture pipeline. *(capture hooks not built; queue exists for when data arrives)*
- [x] Normalize events across apps. *(normalizeObserverEvents in provider-adapters.js)*
- [x] Add event batching and upload. *(observerQueue in main.js + POST /api/observer/events/batch)*
- [x] Add deduplication. *(UNIQUE on observed_actions(org_id, source, source_key))*
- [x] Add ingestion authentication per device install. *(ingest_key_hash)*
- [x] Add rate limiting and abuse protection. *(server-side limiters on login and observer ingest routes)*
- [x] Add redaction pipeline before persistence. *(redacted provider payloads are stored through `redactObserverEvent`)*
- [x] Add raw-event vs normalized-event retention policy. *(`INFRASTRUCT_RAW_EVENT_RETENTION_DAYS` + `npm run backend:maintenance`)*

## 8. Integrations

- [x] Choose v1 integrations to truly support. *(Gmail, Slack, Figma)*
- [ ] For each integration, build:
  - [ ] OAuth or SSO connection flow
  - [ ] token refresh handling
  - [x] scoped permissions model *(provider catalog defines scopes per integration)*
  - [x] integration health checks *(health_status field)*
  - [ ] revocation flow
- [x] Build initial data model for: Gmail, Slack, Figma *(provider catalog + connection records)*
- [x] Represent credentials as masked tokens and scopes, not exposed passwords.

## 9. Automation Recommendation Engine

- [x] Define how repeated work becomes an automation candidate. *(app/category/keyword heuristic in recommendation-engine.js)*
- [x] Build classification pipeline. *(observed actions are classified into template matches and fallback flows)*
- [x] Add confidence scoring. *(confidenceScore on generated automations)*
- [x] Add projected time savings calculation. *(projected_hours + impact labels)*
- [x] Add per-employee and per-org ranking. *(rank_score + GET /api/automation-opportunities)*
- [x] Add human-readable rationale generation. *(rationale on generated automations and report findings)*
- [x] Persist model inputs/outputs and evaluation traces where appropriate. *(recommendation_runs.trace_json)*

## 10. Approval And Execution Model

- [x] Define automation states:
  - [x] proposed
  - [x] review
  - [x] approved *(admin_decision = approved)*
  - [x] rejected
  - [x] pilot *(POST /api/automations/state)*
  - [x] active
  - [x] paused *(POST /api/automations/state)*
- [x] Add employee approval flow.
- [x] Add admin approval flow.
- [ ] Add manager approval flow if needed.
- [ ] Add policy engine for "what requires approval".
- [x] Add execution logs for every automation run. *(audit_events tracks all state changes)*
- [ ] Add rollback / disable flow.

## 11. Reporting

- [x] Build report generation pipeline. *(reports + report_findings in DB)*
- [x] Support:
  - [x] per-employee report *(GET /api/reports/:id)*
  - [ ] per-manager report
  - [x] org-level report *(GET /api/reports — all employees)*
- [x] Add export formats:
  - [x] in-app *(GET /api/reports, GET /api/reports/:id)*
  - [ ] PDF
  - [x] CSV *(GET /api/reports/:id?format=csv)*
- [ ] Add generated-at snapshots so reports stay historically stable.

## 12. Security

- [x] Encrypt secrets at rest. *(passwords via scrypt + salt; tokens via SHA-256 hash)*
- [x] Encrypt sensitive data in transit. *(localhost only; TLS needed for cloud)*
- [ ] Add secret management. *(env vars only; no vault yet)*
- [x] Add per-tenant authorization checks on every backend query.
- [x] Add audit logging for:
  - [x] sign-ins *(auth.login / auth.logout)*
  - [x] approvals *(automation.updated)*
  - [x] consent changes *(consent.updated)*
  - [x] integration connections *(integration.connected)*
  - [x] report access *(report.accessed)*
- [x] Add admin action history.
- [x] Add device registration and revocation.
- [ ] Add incident response plan.

## 13. Privacy And Compliance

- [x] Finalize metadata-only vs content-storage rules. *(documented in `backend/OPERATIONS.md`)*
- [x] Add explicit employee consent records. *(users.consent_status)*
- [ ] Add visible observation indicator requirements to product spec.
- [ ] Add retention/deletion policy.
- [ ] Add export/delete user data workflows.
- [ ] Define compliance target for first release.
- [ ] Add privacy policy and internal data handling rules.

## 14. Reliability And Ops

- [x] Add structured logging. *(JSON log lines on stdout in server.js)*
- [x] Add metrics. *(`GET /metrics`)*
- [ ] Add tracing.
- [ ] Add error monitoring.
- [x] Add health checks. *(GET /health)*
- [ ] Add job queue monitoring.
- [x] Add backup strategy. *(`npm run backend:backup` for local SQLite snapshots)*
- [ ] Add disaster recovery plan.
- [ ] Add production dashboards.

## 15. Testing

- [x] Integration tests for API/database paths. *(`npm run backend:test` — 75 tests, all passing)*
- [x] Unit tests for domain logic. *(recommendation-engine.test.js)*
- [ ] End-to-end tests for:
  - [x] sign-in *(covered in test.js)*
  - [x] employee invite *(covered in test.js)*
  - [x] consent *(covered in test.js)*
  - [x] observation ingest *(covered in test.js)*
  - [x] automation approval *(covered in test.js)*
  - [x] report generation *(covered in test.js)*
- [ ] Load tests for ingestion endpoints.
- [x] Security tests for auth and tenant isolation. *(unauthenticated, admin-only, and employee-scope cases covered in test.js)*

## 16. Deployment

- [ ] Set up backend deployment pipeline.
- [ ] Set up database migrations in CI/CD.
- [ ] Set up staging environment.
- [ ] Set up production environment.
- [ ] Set up desktop app release process for:
  - [ ] macOS signed build
  - [ ] update channel
  - [ ] rollback path

## 17. Immediate Build Order

- [x] Step 1: scaffold backend service and shared types.
- [x] Step 2: add database and migrations.
- [x] Step 3: move current seed data into the database.
- [x] Step 4: add auth and org/user models.
- [x] Step 5: replace current IPC-backed app reads/writes with API calls.
- [x] Step 6: add employee pages, approvals, and report reads from the API.
- [x] Step 7: add observer ingestion endpoint and local upload queue.
- [ ] Step 8: add first real integration and token handling.
- [x] Step 9: add automation generation pipeline.
- [ ] Step 10: add deployment, monitoring, and security hardening.

## 18. Sign-Ins / Credentials You Will Need From The User

- [ ] Cloud account login:
  - [ ] AWS / GCP / Azure / Railway / Render / Fly.io / similar
- [ ] Database provider login if separate.
- [ ] Auth provider login if using hosted auth.
- [ ] Domain / DNS provider login if deploying on a custom domain.
- [ ] OAuth app credentials for integrations:
  - [ ] Google
  - [ ] Slack
  - [ ] Notion
  - [ ] Salesforce
  - [ ] Figma
  - [ ] Zendesk / Intercom
- [ ] Error monitoring account if using Sentry or similar.
- [ ] Email provider credentials if sending invites or approval emails.
- [ ] Code signing / Apple developer credentials for production desktop distribution.

## 19. Recommended First Pass

For the fastest credible production path, start with:

- [x] Electron desktop app stays as client
- [x] one backend API service
- [x] SQLite (local) → PostgreSQL (cloud)
- [x] custom auth (scrypt + session tokens)
- [x] one ingestion worker / job queue
- [ ] S3-compatible object storage only if reports or attachments need it
- [ ] Google Workspace + Slack as the first real integrations
- [x] strict metadata-first storage

## 20. Not Actually "Production Ready" Yet

The current app is still missing all of these mandatory backend capabilities:

- [x] real auth *(password + session token login/logout)*
- [x] real database *(SQLite via node:sqlite)*
- [x] real API *(Node HTTP server with 20+ endpoints)*
- [ ] real integration credentials *(OAuth flows not built)*
- [x] real event ingestion *(observer batch endpoint + desktop queue)*
- [x] multi-tenant authorization *(org_id on every table + membership checks)*
- [x] audit logging *(audit_events on every write)*
- [x] structured logging *(JSON stdout from server.js)*
- [ ] deployment
- [ ] secrets management
- [ ] signed desktop release pipeline
